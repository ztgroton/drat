
#' Shiny Module UI - `clauseRuleOperator`
#'
#' @import shiny
#' @import shinyWidgets
#'
#' @param id character - Unique identifier for module instance
#' @param columns character - Reactive Expression
#'
#' @return R Shiny Tags
#' @export
#'
#' @examples
#' \dontrun{
#' clauseRuleColumn_ui('test', column)
#' }
clauseRuleColumn_ui <- function(id, columns) {

  # Session Namespace
  ns <- NS(id)

  tagList(
    shinyWidgets::pickerInput(
      ns("rule_column_control"),
      label = NULL,
      multiple = FALSE,
      selected = columns()[1],
      choices = sort(unique(as.character(columns()))),
      options = pickerOptions(liveSearch = TRUE),
      width = '100%'
    )
  )

}

#' Shiny Module Server - `clauseRuleColumn`
#'
#' @param id character - Unique identifier for module instance
#' @param data data.frame - Reactive Expression
#'
#' @return R Shiny Reactive Expression
#' @export
#'
#' @examples
#' \dontrun{
#' x <- clauseRuleColumn_server('test', data)
#' }
clauseRuleColumn_server <- function(id, data) {

  moduleServer(id, function(input, output, session) {

    # Session Namespace
    ns <- session$ns

    # _____________________________ ----
    # INPUT REACTIVE EXPRESSIONS ----

    # * tableData() ----
    tableData <- shiny::reactive({

      shiny::req(data())

      if (!isTRUE(is.data.frame(data()))) {
        shinyWidgets::show_toast(
          title = "`clauseRuleColumn_server` - Invalid Data Table!!!",
          type = "error",
          position = "bottom"
        )
      } else {
        return(data())
      }

    })

    # * tableColumns() ----
    tableColumns <- shiny::reactive({

      shiny::req(tableData())

      # Return `colnames(tableData())`
      return(colnames(tableData()))

    })

    # * tableColumnTypes() ----
    tableColumnTypes <- shiny::reactive({

      shiny::req(tableData())
      shiny::req(tableColumns())

      # Get Data Types for each Column
      types <- purrr::map_chr(tableData(), function(t){class(t)[1]})
      names(types) <- colnames(tableData())

      # Return Data Types
      return(types)

    })

    # ____________ ----
    # MODULE RETURN VALUE ----
    result <- shiny::reactive({

      req(input$rule_column_control)
      req(tableColumnTypes())

      # Return Selected Column Name and Type
      list(
        name = input$rule_column_control,
        type = tableColumnTypes()[[input$rule_column_control]]
      )

    })

    return(result)

    # _______________________ ----
    # END OF MODULE SERVER ----

  })

}




test_that("`r_col_nest` fails with missing values", {
  expect_error(r_col_nest(x = data.frame(a = vector())), "`group` is missing in call to `r_col_nest`", fixed = TRUE)
  expect_error(r_col_nest(group = 'a'), "`x` is missing in call to `r_col_nest`", fixed = TRUE)
})

test_that("`r_col_nest` fails when `x` is not `data.frame`", {
  expect_error(r_col_nest(x = list(b = vector()), group = 'a'), "`x` must be `data.frame` in call to `r_col_nest`", fixed = TRUE)
})

test_that("`r_col_nest` fails when `group` is invalid", {
  expect_error(r_col_nest(x = data.frame(a = vector()), group = '4'), "`group` must be subset of `colnames(x)` in call to `r_col_nest`", fixed = TRUE)
  expect_error(r_col_nest(x = data.frame(a = vector()), group = c('b', 'c')), "`group` must be subset of `colnames(x)` in call to `r_col_nest`", fixed = TRUE)
  expect_error(r_col_nest(x = data.frame(a = vector()), group = c('a', 'b', 'c')), "`group` must be subset of `colnames(x)` in call to `r_col_nest`", fixed = TRUE)
})


test_that("`psql_db_connect` works", {
  expect_true(expect_dbi(psql_db_connect('comp_map_lib')))
  expect_true(expect_dbi(psql_db_connect('market_pos')))
  expect_error(expect_dbi(psql_db_connect(c('comp_map_lib', 'market_pos'))))
  expect_error(expect_dbi(psql_db_connect(2)))
  expect_error(expect_dbi(psql_db_connect(TRUE)))
  expect_error(expect_dbi(psql_db_connect(NA)))
})

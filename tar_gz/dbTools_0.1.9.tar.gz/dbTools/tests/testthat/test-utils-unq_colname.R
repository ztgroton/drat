test_that("`unq_colname` works", {
  expect_equal(unq_colname(data.frame(a = vector()), 'a'), 'a_1')
  expect_equal(unq_colname(data.frame(b = vector()), 'a'), 'a')
})

test_that("`unq_colname` fails with missing values", {
  expect_error(unq_colname(data.frame(a = vector())), "`name` is missing in call to `unq_colname`")
  expect_error(unq_colname(name = 'a'), "`x` is missing in call to `unq_colname`")
})

test_that("`unq_colname` fails when `x` is not `data.frame`", {
  expect_error(unq_colname(x = list(b = vector()), name = 'a'), "`x` must be `data.frame` in call to `unq_colname`")
})

test_that("`unq_colname` fails when `name` is not length 1 character", {
  expect_error(unq_colname(x = data.frame(a = vector()), name = 2), "`name` must be character in call to `unq_colname`")
  expect_error(unq_colname(x = data.frame(a = vector()), name = c('b', 'c')), "`name` must be length 1 in call to `unq_colname`")
  expect_error(unq_colname(x = data.frame(a = vector()), name = NA_character_), "`name` cannot be NA in call to `unq_colname`")
})

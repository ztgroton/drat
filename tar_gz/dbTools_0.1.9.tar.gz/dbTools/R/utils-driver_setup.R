
#' Return Correct DBI Driver for Connection Type
#'
#' @param x character - connection type : 'psql', 'mssql' or 'bqsql'
#'
#' @return DBI Driver
#' @export
#'
driver_setup <- function(x) {

  # Validate Inputs
  if (missing(x)) {stop("`x` is missing in call to `driver_setup`", call. = FALSE)}

  # Validate Input Expectations
  expect_scalar_char(x)

  valid_drivers <- c('psql', 'mssql', 'bqsql')
  if (!isTRUE(x %in% valid_drivers)) {
    stop("`x` must be one of c('psql', 'mssql', 'bqsql') in call to `driver_setup`", call. = FALSE)
  }

  # Return Driver
  if (isTRUE(x == 'psql')) {
    drv <- RPostgreSQL::PostgreSQL()
  } else if (isTRUE(x == 'mssql')) {
    drv <- odbc::odbc()
  } else if (isTRUE(x == 'bqsql')) {
    drv <- bigrquery::bigquery()
  }

  return(drv)

}

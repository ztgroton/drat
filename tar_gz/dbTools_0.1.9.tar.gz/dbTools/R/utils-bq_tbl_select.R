
#' Select contents of an existing BigQuery table referenced by 'tbl'
#'
#' @param tbl S3 Object
#'
#' @return data.frame
#' @export
#'
bq_tbl_select <- function(tbl) {

  # Validate Inputs
  if (missing(tbl)) {stop("`tbl` is missing in call to `bq_tbl_select`", call. = FALSE)}

  # Validate Input Expectations
  if (!isTRUE(inherits(tbl, 'bq_table'))) {
    stop("`tbl` must inherit from S3 class 'bq_table' in call to `bq_tbl_select`", call. = FALSE)
  }

  # Query Table Contents
  res <- bigrquery::bq_table_download(tbl, quiet = TRUE)

  # Return Results
  return(res)

}


#' Validate if a set of columns 'fk' is a Foreign Key on data frames 'x' and 'y'
#'
#' @param x data.frame - The first 'data.frame' containing data to be tested.
#' @param y data.frame - The second 'data.frame' containing data to be tested.
#' @param fk character - Vector of column names defining a candidate 'foreign key' for 'x' and 'y'.
#'
#' @return R Object
#' @export
#'
r_nest_fk <- function(x, y, fk) {

  # Validate Inputs

  # * `x`
  if (missing(x)) {stop("`x` is missing in call to `r_nest_fk`", call. = FALSE)}
  if (!isTRUE(is.data.frame(x))) {stop("`x` must be `data.frame` in call to `r_nest_fk`", call. = FALSE)}

  # * `y`
  if (missing(y)) {stop("`y` is missing in call to `r_nest_fk`", call. = FALSE)}
  if (!isTRUE(is.data.frame(y))) {stop("`y` must be `data.frame` in call to `r_nest_fk`", call. = FALSE)}

  # * `fk`
  if (missing(fk)) {stop("`fk` is missing in call to `r_nest_fk`", call. = FALSE)}
  if (!isTRUE(all(fk %in% colnames(y)))) {
    stop("`fk` must be subset of `colnames(y)` in call to `r_nest_fk`", call. = FALSE)
  }

  fk_names <- attr(fk, 'names')
  fk_is_named <- !isTRUE(is.null(fk_names))

  if (!isTRUE(fk_is_named)) {

    stop("`fk` must have `names(fk)` defined in call to `r_nest_fk`", call. = FALSE)

  } else {

    if (!isTRUE(is.character(fk_names))) {
      stop("`names(fk)` must be `character` in call to `r_nest_fk`", call. = FALSE)
    }

    any_na <- isTRUE(any(purrr::map_lgl(fk_names, ~ isTRUE(is.na(.x)))))
    if (isTRUE(any_na)) {
      stop("`names(fk)` cannot contain NA values in call to `r_nest_fk`", call. = FALSE)
    }

    any_null <- isTRUE(any(purrr::map_lgl(fk_names, ~ isTRUE(is.null(.x)))))
    if (isTRUE(any_null)) {
      stop("`names(fk)` cannot contain NULL values in call to `r_nest_fk`", call. = FALSE)
    }

    any_empty <- isTRUE(any(purrr::map_lgl(fk_names, ~ isTRUE(nchar(.x) == 0))))
    if (isTRUE(any_empty)) {
      stop("`names(fk)` cannot contain empty '' values in call to `r_nest_fk`", call. = FALSE)
    }

    if (!isTRUE(all(fk_names %in% colnames(x)))) {
      stop("`names(fk)` must be subset of `colnames(x)` in call to `r_nest_fk`", call. = FALSE)
    }

  }

  # Compute `x_nest`
  x_nest <- r_col_nest(x = x, group = fk_names) %>% dplyr::select(-.data$nest_row_cnt)

  # Compute `y_nest`
  y_nest <- r_col_nest(x = y, group = fk) %>% dplyr::select(-.data$nest_row_cnt)

  # Full Join `x_nest` and `y_nest`
  xy_nest <- x_nest %>% dplyr::full_join(y_nest, by = fk, suffix = c('_x', '_y'), na_matches = "never")

  # Compute Lengths
  xy_nest <- xy_nest %>%
    dplyr::mutate(row_num_cnt_x = purrr::map_dbl(.data$nest_row_num_x, ~ ifelse(is.null(.x), 0, nrow(.x)))) %>%
    dplyr::mutate(row_num_cnt_y = purrr::map_dbl(.data$nest_row_num_y, ~ ifelse(is.null(.x), 0, nrow(.x))))

  # Return
  class(xy_nest) <- c(setdiff('r_nest_fk', class(xy_nest)), class(xy_nest))
  return(xy_nest)

}

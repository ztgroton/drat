
#' S3 Generic - Summarize a Candidate Primary Key
#'
#' @param obj S3 Class 'nest_fk'
#'
#' @return data.frame
#' @export
#'
fk_summary <- function(obj) {UseMethod("fk_summary", obj)}

#' S3 Method - Summarize a Candidate Primary Key
#'
#' @importFrom rlang .data
#'
#' @param obj S3 Class 'nest_fk'
#'
#' @return list
#' @export
#'
fk_summary.nest_fk <- function(obj) {

  if (missing(obj)) {stop("`obj` is missing in call to `pk_summary.nest_fk`", call. = FALSE)}
  if (!isTRUE(inherits(obj, 'nest_fk'))) {
    stop("`obj` must inherit from 'nest_fk' in call to `pk_summary.nest_fk`", call. = FALSE)
  }

  # Calculate `unq_cnt`
  unq_cnt <- nrow(obj)

  # Calculate `row_cnt_x`
  if (!isTRUE('orig_row_cnt_x' %in% colnames(obj))) {
    stop("`orig_row_cnt_x` not found in `colnames(obj)` in call to `pk_summary.nest_fk`", call. = FALSE)
  }

  row_cnt_x <- sum(obj$orig_row_cnt_x)

  # Calculate `row_cnt_y`
  if (!isTRUE('orig_row_cnt_y' %in% colnames(obj))) {
    stop("`orig_row_cnt_y` not found in `colnames(obj)` in call to `pk_summary.nest_fk`", call. = FALSE)
  }

  row_cnt_y <- sum(obj$orig_row_cnt_y)

  # Calculate `non_na_cnt`
  fk_cols <- setdiff(colnames(obj), c('orig_row_num_x', 'orig_row_num_y', 'orig_row_cnt_x', 'orig_row_cnt_y'))

  fk_cols_non_na <- lapply(fk_cols, function(x){
    purrr::map_lgl(obj[[x]], ~ !isTRUE(is.null(.x)) && !isTRUE(is.na(.x)))
  })
  names(fk_cols_non_na) <- fk_cols

  fk_non_na <- purrr::reduce(fk_cols_non_na, `&`)
  non_na_cnt <- sum(as.numeric(fk_non_na))

  # Calculate `unq_cnt_x`
  unq_cnt_x <- obj %>% dplyr::filter(purrr::map_lgl(.data$orig_row_num_x, ~ !isTRUE(is.null(.x)))) %>% nrow()

  # Calculate `unq_cnt_y`
  unq_cnt_y <- obj %>% dplyr::filter(purrr::map_lgl(.data$orig_row_num_y, ~ !isTRUE(is.null(.x)))) %>% nrow()

  # Calculate `fk_score_x`
  fk_score_x <-  1 - (row_cnt_x - non_na_cnt)/row_cnt_x

  # Calculate `fk_score_y`
  fk_score_y <-  1 - (row_cnt_y - non_na_cnt)/row_cnt_y


  # Return Result
  res <- list(
    unq_cnt = unq_cnt,
    non_na_cnt = non_na_cnt,
    row_cnt_x = row_cnt_x,
    row_cnt_y = row_cnt_y,
    unq_cnt_x = unq_cnt_x,
    unq_cnt_y = unq_cnt_y,
    fk_score_x = fk_score_x,
    fk_score_y = fk_score_y
  )

  return(res)

}

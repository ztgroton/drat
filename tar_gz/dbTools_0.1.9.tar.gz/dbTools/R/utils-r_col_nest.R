
#' Group Row Numbers of a Data Frame by Columns
#'
#' @param x data.frame - The data.frame containing data to be nested.
#' @param group character - Vector of column names to 'group by'. If vector has names, grouping columns will be renamed accordingly.
#'
#' @return data.frame
#' @export
#'
r_col_nest <- function(x, group) {

  # Validate Inputs
  if (missing(x)) {stop("`x` is missing in call to `r_col_nest`", call. = FALSE)}
  if (!isTRUE(is.data.frame(x))) {stop("`x` must be `data.frame` in call to `r_col_nest`", call. = FALSE)}

  if (missing(group)) {stop("`group` is missing in call to `r_col_nest`", call. = FALSE)}
  if (!isTRUE(all(group %in% colnames(x)))) {
    stop("`group` must be subset of `colnames(x)` in call to `r_col_nest`", call. = FALSE)
  }

  # Select columns using `group`
  x <- x [, c(group), drop = F]

  # Save `colnames(x)` as `group_by_cols` for later use
  group_by_cols <- colnames(x)

  # Generate Row Numbers
  unq_rownum_name <- unq_colname(x, 'row_num')
  x[, c(unq_rownum_name)] <- 1:nrow(x)

  # Nest Row Numbers
  x <- x %>%
    dplyr::group_by_at(group_by_cols) %>%
    dplyr::group_nest(.key = 'nest_row_num') %>%
    dplyr::ungroup() %>%
    dplyr::mutate(nest_row_cnt = purrr::map_dbl(.data$nest_row_num, function(x){ifelse(is.null(x), 0, nrow(x))}))

  # Return
  class(x) <- c('r_col_nest', unique(setdiff(class(x), 'r_col_nest')))
  return(x)

}

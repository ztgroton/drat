
#' List Existing EDAP PSQL Schema
#'
#' @param conn DBI Connection
#'
#' @importFrom rlang .data
#' @return data.frame
#'
get_psql_schema <- function(conn) {

  # Validate Inputs

  # * `conn`
  if (missing(conn)) {stop("`conn` is missing in call to `get_psql_schema`", call. = FALSE)}
  expect_dbi(conn)

  if (!isTRUE(is_psql(conn))) {stop("`conn` must be PSQL Connection in call to `get_psql_schema`", call. = FALSE)}

  # Construct Query
  qry <- readr::read_file(system.file('sql/metadata/get_schema/psql_list_schemas.sql', package = 'dbTools'))

  # Execute and Return
  DBI::dbGetQuery(conn, qry) %>% as.data.frame()

}

#' List Existing EDAP MSSQL Schema
#'
#' @param conn DBI Connection
#'
#' @importFrom rlang .data
#' @return data.frame
#'
get_mssql_schema <- function(conn) {

  # Validate Inputs

  # * `conn`
  if (missing(conn)) {stop("`conn` is missing in call to `get_mssql_schema`", call. = FALSE)}
  expect_dbi(conn)

  if (!isTRUE(is_mssql(conn))) {stop("`conn` must be MSSQL Connection in call to `get_mssql_schema`", call. = FALSE)}

  # Construct Query
  qry <- readr::read_file(system.file('sql/metadata/get_schema/mssql_list_schemas.sql', package = 'dbTools'))

  # Execute and Return
  DBI::dbGetQuery(conn, qry) %>% as.data.frame()

}


#' List All Existing Schemas in R DBI Connection
#'
#' @param conn DBI Connection
#'
#' @return data.frame
#' @export
#'
get_schema <- function(conn) {

  # Validate Inputs
  if (missing(conn)) {
    stop("`conn` is missing in call to `get_schema`", call. = FALSE)
  }
  expect_dbi(conn)

  # MAIN LOGIC

  if (isTRUE(is_psql(conn))) { # PSQL
    return(get_psql_schema(conn))
  } else if (isTRUE(is_mssql(conn))) { # MSSQL
    return(get_mssql_schema(conn))
  } else {
    stop("`get_schema` must be called on PSQL or MSSQL connection", call. = FALSE)
  }

}

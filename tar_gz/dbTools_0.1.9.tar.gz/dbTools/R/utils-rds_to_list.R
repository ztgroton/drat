
#' Read directory containing RDS Files into a single list
#'
#' @param rds_dir character
#'
#' @return list
#' @export
#'
rds_to_list <- function(rds_dir) {

  # Validate Input
  if (missing(rds_dir)) {
    stop("`rds_dir` is missing in call to `rds_to_list`", call. = FALSE)
  }
  expect_scalar_char(rds_dir)

  # List Directory Contents
  dir_contents <- list.files(path = rds_dir, pattern = "*.rds", full.names = FALSE, recursive = FALSE)
  if (isTRUE(length(dir_contents) == 0)) {
    stop("`dir_dir` contains no RDS Files in call to `rds_to_list`", call. = FALSE)
  }

  # Pull RDS Files into List
  rds_list <- purrr::map(dir_contents, ~ readRDS(file.path(rds_dir, .x)))
  names(rds_list) <- gsub('.rds', '', dir_contents, fixed = TRUE)

  # Return Named List of RDS Files
  return(rds_list)

}

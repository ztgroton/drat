
select distinct
fk_obj.name as constraint_name,
schemas.name as schema_name,
tabs.name as table_name,
cols.name as column_name,
ref_schemas.name as foreign_schema_name,
ref_tabs.name AS foreign_table_name,
ref_cols.name AS foreign_column_name

from {db_sql}.sys.all_columns cols

inner join {db_sql}.sys.tables tabs
on cols.object_id = tabs.object_id

inner join {db_sql}.sys.schemas schemas
on tabs.schema_id = schemas.schema_id

inner join {db_sql}.sys.foreign_key_columns ref
on ref.parent_object_id = tabs.object_id
and ref.parent_column_id = cols.column_id

inner join sys.objects fk_obj
on fk_obj.object_id = ref.constraint_object_id

inner join {db_sql}.sys.tables ref_tabs
on ref_tabs.object_id = ref.referenced_object_id

inner join {db_sql}.sys.schemas ref_schemas
on ref_tabs.schema_id = ref_schemas.schema_id

inner join {db_sql}.sys.all_columns ref_cols
on ref_cols.object_id = ref.referenced_object_id
and ref_cols.column_id = ref.referenced_column_id

where not (schemas.name = 'dbo' and tabs.name = 'store' and cols.name = 'primary_bank')
and schemas.name = {schema}

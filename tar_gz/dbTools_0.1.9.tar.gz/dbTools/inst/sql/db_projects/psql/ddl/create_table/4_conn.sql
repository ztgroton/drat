
CREATE TABLE IF NOT EXISTS common.conn
(
  id SERIAL,
  conn_type_id INTEGER NOT NULL,
  name TEXT NOT NULL,

  CONSTRAINT common_conn_pkey PRIMARY KEY (id),
  CONSTRAINT common_conn_fkey1 FOREIGN KEY (conn_type_id) REFERENCES common.conn_type (id) ON UPDATE CASCADE ON DELETE RESTRICT,
  CONSTRAINT common_conn_unq1 UNIQUE (name)
)

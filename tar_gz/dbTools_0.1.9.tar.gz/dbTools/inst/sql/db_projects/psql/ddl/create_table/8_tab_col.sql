
CREATE TABLE IF NOT EXISTS common.tab_col
(
  tab_id INTEGER NOT NULL,
  col_id INTEGER NOT NULL,
  name TEXT NOT NULL,

  CONSTRAINT common_tab_col_pkey PRIMARY KEY (tab_id, col_id),
  CONSTRAINT common_tab_col_fkey1 FOREIGN KEY (tab_id) REFERENCES common.tab (id) ON UPDATE CASCADE ON DELETE RESTRICT
)

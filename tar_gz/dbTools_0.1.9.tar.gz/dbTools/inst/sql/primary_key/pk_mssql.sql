
select distinct

CASE
  WHEN ind.name IS NOT NULL THEN ind.name
  ELSE CONCAT('PK_', tabs.name)
END as constraint_name,

schemas.name as schema_name,
tabs.name as table_name,
cols.name as column_name

from {db_sql}.sys.all_columns cols

inner join {db_sql}.sys.tables tabs
on cols.object_id = tabs.object_id

inner join {db_sql}.sys.schemas schemas
on tabs.schema_id = schemas.schema_id

inner join {db_sql}.sys.indexes ind
on ind.object_id = tabs.object_id
and ind.is_primary_key = 1

inner join {db_sql}.sys.index_columns ind_col
on ind_col.object_id = ind.object_id
and ind_col.index_id = ind.index_id
and ind_col.column_id = cols.column_id

where not (schemas.name = 'dbo' and tabs.name = 'store' and cols.name = 'primary_bank')
and schemas.name = {schema}


#' Create Table 'map_library.competitor'
#'
#' @param conn DBIConnection - R Database Connection Object
#'
#' @return NULL
#'
create_competitor_table <- function(conn) {

  # Validate Inputs
  if (missing(conn)) {stop("`conn` is missing in call to `create_competitor_table`", call. = FALSE)}

  # Validate Input Expectations
  expect_dbi(conn)

  # Check if 'map_library' schema already exists
  exist_qry <- "SELECT schema_name FROM information_schema.schemata WHERE schema_name = 'map_library'"
  map_library_exists <- isTRUE(nrow(DBI::dbGetQuery(conn, exist_qry)) == 1)
  if (isTRUE(map_library_exists)) {

    DBI::dbExecute(
      conn = conn,
      glue::glue(
        "
        CREATE TABLE IF NOT EXISTS map_library.competitor
        (
          competitor_hash TEXT NOT NULL CHECK (competitor_hash = encode(public.digest(competitor_name::TEXT, 'sha256'), 'hex')),
          competitor_name TEXT NOT NULL,
          CONSTRAINT comp_map_lib_competitor_pkey PRIMARY KEY (competitor_hash)
        );
        "
      )
    )

  } else {
    message("schema `map_library` DOES NOT EXIST")
  }

  invisible(return(NULL))

}

#' Create Table 'map_library.twm_map'
#'
#' @param conn DBIConnection - R Database Connection Object
#'
#' @return NULL
#'
create_twm_map_table <- function(conn) {

  # Validate Inputs
  if (missing(conn)) {stop("`conn` is missing in call to `create_twm_map_table`", call. = FALSE)}

  # Validate Input Expectations
  expect_dbi(conn)

  # Check if 'map_library' schema already exists
  exist_qry <- "SELECT schema_name FROM information_schema.schemata WHERE schema_name = 'map_library'"
  map_library_exists <- isTRUE(nrow(DBI::dbGetQuery(conn, exist_qry)) == 1)
  if (isTRUE(map_library_exists)) {

    DBI::dbExecute(
      conn = conn,
      glue::glue(
        "
        CREATE TABLE IF NOT EXISTS map_library.twm_map
        (
          map_hash TEXT NOT NULL CHECK (map_hash = encode(public.digest(CONCAT(twm_item_code::TEXT, '-'::TEXT, twm_position_key::TEXT), 'sha256'), 'hex')),
          twm_item_code NUMERIC NOT NULL,
          twm_position_key INTEGER NOT NULL CHECK (twm_position_key IN (1,2,3)),
          CONSTRAINT comp_map_lib_twm_map_pkey PRIMARY KEY (map_hash)
        );
        "
      )
    )

  } else {
    message("schema `map_library` DOES NOT EXIST")
  }

  invisible(return(NULL))

}

#' Create Table 'map_library.map_lib'
#'
#' @param conn DBIConnection - R Database Connection Object
#'
#' @return NULL
#'
create_map_lib_table <- function(conn) {

  # Validate Inputs
  if (missing(conn)) {stop("`conn` is missing in call to `create_map_lib_table`", call. = FALSE)}

  # Validate Input Expectations
  expect_dbi(conn)

  # Check if 'map_library' schema already exists
  exist_qry <- "SELECT schema_name FROM information_schema.schemata WHERE schema_name = 'map_library'"
  map_library_exists <- isTRUE(nrow(DBI::dbGetQuery(conn, exist_qry)) == 1)
  if (isTRUE(map_library_exists)) {

    DBI::dbExecute(
      conn = conn,
      glue::glue(
        "
        CREATE TABLE IF NOT EXISTS map_library.map_lib
        (
          key_hash TEXT NOT NULL CHECK (encode(public.digest(key_jsonb::TEXT, 'sha256'), 'hex') = key_hash),
          key_jsonb JSONB NOT NULL,
          map_order INTEGER DEFAULT 1 CHECK (map_order > 0),
          map_hash TEXT DEFAULT NULL,
          is_primary BOOLEAN NOT NULL CHECK((is_primary AND map_order = 1) OR map_order > 1),
          CONSTRAINT comp_map_lib_map_lib_pkey PRIMARY KEY (key_hash, map_order),
          CONSTRAINT comp_map_lib_map_lib_fkey1 FOREIGN KEY (map_hash) REFERENCES map_library.twm_map (map_hash) ON DELETE RESTRICT ON UPDATE CASCADE
        );
        "
      )
    )

  } else {
    message("schema `map_library` DOES NOT EXIST")
  }

  invisible(return(NULL))

}

#' Create Table 'map_library.map_lib_update'
#'
#' @param conn DBIConnection - R Database Connection Object
#'
#' @return NULL
#'
create_map_lib_update_table <- function(conn) {

  # Validate Inputs
  if (missing(conn)) {stop("`conn` is missing in call to `create_map_lib_update_table`", call. = FALSE)}

  # Validate Input Expectations
  expect_dbi(conn)

  # Check if 'map_library' schema already exists
  exist_qry <- "SELECT schema_name FROM information_schema.schemata WHERE schema_name = 'map_library'"
  map_library_exists <- isTRUE(nrow(DBI::dbGetQuery(conn, exist_qry)) == 1)
  if (isTRUE(map_library_exists)) {

    DBI::dbExecute(
      conn = conn,
      glue::glue(
        "
        CREATE TABLE IF NOT EXISTS map_library.map_lib_update
        (
          id SERIAL NOT NULL,
          edit_time TIMESTAMPTZ NOT NULL,
          edit_type TEXT NOT NULL CHECK (edit_type IN ('I', 'U', 'D')),
          key_hash TEXT NOT NULL CHECK (encode(public.digest(key_jsonb::TEXT, 'sha256'), 'hex') = key_hash),
          key_jsonb JSONB NOT NULL,
          map_order INTEGER NOT NULL,
          map_hash TEXT DEFAULT NULL,
          is_primary BOOLEAN NOT NULL,
          CONSTRAINT comp_map_lib_map_lib_update_pkey PRIMARY KEY (id),
          CONSTRAINT comp_map_lib_map_lib_update_fkey1 FOREIGN KEY (map_hash) REFERENCES map_library.twm_map (map_hash) ON UPDATE RESTRICT ON DELETE RESTRICT
        );
        "
      )
    )

  } else {
    message("schema `map_library` DOES NOT EXIST")
  }

  invisible(return(NULL))

}

#' Create Table 'map_library.valid_key'
#'
#' @param conn DBIConnection - R Database Connection Object
#'
#' @return NULL
#'
create_valid_key_table <- function(conn) {

  # Validate Inputs
  if (missing(conn)) {stop("`conn` is missing in call to `create_valid_key_table`", call. = FALSE)}

  # Validate Input Expectations
  expect_dbi(conn)

  # Check if 'map_library' schema already exists
  exist_qry <- "SELECT schema_name FROM information_schema.schemata WHERE schema_name = 'map_library'"
  map_library_exists <- isTRUE(nrow(DBI::dbGetQuery(conn, exist_qry)) == 1)
  if (isTRUE(map_library_exists)) {

    DBI::dbExecute(
      conn = conn,
      glue::glue(
        "
        CREATE TABLE IF NOT EXISTS map_library.valid_key
        (
          name TEXT NOT NULL,
          CONSTRAINT comp_map_lib_valid_key_pkey PRIMARY KEY (name)
        );
        "
      )
    )

  } else {
    message("schema `map_library` DOES NOT EXIST")
  }

  invisible(return(NULL))

}

#' Create Table 'map_library.valid_key_field'
#'
#' @param conn DBIConnection - R Database Connection Object
#'
#' @return NULL
#'
create_valid_key_field_table <- function(conn) {

  # Validate Inputs
  if (missing(conn)) {stop("`conn` is missing in call to `create_valid_key_field_table`", call. = FALSE)}

  # Validate Input Expectations
  expect_dbi(conn)

  # Check if 'map_library' schema already exists
  exist_qry <- "SELECT schema_name FROM information_schema.schemata WHERE schema_name = 'map_library'"
  map_library_exists <- isTRUE(nrow(DBI::dbGetQuery(conn, exist_qry)) == 1)
  if (isTRUE(map_library_exists)) {

    DBI::dbExecute(
      conn = conn,
      glue::glue(
        "
        CREATE TABLE IF NOT EXISTS map_library.valid_key_field
        (
          key TEXT NOT NULL,
          field TEXT NOT NULL,
          type TEXT NOT NULL,
          CONSTRAINT comp_map_lib_valid_key_field_pkey PRIMARY KEY (key, field),
          CONSTRAINT comp_map_lib_valid_key_field_fkey1 FOREIGN KEY (key) REFERENCES map_library.valid_key (name) ON UPDATE CASCADE ON DELETE CASCADE
        );
        "
      )
    )

  } else {
    message("schema `map_library` DOES NOT EXIST")
  }

  invisible(return(NULL))

}

#' Drop Table 'map_library.competitor'
#'
#' @param conn DBIConnection - R Database Connection Object
#'
#' @return NULL
#'
drop_competitor_table <- function(conn) {

  # Validate Inputs
  if (missing(conn)) {stop("`conn` is missing in call to `drop_competitor_table`", call. = FALSE)}

  # Validate Input Expectations
  expect_dbi(conn)

  DBI::dbExecute(conn = conn, glue::glue("DROP TABLE IF EXISTS map_library.competitor"))

}

#' Drop Table 'map_library.twm_map'
#'
#' @param conn DBIConnection - R Database Connection Object
#'
#' @return NULL
#'
drop_twm_map_table <- function(conn) {

  # Validate Inputs
  if (missing(conn)) {stop("`conn` is missing in call to `drop_twm_map_table`", call. = FALSE)}

  # Validate Input Expectations
  expect_dbi(conn)

  # Check if 'map_library' schema already exists
  DBI::dbExecute(conn = conn, glue::glue("DROP TABLE IF EXISTS map_library.twm_map"))

}

#' Drop Table 'map_library.map_lib'
#'
#' @param conn DBIConnection - R Database Connection Object
#'
#' @return NULL
#'
drop_map_lib_table <- function(conn) {

  # Validate Inputs
  if (missing(conn)) {stop("`conn` is missing in call to `drop_map_lib_table`", call. = FALSE)}

  # Validate Input Expectations
  expect_dbi(conn)

  # Check if 'map_library' schema already exists
  DBI::dbExecute(conn = conn, glue::glue("DROP TABLE IF EXISTS map_library.map_lib"))

}

#' Drop Table 'map_library.map_lib_update'
#'
#' @param conn DBIConnection - R Database Connection Object
#'
#' @return NULL
#'
drop_map_lib_update_table <- function(conn) {

  # Validate Inputs
  if (missing(conn)) {stop("`conn` is missing in call to `drop_map_lib_update_table`", call. = FALSE)}

  # Validate Input Expectations
  expect_dbi(conn)

  # Check if 'map_library' schema already exists
  DBI::dbExecute(conn = conn, glue::glue("DROP TABLE IF EXISTS map_library.map_lib_update"))

}

#' Drop Table 'map_library.valid_key'
#'
#' @param conn DBIConnection - R Database Connection Object
#'
#' @return NULL
#'
drop_valid_key_table <- function(conn) {

  # Validate Inputs
  if (missing(conn)) {stop("`conn` is missing in call to `drop_valid_key_table`", call. = FALSE)}

  # Validate Input Expectations
  expect_dbi(conn)

  # Check if 'map_library' schema already exists
  DBI::dbExecute(conn = conn, glue::glue("DROP TABLE IF EXISTS map_library.valid_key"))

}

#' Drop Table 'map_library.valid_key_field'
#'
#' @param conn DBIConnection - R Database Connection Object
#'
#' @return NULL
#'
drop_valid_key_field_table <- function(conn) {

  # Validate Inputs
  if (missing(conn)) {stop("`conn` is missing in call to `drop_valid_key_field_table`", call. = FALSE)}

  # Validate Input Expectations
  expect_dbi(conn)

  # Check if 'map_library' schema already exists
  DBI::dbExecute(conn = conn, glue::glue("DROP TABLE IF EXISTS map_library.valid_key_field"))

}


#' Construct an Empty S3 Object of class 'cdmp_key'
#'
#' @param schema character
#' @param key character
#' @param val list
#'
#' @return S3 Object
#'
new_cdmp_key <- function(schema, key, val) {

  # Validate Inputs
  if (missing(schema)) {schema <- vector('character')}
  if (missing(key)) {key <- vector('character')}
  if (missing(val)) {val <- NULL}

  # Define Class Environment
  rs <- new.env()

  # Define Class Members
  rs$schema <- schema
  rs$key <- key
  rs$val <- val

  # Update Class Path
  class(rs) <- c(setdiff('cdmp_key', class(rs)), class(rs))

  # Return Object
  return(rs)

}

#' Validate that List of Values is Formatted according to Key
#'
#' @param val list
#' @param key character
#'
#' @return TRUE
#'
#' @examples
#' \dontrun{
#' validate_key_val(list(item_name = 'TEST'), 'item_name')
#' }
validate_key_val <- function(val, key) {

  # Validate Inputs
  if (missing(val)) {stop("`val` is missing in call to `validate_key_val`")}
  if (missing(key)) {stop("`key` is missing in call to 'validate_key_val'")}

  # Validate Input Expectations

  # * `key`
  dbTools::expect_scalar_char(key)
  if (!isTRUE(key %in% get_cdmp_valid_keys())) {
    stop("`key` must be valid key name in call to `validate_key_val`")
  }

  # * `val`
  fields_key <- get_cdmp_valid_key_fields()[[key]]
  if (!isTRUE(is.list(val)) || !isTRUE(identical(sort(fields_key), sort(names(val))))) {
    stop("`val` must be a list whose names match `fields_key` in call to `validate_key_val`")
  }


  # Initialize `types_key`
  types_key <- get_cdmp_valid_key_field_types()[[key]]

  # Iterate over 'names(types_key)'
  valid_types <- purrr::map_lgl(names(types_key), function(x) {

    switch(
      types_key[x],
      TEXT = {isTRUE(dbTools::expect_scalar_char(val[[x]]))},
      NUMERIC = {isTRUE(dbTools::expect_data_type(val[[x]], 'numeric', TRUE, TRUE, FALSE))},
      stop("`type_key[x]` is unrecognized in call to `validate_key_val`")
    )

  })

  # Return Success
  return(TRUE)


}

#' Validate that 'obj' is properly formatted S3 Object of class 'cdmp_key'
#'
#' @param obj S3 Object
#' @param bool TRUE/FALSE - indicates if function should invisibly return 'obj' or 'TRUE/FALSE'
#'
#' @return S3 Object, TRUE/FALSE
#'
validate_cdmp_key <- function(obj, bool) {

  # Validate Inputs
  if (missing(obj)) {stop("`obj` is missing in call to `validate_cdmp_key`", call. = FALSE)}
  if (missing(bool)) {bool <- FALSE}

  # Validate Input Expectations
  expect_env(obj, c('schema', 'key', 'val'))
  expect_scalar_logical(bool)

  # * schema
  expect_scalar_char(obj$schema)
  if (!isTRUE(obj$schema %in% get_valid_schema_names())) {
    stop("`schema` must be valid key name in call to `validate_cdmp_key`")
  }

  # * key
  expect_scalar_char(obj$key)
  if (!isTRUE(obj$key %in% get_valid_schema_keys(obj$schema))) {
    stop("`key` must be valid key name in call to `validate_cdmp_key`")
  }

  # * val
  invisible(validate_key_val(obj$val, obj$key))

  # Return Result
  if (isTRUE(bool)) {return(TRUE)}
  else {invisible(obj)}

}

#' Helper Function for Constructing S3 Class 'cdmp_key'
#'
#' @param schema character
#' @param key character
#' @param val list
#'
#' @return S3 Object
#' @export
#'
#' @examples
#' \dontrun{
#' record <- cdmp_key(schema, key, val)
#' }
cdmp_key <- function(schema, key, val) {

  # Validate Inputs
  if (missing(schema)) {schema <- vector('character')}
  if (missing(key)) {key <- vector('character')}
  if (missing(val)) {val <- NULL}

  new_cdmp_key(schema, key, val) %>% validate_cdmp_key()

}

#' S3 Generic - Retrieve Internal Values from 'cdmp_key' object
#'
#' @param obj S3 Object of class 'cdmp_key'
#' @param name character
#'
#' @return NULL
#' @export
#'
get_elem <- function(obj, name) {UseMethod("get_elem", obj)}

#' S3 Generic - Set Internal Values from 'cdmp_key' object
#'
#' @param obj S3 Object of class 'cdmp_key'
#' @param name character
#' @param value R Object
#'
#' @return NULL
#' @export
#'
set_elem <- function(obj, name, value) {UseMethod("set_elem", obj)}

#' S3 Generic - Clear Existing Mappings for 'cdmp_key' object
#'
#' @param obj S3 Object of class 'cdmp_key'
#' @param map_order integer
#'
#' @return NULL
#' @export
#'
clear_map <- function(obj, map_order) {UseMethod("clear_map", obj)}

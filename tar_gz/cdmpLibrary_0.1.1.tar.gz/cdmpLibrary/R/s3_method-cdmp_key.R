
#' S3 Method - Retrieve Internal Values from 'cdmp_key' object
#'
#' @param obj S3 Object of class 'cdmp_key'
#' @param name character
#'
#' @return R Object
#' @export
#'
#' @examples
#' \dontrun{
#' val <- get_elem(key, 'schema')
#' }
get_elem.cdmp_key <- function(obj, name) {

  # Validate Inputs
  if (missing(obj)) {stop("`obj` is missing in call to `get_elem.cdmp_key`")}
  if (missing(name)) {stop("`name` is missing in call to `get_elem.cdmp_key`")}

  # Validate Input Expectations

  # * `name`
  dbTools::expect_scalar_char(name)
  if (!isTRUE(name %in% c('schema', 'key', 'val'))) {
    stop("`name` must refer to element name of `obj` in call to `get_elem.cdmp_key`")
  }

  # Return Result
  return(obj[[name]])

}

#' S3 Method - Set Internal Values from 'cdmp_key' object
#'
#' @param obj S3 Object of class 'cdmp_key'
#' @param name character
#' @param value R Object
#'
#' @return TRUE
#' @export
#'
#' @examples
#' \dontrun{
#' set_elem(key, 'schema', 'nlsn')
#' }
set_elem.cdmp_key <- function(obj, name, value) {

  # Validate Inputs
  if (missing(obj)) {stop("`obj` is missing in call to `set_elem.cdmp_key`")}
  if (missing(name)) {stop("`name` is missing in call to `set_elem.cdmp_key`")}
  if (missing(value)) {stop("`value` is missing in call to `set_elem.cdmp_key`")}

  # Validate Input Expectations

  # * `name`
  dbTools::expect_scalar_char(name)
  if (!isTRUE(name %in% c('schema', 'key', 'val'))) {
    stop("`name` must refer to element name of `obj` in call to `set_elem.cdmp_key`")
  }

  # Set Value
  obj[[name]] <- value

  # Return Success
  invisible(TRUE)

}

#' S3 Method - Clear Existing Mappings for 'cdmp_key' object
#'
#' @param obj S3 Object of class 'cdmp_key'
#' @param map_order integer
#'
#' @return TRUE
#' @export
#'
#' @examples
#' \dontrun{
#' clear_map(key)
#' clear_map(key, 1)
#' clear_map(key, 2)
#' }
clear_map.cdmp_key <- function(obj, map_order) {

  # Validate Inputs
  if (missing(obj)) {stop("`obj` is missing in call to `clear_map.cdmp_key`")}
  if (missing(map_order)) {map_order <- NA_real_}

  # Validate Inputs

  # * `obj`
  if (!isTRUE(inherits(obj, 'cdmp_key'))) {
    stop("`obj` must inherit from 'cdmp_key' in call to `clear_map.cdmp_key`")
  }
  stopifnot(isTRUE(validate_cdmp_key(obj, TRUE)))

  # * `map_order`
  if (!isTRUE(identical(NA_real_, map_order))) {
    dbTools::expect_data_type(map_order, 'numeric', TRUE, TRUE, FALSE)
    if (!isTRUE(map_order %% 1 == 0) || !isTRUE(map_order > 0)) {
      stop("`map_order` must be whole integer in call to `clear_map.cdmp_key`")
    }
  }

  # Setup Connection to Competitor Mapping Library
  conn <- dbTools::psql_db_connect('comp_map_lib')

  # Initialize Environment to hold elements of `obj$val`
  val_env <- new.env()
  for (x in names(obj$val)) {val_env[[x]] <- obj$val[[x]]}

  # Generate WHERE Clause
  where_clause <- paste0(
    paste0(names(obj$val), ' = {', names(obj$val), '}'),
    collapse = '\nand '
  )
  where_clause <- paste0('where ', where_clause)
  where_clause <- glue::glue_data_sql(val_env, where_clause, .con = conn)

  # Generate UPDATE Statement
  update_clause <- paste('UPDATE {schema}.{key}', 'SET map_hash = NULL', sep = '\n')
  update_stmt <- glue::glue(paste(update_clause, where_clause, sep = '\n'), schema = obj$schema, key = obj$key)

  # Execute UPDATE Statement
  DBI::dbExecute(conn, update_stmt)

  # Close Connection to Competitor Mapping Library
  DBI::dbDisconnect(conn)
  rm(conn)

  # Return Result
  invisible(TRUE)

}


#' S3 Method - Retrieve Internal Values from 'cdmp_map' object
#'
#' @param obj S3 Object of class 'cdmp_map'
#' @param name character
#'
#' @return R Object
#' @export
#'
#' @examples
#' \dontrun{
#' val <- get_elem(key, 'schema')
#' }
get_elem.cdmp_map <- function(obj, name) {

  # Validate Inputs
  if (missing(obj)) {stop("`obj` is missing in call to `get_elem.cdmp_map`")}
  if (missing(name)) {stop("`name` is missing in call to `get_elem.cdmp_map`")}

  # Validate Input Expectations

  # * `name`
  dbTools::expect_scalar_char(name)
  if (!isTRUE(name %in% c('key', 'item_pos'))) {
    stop("`name` must refer to element name of `obj` in call to `get_elem.cdmp_map`")
  }

  # Return Result
  return(obj[[name]])

}

#' S3 Method - Set Internal Values from 'cdmp_map' object
#'
#' @param obj S3 Object of class 'cdmp_map'
#' @param name character
#' @param value R Object
#'
#' @return TRUE
#' @export
#'
#' @examples
#' \dontrun{
#' set_elem(key, 'schema', 'nlsn')
#' }
set_elem.cdmp_map <- function(obj, name, value) {

  # Validate Inputs
  if (missing(obj)) {stop("`obj` is missing in call to `set_elem.cdmp_map`")}
  if (missing(name)) {stop("`name` is missing in call to `set_elem.cdmp_map`")}
  if (missing(value)) {stop("`value` is missing in call to `set_elem.cdmp_map`")}

  # Validate Input Expectations

  # * `name`
  dbTools::expect_scalar_char(name)
  if (!isTRUE(name %in% c('key', 'item_pos'))) {
    stop("`name` must refer to element name of `obj` in call to `set_elem.cdmp_map`")
  }

  # Set Value
  obj[[name]] <- value

  # Return Success
  invisible(TRUE)

}

#' S3 Method - Clear Existing Mappings for 'cdmp_map' object
#'
#' @param obj S3 Object of class 'cdmp_map'
#' @param map_order integer
#'
#' @return TRUE
#' @export
#'
#' @examples
#' \dontrun{
#' clear_map(map)
#' clear_map(map, 1)
#' clear_map(map, 2)
#' }
clear_map.cdmp_map <- function(obj, map_order) {

  # Validate Inputs
  if (missing(obj)) {stop("`obj` is missing in call to `clear_map.cdmp_map`")}
  if (missing(map_order)) {map_order <- NA_real_}

  # Validate Inputs

  # * `obj`
  if (!isTRUE(inherits(obj, 'cdmp_map'))) {
    stop("`obj` must inherit from 'cdmp_map' in call to `clear_map.cdmp_map`")
  }
  stopifnot(isTRUE(validate_cdmp_map(obj, TRUE)))

  # * `map_order`
  if (!isTRUE(identical(NA_real_, map_order))) {
    dbTools::expect_data_type(map_order, 'numeric', TRUE, TRUE, FALSE)
    if (!isTRUE(map_order %% 1 == 0) || !isTRUE(map_order > 0)) {
      stop("`map_order` must be whole integer in call to `clear_map.cdmp_map`")
    }
  }

  # Call 'clear_map.cdmp_key'
  clear_map.cdmp_key(obj$key, map_order)

}

#' S3 Method - Upload Mapping Defined by 'cdmp_map' object
#'
#' @param obj S3 Object of class 'cdmp_map'
#' @param map_order integer
#'
#' @return TRUE
#' @export
#'
#' @examples
#' \dontrun{
#' update_map(map)
#' update_map(map, 1)
#' update_map(map, 2)
#' }
update_map.cdmp_map <- function(obj, map_order) {

  # Validate Inputs
  if (missing(obj)) {stop("`obj` is missing in call to `update_map.cdmp_map`")}
  if (missing(map_order)) {map_order <- 1}

  # Validate Input Expectations

  # * `obj`
  if (!isTRUE(inherits(obj, 'cdmp_map'))) {
    stop("`obj` must inherit from 'cdmp_map' in call to `update_map.cdmp_map`")
  }
  stopifnot(isTRUE(validate_cdmp_map(obj, TRUE)))

  # * `map_order`
  dbTools::expect_data_type(map_order, 'numeric', TRUE, TRUE, FALSE)
  if (!isTRUE(map_order %% 1 == 0) || !isTRUE(map_order > 0)) {
    stop("`map_order` must be whole integer in call to `update_map.cdmp_map`")
  }

  # Upsert `obj$item_pos`
  map_hash <- upsert_item_pos.cdmp_item_pos(obj$item_pos)

  # Setup Connection to Competitor Mapping Library
  conn <- dbTools::psql_db_connect('comp_map_lib')

  # Initialize Environment to hold elements of `obj$val`
  val_env <- new.env()
  for (x in names(obj$key$val)) {val_env[[x]] <- obj$key$val[[x]]}
  val_env[['map_order']] <- map_order

  # Generate WHERE Clause
  where_clause <- paste0(
    paste0(names(val_env), ' = {', names(val_env), '}'),
    collapse = '\nand '
  )
  where_clause <- paste0('where ', where_clause)
  where_clause <- glue::glue_data_sql(val_env, where_clause, .con = conn)

  # Generate UPDATE Statement
  update_clause <- paste('UPDATE {schema}.{key}', "SET map_hash = '{map_hash}'", sep = '\n')
  update_stmt <- glue::glue(
    paste(update_clause, where_clause, sep = '\n'),
    schema = obj$key$schema,
    key = obj$key$key
  )

  # Execute UPDATE Statement
  DBI::dbExecute(conn, update_stmt)

  # Close Connection to Competitor Mapping Library
  DBI::dbDisconnect(conn)
  rm(conn)

  # Return Success
  return(TRUE)

}


#' S3 Method - Load File into S3 Object of class 'cdmp_shop_data'
#'
#' @importFrom rlang .data
#'
#' @param obj S3 Object of class 'cdmp_shop_data'
#' @param name character - name of file
#' @param data data.frame - tabluar data
#'
#' @return NULL
#' @export
#'
load_file.cdmp_shop_data <- function(obj, name, data) {

  tryCatch({

    if (isTRUE(expect_scalar_char(name))) {obj$file <- name}
    if (isTRUE(expect_data_frame(data))) {
      obj$data <- data
      obj$data$`_ORIG_ROW_NUMBER_` <- 1:nrow(obj$data)
      obj$data <- obj$data %>% dplyr::relocate(.data$`_ORIG_ROW_NUMBER_`)
    }

  }, error = function(e) {

    obj$file <- NULL
    obj$data <- NULL
    message(sprintf("Error in %s: %s", deparse(e[["call"]]), e[["message"]]))

  })

}

#' S3 Method - Clear File Data from S3 Object of class 'cdmp_shop_data'
#'
#' @param obj S3 Object of class 'cdmp_shop_data'
#'
#' @return NULL
#' @export
#'
clear_file.cdmp_shop_data <- function(obj) {

  obj$file <- NULL
  obj$data <- NULL

}

#' S3 Method - Set Key Values for S3 Object of class 'cdmp_shop_data'
#'
#' @param obj S3 Object of class 'cdmp_shop_data'
#' @param key list - named list of keys and their desrired values
#'
#' @return NULL
#' @export
#'
#' @examples
#' \dontrun{
#' set_key(nielsen_wine, list(upc_num = c(upc = 'UPC'), upc_text = c(upc = 'UPC')))
#' }
set_key.cdmp_shop_data <- function(obj, key) {

  # Validate Inputs
  if (missing(key)) {stop("`key` is missing in call to `set_key.cdmp_shop_data`", call. = FALSE)}
  expect_list(obj = key, type = 'character')

  # Validate 'obj$key'
  is_valid_shop_key <- isTRUE(validate_cdmp_shop_key(obj$key, bool = TRUE))
  if (!isTRUE(is_valid_shop_key)) {
    stop("`obj$key` is not a valid 'cdmp_shop_key' in call to `set_key.cdmp_shop_data`", call. = FALSE)
  }

  # Generate New Template Values
  new_template <- validate_template.cdmp_shop_key(obj$key, x = key)

  # Validate Template Values against 'obj$data'
  for (new_elem in names(new_template)) {
    col_exist <- isTRUE(all(new_template[[new_elem]] %in% colnames(obj$data)))
    if (!isTRUE(col_exist)) {
      stop("`key` values must be columns in `obj$data` in call to `set_key.cdmp_shop_data`", call. = FALSE)
    }
  }

  # Load New Template Values
  for (new_elem in names(new_template)) {
    obj$key$template[[new_elem]] <- new_template[[new_elem]]
  }

}


#' S3 Method - Clear Key Values for S3 Object of class 'cdmp_shop_data'
#'
#' @param obj S3 Object of class 'cdmp_shop_data'
#' @param key character - vector of key names to clear
#'
#' @return NULL
#' @export
#'
clear_key.cdmp_shop_data <- function(obj, key) {

  if (missing(key)) {stop("`key` is missing in call to `clear_key.cdmp_shop_data`", call. = FALSE)}
  expect_data_type(obj = key, type = 'character', nz_len = TRUE)

  # Validate 'obj$key'
  is_valid_shop_key <- isTRUE(validate_cdmp_shop_key(obj$key, bool = TRUE))
  if (!isTRUE(is_valid_shop_key)) {
    stop("`obj$key` is not a valid 'cdmp_shop_key' in call to `set_key.cdmp_shop_data`", call. = FALSE)
  }

  delete_keys <- unique(intersect(key, names(obj$key$template)))
  for (delete_key in delete_keys) {
    obj$key$template[[delete_key]] <- NULL
  }

}

#' S3 Method - Set Shop Party Value for S3 Object of class 'cdmp_shop_data'
#'
#' @param obj S3 Object of class 'cdmp_shop_data'
#' @param shop_party character - desired shop party
#'
#' @return NULL
#' @export
#'
set_shop_party.cdmp_shop_data <- function(obj, shop_party) {

  if (missing(shop_party)) {stop("`shop_party` is missing in call to `set_shop_party.cdmp_shop_data`", call. = FALSE)}
  expect_scalar_char(obj = shop_party)

  obj$shop_party <- shop_party

}

#' S3 Method - Clear Shop Party Value for S3 Object of class 'cdmp_shop_data'
#'
#' @param obj S3 Object of class 'cdmp_shop_data'
#'
#' @return NULL
#' @export
#'
clear_shop_party.cdmp_shop_data <- function(obj) {

  obj$shop_party <- NULL

}

#' S3 Method - Set Competitor Value for S3 Object of class 'cdmp_shop_data'
#'
#' @param obj S3 Object of class 'cdmp_shop_data'
#' @param competitor character - specified column in 'obj$data' indicating competitor
#'
#' @return NULL
#' @export
#'
set_competitor.cdmp_shop_data <- function(obj, competitor) {

  if (missing(competitor)) {stop("`competitor` is missing in call to `set_competitor.cdmp_shop_data`", call. = FALSE)}
  expect_scalar_char(obj = competitor)

  # Validate 'competitor' is a column in 'obj$data'
  if (!isTRUE(competitor %in% colnames(obj$data))) {
    stop("`competitor` must be member of `colnames(obj$data)` in call to `set_competitor.cdmp_shop_data`", call. = FALSE)
  }

  obj$competitor <- competitor

}

#' S3 Method - Clear Competitor Value for S3 Object of class 'cdmp_shop_data'
#'
#' @param obj S3 Object of class 'cdmp_shop_data'
#'
#' @return NULL
#' @export
#'
clear_competitor.cdmp_shop_data <- function(obj) {

  obj$competitor <- NULL

}

#' S3 Method - Clear Key Values for S3 Object of class 'cdmp_shop_data'
#'
#' @importFrom rlang .data
#'
#' @param obj S3 Object of class 'cdmp_shop_data'
#'
#' @return NULL
#' @export
#'
generate_shop_key.cdmp_shop_data <- function(obj) {

  # Validate 'obj$data'
  expect_data_frame(df = obj$data)

  # Validate 'obj$key'
  is_valid_shop_key <- isTRUE(validate_cdmp_shop_key(obj$key, bool = TRUE))
  if (!isTRUE(is_valid_shop_key)) {
    stop("`obj$key` is not a valid 'cdmp_shop_key' in call to `generate_shop_key.cdmp_shop_data`", call. = FALSE)
  }

  generate_key.cdmp_shop_key(obj$key, obj$data, obj$competitor)

}

#' S3 Method - Map Key Values for S3 Object of class 'cdmp_shop_data'
#'
#' @param obj S3 Object of class 'cdmp_shop_data'
#'
#' @return NULL
#' @export
#'
map_shop_key.cdmp_shop_data <- function(obj) {

  expect_scalar_char(obj$shop_party)

  if (!isTRUE(validate_cdmp_shop_data(obj = obj, bool = TRUE))) {
    stop("`obj` must be a valid `cdmp_shop_data` in call to `map_shop_key.cdmp_shop_data`", call. = FALSE)
  }

  map_key.cdmp_shop_key(obj = obj$key, shop_party = obj$shop_party, competitor = obj$competitor)

}

#' S3 Method - Upsert Key Values for S3 Object of class 'cdmp_shop_data'
#'
#' @param obj S3 Object of class 'cdmp_shop_data'
#'
#' @return NULL
#' @export
#'
upsert_shop_key <- function(obj) {

  expect_scalar_char(obj$shop_party)

  if (!isTRUE(validate_cdmp_shop_data(obj = obj, bool = TRUE))) {
    stop("`obj` must be a valid `cdmp_shop_data` in call to `upsert_shop_key.cdmp_shop_data`", call. = FALSE)
  }

  upsert_key.cdmp_shop_key(obj = obj$key, shop_party = obj$shop_party)

}


#' S3 Generic - Create New Entry in 'db_projects'
#'
#' @param obj S3 Class
#' @param ... ellipsis
#'
#' @return TRUE
#' @export
#'
db_proj_create <- function(obj, ...) {UseMethod("db_proj_create", obj)}

#' S3 Generic - Select Existing Entry in 'db_projects'
#'
#' @param obj S3 Class
#' @param ... ellipsis
#'
#' @return TRUE
#' @export
#'
db_proj_select <- function(obj, ...) {UseMethod("db_proj_select", obj)}

#' S3 Generic - Update Existing Entry in 'db_projects'
#'
#' @param obj S3 Class
#' @param ... ellipsis
#'
#' @return TRUE
#' @export
#'
db_proj_update <- function(obj, ...) {UseMethod("db_proj_update", obj)}

#' S3 Generic - Delete Existing Entry in 'db_projects'
#'
#' @param obj S3 Class
#' @param ... ellipsis
#'
#' @return TRUE
#' @export
#'
db_proj_delete <- function(obj, ...) {UseMethod("db_proj_delete", obj)}

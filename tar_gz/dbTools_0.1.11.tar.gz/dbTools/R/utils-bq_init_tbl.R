
#' Constructs an S3 object of class 'bq_table', used to refer to a BigQuery Table
#'
#' @param dataset character - Name of BigQuery dataset containing the table to be referenced
#' @param table character - Name of table to be referenced
#'
#' @return S3 Object of class 'bq_table'
#' @export
#'
bq_init_tbl <- function(dataset, table) {

  # Validate Inputs
  if (missing(dataset)) {stop("`dataset` is missing in call to `bq_init_tbl`", call. = FALSE)}
  if (missing(table)) {stop("`table` is missing in call to `bq_init_tbl`", call. = FALSE)}

  # Validate Expectations
  dbTools::expect_scalar_char(dataset)
  dbTools::expect_scalar_char(table)

  # Initialize `bq_table` object
  bq_tbl <- bigrquery::bq_table(
    project = "twm-edap-prod-1802",
    dataset = dataset,
    table = table
  )

  # Return `bq_table` object
  return(bq_tbl)

}

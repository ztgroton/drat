
#' Group Row Numbers of a SQL Table by Columns
#'
#' @importFrom rlang .data
#'
#' @param conn DBI Connection
#' @param schema character
#' @param table character
#' @param columns character
#'
#' @return data.frame
#' @export
#'
sql_col_nest <- function(conn, schema, table, columns) {

  # Validate Inputs
  if (missing(conn)) {stop("`conn` is missing in call to `sql_col_nest`", call. = FALSE)}
  if (missing(schema)) {stop("`schema` is missing in call to `sql_col_nest`", call. = FALSE)}
  if (missing(table)) {stop("`table` is missing in call to `sql_col_nest`", call. = FALSE)}
  if (missing(columns)) {stop("`columns` is missing in call to `sql_col_nest`", call. = FALSE)}

  # Validate Expectations
  expect_dbi(conn)
  expect_scalar_char(schema)
  expect_scalar_char(table)
  expect_data_type(obj = columns, type = 'character', nz_len = TRUE)

  # Initialize Table Id
  if (isTRUE(inherits(conn, "BigQueryConnection"))) {
    tbl_id <- glue::glue("{schema}.{table}")
  } else {
    tbl_id <- DBI::Id(schema = schema, table = table)
  }

  # Initialize Lazy Table
  tbl_lzy <- dplyr::tbl(conn, tbl_id)

  # Compute Results
  res <- tbl_lzy %>%
    dplyr::select(dplyr::all_of(columns)) %>%
    dplyr::mutate(row_num = row_number()) %>%
    dplyr::collect() %>%
    dplyr::group_by_at(columns) %>%
    dplyr::group_nest(.key = 'nest_row_num') %>%
    dplyr::ungroup() %>%
    dplyr::mutate(nest_row_cnt = purrr::map_dbl(.data$nest_row_num, function(x){ifelse(is.null(x), 0, nrow(x))}))

  # Return Results
  return(res)

}

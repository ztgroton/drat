
#' Validate if a set of columns 'pk' is a Primary Key on SQL Table 'x'
#'
#' @importFrom rlang .data
#'
#' @param conn DBI Connection
#' @param schema character
#' @param table character
#' @param columns character
#'
#' @return data.frame
#' @export
#'
sql_nest_pk <- function(conn, schema, table, columns) {

  # Validate Inputs
  if (missing(conn)) {stop("`conn` is missing in call to `sql_nest_pk`", call. = FALSE)}
  if (missing(schema)) {stop("`schema` is missing in call to `sql_nest_pk`", call. = FALSE)}
  if (missing(table)) {stop("`table` is missing in call to `sql_nest_pk`", call. = FALSE)}
  if (missing(columns)) {stop("`columns` is missing in call to `sql_nest_pk`", call. = FALSE)}

  # Execute `sql_col_nest`
  pk_nest <- sql_col_nest(conn = conn, schema = schema, table = table, columns = columns)

  # Return Result
  class(pk_nest) <- c(setdiff('sql_nest_pk', class(pk_nest)), class(pk_nest))
  return(pk_nest)

}

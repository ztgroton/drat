
#' S3 Generic - Summarize a Candidate Primary Key
#'
#' @param obj S3 Class 'nest_pk'
#'
#' @return data.frame
#' @export
#'
pk_summary <- function(obj) {UseMethod("pk_summary", obj)}

#' S3 Method - Summarize a Candidate Primary Key
#'
#' @importFrom rlang .data
#'
#' @param obj S3 Class 'nest_pk'
#'
#' @return list
#' @export
#'
pk_summary.nest_pk <- function(obj) {

  if (missing(obj)) {stop("`obj` is missing in call to `pk_summary.nest_pk`", call. = FALSE)}
  if (!isTRUE(inherits(obj, 'nest_pk'))) {
    stop("`obj` must inherit from 'nest_pk' in call to `pk_summary.nest_pk`", call. = FALSE)
  }

  # Calculate `unq_cnt`
  unq_cnt <- nrow(obj)

  # Calculate `row_cnt`
  if (!isTRUE('orig_row_cnt' %in% colnames(obj))) {
    stop("`orig_row_cnt` not found in `colnames(obj)` in call to `pk_summary.nest_pk`", call. = FALSE)
  }

  row_cnt <- sum(obj$orig_row_cnt)

  # Calculate `non_na_cnt`
  pk_cols <- setdiff(colnames(obj), c('orig_row_num', 'orig_row_cnt'))

  pk_cols_non_na <- lapply(pk_cols, function(x){
    purrr::map_lgl(obj[[x]], !isTRUE(is.null(.x)) && !isTRUE(is.na(.x)))
  })
  names(pk_cols_non_na) <- pk_cols

  pk_non_na <- purrr::reduce(pk_cols_non_na, `&`)
  non_na_cnt <- sum(as.numeric(pk_non_na))

  # Calculate `valid_cnt`
  valid_cnt <- obj %>% dplyr::filter(.data$orig_row_cnt == 1) %>% nrow()

  # Calculate `pk_score`
  pk_score <-  1 - (row_cnt - unq_cnt)/row_cnt

  # Return Result
  res <- list(
    unq_cnt = unq_cnt,
    non_na_cnt = non_na_cnt,
    row_cnt = row_cnt,
    valid_cnt = valid_cnt,
    pk_score = pk_score
  )

  return(res)

}

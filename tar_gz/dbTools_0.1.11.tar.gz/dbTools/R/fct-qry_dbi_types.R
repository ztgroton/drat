
#' List Columns to be returned by SQL Query, along with their 'DBI' and 'R' data types.
#'
#' @param conn DBIConnection - An open DBI connection to be searched.
#' @param qry character - SQL query to be executed
#'
#' @importFrom rlang .data
#'
#' @return data.frame - A data.frame with two columns: 'name' and 'rtype'
#' @export
#'
qry_dbi_types <- function(conn, qry) {

  # Validate Inputs

  # * `conn`
  if (missing(conn)) {stop("`conn` is missing in call to `qry_dbi_types`", call. = FALSE)}
  expect_dbi(conn)

  # * `qry`
  if (missing(qry)) {stop("`qry` is missing in call to `qry_dbi_types`", call. = FALSE)}
  expect_scalar_char(qry)

  # Build `qry` ----
  qry <- glue::glue_sql(qry, .con = conn)

  tryCatch({

    # Send Query to RDBMS
    rs <- DBI::dbSendQuery(conn, qry, immediate = FALSE)

    # Get Column Info
    colinfo <- DBI::dbColumnInfo(rs)

    # Query Empty Result Set Data-Frame
    empty_result <- DBI::dbFetch(rs, n = 0)

    # Clear Result
    DBI::dbClearResult(rs)

    # Gather `empty_dbi_types` : one name column and one data-type column
    empty_dbi_types <- purrr::map_chr(empty_result, ~ DBI::dbDataType(conn, .))
    names(empty_dbi_types) <- colnames(empty_result)

    # Gather `empty_r_types` : one name column and one data-type column
    empty_r_types <- purrr::map_chr(empty_result, ~ class(.)[1])
    names(empty_r_types) <- colnames(empty_result)

    # Add `rtype` and `dbitype` as new columns in `colinfo`
    colinfo <- colinfo %>%
      dplyr::mutate(rtype = purrr::map_chr(.data$name, ~ empty_r_types[[.]])) %>%
      dplyr::mutate(dbitype = purrr::map_chr(.data$name, ~ empty_dbi_types[[.]]))

    # Return Results
    result <- colinfo %>% dplyr::select(.data$name, .data$dbitype, .data$rtype)
    return(result)

  }, error = function(e) {
    message(sprintf("Error in %s: %s", deparse(e[["call"]]), e[["message"]]))
    return(NULL)
  })

}

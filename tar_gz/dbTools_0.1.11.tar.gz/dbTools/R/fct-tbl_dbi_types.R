
#' List Columns in table, along with their 'DBI' and 'R' data types.
#'
#' @param conn DBIConnection - An open DBI connection to be searched.
#' @param schema character - Name of schema to be searched, must be a length 1 non-na character vector.
#' @param table character - Name of table to be searched, must be a length 1 non-na character vector.
#'
#' @importFrom rlang .data
#'
#' @return data.frame - A data.frame with two columns: 'name' and 'rtype'
#' @export
#'
tbl_dbi_types <- function(conn, schema, table) {

  # Validate Inputs

  # * `conn`
  if (missing(conn)) {stop("`conn` is missing in call to `tbl_dbi_types`", call. = FALSE)}
  expect_dbi(conn)

  # * `schema`
  if (missing(schema)) {stop("`schema` is missing in call to `tbl_dbi_types`", call. = FALSE)}
  expect_scalar_char(schema)

  # * `table`
  if (missing(table)) {
    stop("`table` is missing in call to `tbl_dbi_types`", call. = FALSE)
  } else {
    expect_data_type(table, type = 'character', nz_len = TRUE)
  }

  # Build `table_id`
  table_id <- DBI::Id(schema = schema, table = table)

  # Build `qry` ----
  qry <- glue::glue_sql("select * from {`table_id`}", .con = conn)

  # Execute and Return
  qry_dbi_types(conn = conn, qry = qry)

}


#' List Columns for all tables in schema, along with their 'DBI' and 'R' data types.
#'
#' @param conn DBIConnection - An open DBI connection to be searched.
#' @param schema character - Name of schema to be searched, must be a length 1 non-na character vector.
#'
#' @return data.frame
#' @export
#'
get_tbl_dbi_types <- function(conn, schema) {

  # Validate Inputs

  # * `conn`
  if (missing(conn)) {stop("`conn` is missing in call to `tbl_dbi_types`", call. = FALSE)}
  expect_dbi(conn)

  # * `schema`
  if (missing(schema)) {stop("`schema` is missing in call to `tbl_dbi_types`", call. = FALSE)}
  expect_scalar_char(schema)

  # Build `tables`
  tables <- get_tables(conn = conn, schema = schema)

  cat(paste0("`Learning DBI Types - ` ", schema, " \n\n"))

  db_schema_tables <- purrr::pmap(
    list(tables$db, tables$schema, tables$table),
    function(db, sch, tbl) {

      cat(paste0(db, '-', sch, '-', tbl, '... '))
      tictoc::tic()
      res <- tbl_dbi_types(conn, sch, tbl)
      res$db <- db
      res$schema <- schema
      res$table <- tbl
      res <- res %>% dplyr::relocate(db, schema, table)
      tictoc::toc()
      res

    }
  )

  cat("Learning Complete\n\n")

  dplyr::bind_rows(db_schema_tables)

}

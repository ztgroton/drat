
#' Connect to EDAP PSQL Database as 'postgres'
#'
#' @param dbname character - Name of an existing database
#' @param package character - Name of R package to use for PSQL Driver
#'
#' @return DBIConnection - R Object handle for the newly opened connection
#' @export
#'
psql_db_connect <- function(dbname, package = 'RPostgres') {

  # Validate Inputs

  # * dbname
  if (missing(dbname)) {stop("`dbname` is missing in call to `psql_db_connect`", call. = FALSE)}
  expect_scalar_char(dbname)

  # * package
  if (missing(package)) {package <- 'RPostgres'}
  expect_scalar_char(package)

  valid_packages <- c('RPostgres', 'RPostgreSQL')
  if (!isTRUE(package %in% valid_packages)) {
    stop("`package` must equal 'RPostgres' or 'RPostgreSQL' in call to `psql_db_connect`", call. = FALSE)
  }

  # MAIN LOGIC

  # * config
  config <- config::get(file = system.file('conf/config.yml', package = 'dbTools'))

  # * driver
  if (isTRUE(package == 'RPostgres')) {
    driver <- RPostgres::Postgres()
  } else if (isTRUE(package == 'RPostgreSQL')) {
    driver <- RPostgreSQL::PostgreSQL()
  }

  # * conn_psql
  conn_psql <- DBI::dbConnect(
    drv = driver,
    dbname = dbname,
    host = config$psql_ip,
    user = 'postgres',
    password = config$postgres_pwd
  )

  return(conn_psql)

}

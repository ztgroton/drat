
#' Authenticate Google BigQuery Connection
#'
#' @param secret_path character
#'
#' @return TRUE
#' @export
#'
#' @examples
#' \dontrun{
#' gsql_auth(secret_path)
#' }
gsql_auth <- function(secret_path) {

  # Validate Inputs
  if (missing(secret_path)) {stop("`secret_path` is missing in call to `gsql_auth`")}

  # Validate Input Expectations

  # * `secret_path`
  if (!isTRUE(dir.exists(secret_path))) {
    stop("`secret_path` was not recognized as an existing directory in call to `gsql_auth`")
  }

  # Search for Authentication Token
  bqtoken <- list.files(path = secret_path)
  if (!isTRUE(file.exists(file.path(secret_path, bqtoken)))) {
    stop("`secret_path` does not contain any recognizable token in call to `gsql_auth`")
  }

  # Authenticate using Token
  bigrquery::bq_auth(token = bqtoken)

  # Return Success
  invisible(TRUE)

}

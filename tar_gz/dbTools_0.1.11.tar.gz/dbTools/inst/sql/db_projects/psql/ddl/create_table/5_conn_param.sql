
CREATE TABLE IF NOT EXISTS common.conn_param
(
  conn_id INTEGER NOT NULL,
  param TEXT NOT NULL,
  value TEXT NOT NULL,

  CONSTRAINT common_conn_param_pkey PRIMARY KEY (conn_id, param),
  CONSTRAINT common_conn_param_fkey1 FOREIGN KEY (conn_id) REFERENCES common.conn (id) ON UPDATE CASCADE ON DELETE RESTRICT
)

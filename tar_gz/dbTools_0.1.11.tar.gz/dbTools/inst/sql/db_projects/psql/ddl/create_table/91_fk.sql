
CREATE TABLE IF NOT EXISTS common.fk
(
  id SERIAL,
  tab_id INTEGER NOT NULL,
  name TEXT NOT NULL,

  CONSTRAINT common_fk_pkey PRIMARY KEY (id),
  CONSTRAINT common_fk_fkey1 FOREIGN KEY (tab_id) REFERENCES common.tab (id) ON UPDATE CASCADE ON DELETE RESTRICT,
  CONSTRAINT common_fk_unq1 UNIQUE (id, tab_id),
  CONSTRAINT common_fk_unq2 UNIQUE (tab_id, name)
)

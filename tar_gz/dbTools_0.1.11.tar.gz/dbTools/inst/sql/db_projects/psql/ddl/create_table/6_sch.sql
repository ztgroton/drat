
CREATE TABLE IF NOT EXISTS common.sch
(
  id SERIAL,
  conn_id INTEGER NOT NULL,
  name TEXT NOT NULL,

  CONSTRAINT common_sch_pkey PRIMARY KEY (id),
  CONSTRAINT common_sch_fkey1 FOREIGN KEY (conn_id) REFERENCES common.conn (id) ON UPDATE CASCADE ON DELETE RESTRICT
)


select distinct
catalog_name as db,
schema_name as schema
from information_schema.schemata
where schema_name NOT IN ('information_schema', 'pg_catalog')

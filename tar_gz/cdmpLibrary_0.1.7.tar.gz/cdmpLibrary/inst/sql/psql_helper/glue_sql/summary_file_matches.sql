
WITH record_match_agg AS
(
select
rml.key_hash,
rml.map_hash,
rml.file_hash,
count(rml.orig_row_num) as row_count

from upload_files.record_match_log rml

group by
rml.key_hash,
rml.map_hash,
rml.file_hash
)

select

rma.key_hash,
ml.key_jsonb,

rma.map_hash,
tm.twm_item_code,
tm.twm_position_key,

rma.file_hash,
fl.name as file_name,
fl.upload_dt,
rma.row_count

from record_match_agg rma

left outer join map_library.map_lib ml
on rma.key_hash = ml.key_hash

left outer join map_library.twm_map tm
on rma.map_hash = tm.map_hash

left outer join upload_files.file_log fl
on rma.file_hash = fl.file_hash

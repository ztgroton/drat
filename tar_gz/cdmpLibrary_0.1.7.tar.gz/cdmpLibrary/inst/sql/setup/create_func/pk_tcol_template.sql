
CREATE OR REPLACE FUNCTION public.pk_tcol_template(sch TEXT, tbl TEXT)
  RETURNS TEXT
  LANGUAGE PLPGSQL
AS $$
DECLARE

  pk_tcol_txt TEXT[];
  result TEXT;

BEGIN

  -- Call 'public.pk_tcol_columns'
  SELECT public.pk_tcol_columns(sch::TEXT, tbl::TEXT) INTO pk_tcol_txt;

  -- Convert Text Array into Comma-Separated String
  SELECT CONCAT(ARRAY_TO_STRING(pk_tcol_txt, ', '), ', ') INTO result;

  -- Return Result
  RETURN result;

END;
$$


CREATE OR REPLACE FUNCTION public.gen_twm_map_template(data TEXT)
  RETURNS TEXT
  LANGUAGE PLPGSQL
AS $$
DECLARE

  result TEXT;

BEGIN

  -- Build SELECT statement to generate key values
  result := CONCAT(
    'insert into map_library.twm_map (map_hash, twm_item_code, twm_position_key) '
    'select ',
    'encode(public.digest(CONCAT(t.twm_item_code::TEXT, ''-''::TEXT, t.twm_position_key::TEXT), ''sha256''), ''hex'') as map_hash, '
    't.twm_item_code, '
    't.twm_position_key ',
    format('from public.%I as t ', data::TEXT),
    'on conflict (map_hash) ',
    'do nothing '
  );

  -- Return Result
  RETURN result;

END;
$$


CREATE OR REPLACE FUNCTION public.col2hash(
  sch TEXT,
  tbl TEXT,
  t_prefix BOOLEAN DEFAULT FALSE,
  pk_only BOOLEAN DEFAULT FALSE,
  exclude_file_columns BOOLEAN DEFAULT FALSE,
  data_tbl TEXT DEFAULT NULL
)
  RETURNS TEXT
  LANGUAGE PLPGSQL
AS $$
DECLARE

  col_array_txt TEXT[];
  result TEXT;

BEGIN

  -- Call 'public.pk_tcol_columns'
  SELECT public.col2array(sch, tbl, t_prefix, pk_only, exclude_file_columns, data_tbl) INTO col_array_txt;

  -- Convert Text Array into Comma-Separated String
  SELECT CONCAT(ARRAY_TO_STRING(col_array_txt, ', ')) INTO result;

  -- Return Result
  RETURN result;

END;
$$

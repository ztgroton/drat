
CREATE OR REPLACE FUNCTION public.array_col_jsonb(
  col_val TEXT[],
  sch TEXT DEFAULT NULL,
  tbl TEXT DEFAULT NULL,
  log_tbl BOOLEAN DEFAULT TRUE
)
  RETURNS TEXT
  LANGUAGE PLPGSQL
AS $$
DECLARE

  tpcols TEXT[];
  result TEXT;

BEGIN

  -- Convert Text Array into Result Statement
  tpcols := ARRAY(
    SELECT CONCAT(''''::TEXT, id::TEXT, ''', '::TEXT, id::TEXT)::TEXT
    FROM unnest(col_val) as id
    ORDER BY id
  );

  IF (log_tbl = TRUE AND (sch IS NOT NULL) AND (tbl IS NOT NULL)) THEN
    tpcols := array_append(tpcols, CONCAT('''schema'', '''::TEXT, sch::TEXT, ''''::TEXT));
    tpcols := array_append(tpcols, CONCAT('''table'', '''::TEXT, tbl::TEXT, ''''::TEXT));
  END IF;

  -- Create JSONB Element Template from input Column text value
  SELECT CONCAT('jsonb_build_object('::TEXT, ARRAY_TO_STRING(tpcols, ', ')::TEXT, ')'::TEXT) INTO result;

  -- Return Result
  RETURN result;

END;
$$

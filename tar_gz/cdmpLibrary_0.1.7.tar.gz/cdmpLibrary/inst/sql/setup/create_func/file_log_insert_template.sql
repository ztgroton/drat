
CREATE OR REPLACE FUNCTION public.file_log_insert_template(file_hash TEXT, name TEXT, shop_party TEXT)
  RETURNS TEXT
  LANGUAGE PLPGSQL
AS $$
DECLARE

  result TEXT;

BEGIN

  -- Build SELECT statement to generate key values
  result := CONCAT(
    'insert into upload_files.file_log (file_hash, name, upload_dt, shop_party) ',
    'select '::TEXT,
    format('%L as file_hash, ', file_hash::TEXT)::TEXT,
    format('%L as name, ', name::TEXT)::TEXT,
    'clock_timestamp() as upload_dt, '::TEXT,
    format('%L as shop_party ', shop_party::TEXT)::TEXT
  )::TEXT;

  -- Return Result
  RETURN result;

END;
$$

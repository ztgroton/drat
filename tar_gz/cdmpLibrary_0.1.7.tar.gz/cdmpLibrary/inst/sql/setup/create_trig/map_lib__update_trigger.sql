
CREATE TRIGGER map_lib_{schema_val}_{table_val}_update_trig AFTER UPDATE 
ON {schema_val}.{table_val} REFERENCING OLD TABLE AS old_table NEW TABLE AS new_table
FOR EACH STATEMENT EXECUTE PROCEDURE public.log_map_lib();


CREATE TRIGGER map_lib_update_trigger_delete AFTER DELETE 
ON map_library.map_lib REFERENCING OLD TABLE AS old_table 
FOR EACH STATEMENT EXECUTE PROCEDURE public.log_map_lib_update();

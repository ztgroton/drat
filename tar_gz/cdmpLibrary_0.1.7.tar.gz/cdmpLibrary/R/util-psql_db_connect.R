
#' Connect to EDAP PSQL Database as 'postgres'
#'
#' @param dbname character - Name of an existing database
#'
#' @return DBIConnection - R Object handle for the newly opened connection
#' @export
#'
psql_db_connect <- function(dbname) {

  expect_scalar_char(dbname)

  config <- config::get(file = system.file('conf/config.yml', package = 'cdmpLibrary'))

  conn_psql <- DBI::dbConnect(
    RPostgreSQL::PostgreSQL(),
    dbname = dbname,
    host = config$psql_ip,
    user = 'postgres',
    password = config$postgres_pwd
  )

  return(conn_psql)

}

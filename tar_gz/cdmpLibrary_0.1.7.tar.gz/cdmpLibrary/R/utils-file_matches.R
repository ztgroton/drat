
#' Summarize File Matches by Key Hash across Upload Files
#'
#' @param use_dev logical
#'
#' @return data.frame
#' @export
#'
#' @examples
#' \dontrun{
#' output <- summary_file_matches()
#' }
summary_file_matches <- function(use_dev = FALSE) {

  # Validate Inputs ----
  if (missing(use_dev)) {use_dev <- FALSE}

  # Validate Input Expectations ----

  # * use_dev ----
  if (!isTRUE(identical(use_dev, TRUE)) && !isTRUE(identical(use_dev, FALSE))) {
    stop("`use_dev` must be TRUE/FALSE in call to `summary_file_matches`")
  }

  # MAIN LOGIC ----

  # Fetch Parametrized SQL Query
  qry <- readr::read_file(system.file('sql/psql_helper/glue_sql/summary_file_matches.sql', package = 'cdmpLibrary'))

  # Setup DB Connection
  if (isTRUE(identical(use_dev, TRUE))) {
    conn <- psql_db_connect('comp_map_lib_dev')
  } else {
    conn <- psql_db_connect('comp_map_lib_prod')
  }

  # Execute SQL / Fetch Results
  results <- DBI::dbGetQuery(conn, qry)

  # Close DB Connection
  DBI::dbDisconnect(conn)
  rm(conn)

  # Return Results
  return(results)

}

#' Search for Mapping Discrepancies in File Record Matches
#'
#' @param data data.frame
#' @param match_types character
#'
#' @return data.frame
#' @export
#'
#' @examples
#' \dontrun{
#' output <- diff_file_matches(data, match_types)
#' }
diff_file_matches <- function(data, match_types) {

  # Initialize Hard-Coded Column Names
  key_col <- 'key_hash'
  map_col <- 'twm_item_pos'

  # Validate Inputs ----
  if (missing(data)) {stop("`data` is missing in call to `diff_file_matches`")}
  if (missing(match_types)) {match_types <- c('item_name', 'upc_num', 'upc_text')}

  # Validate Input Expectations ----

  # * data ----
  if (!isTRUE(is.data.frame(data))) {
    stop("`data` must be data.frame in call to `diff_file_matches`")
  }

  # * match_types ----
  expected_columns <- c(
    paste(match_types, key_col, sep = '__'),
    paste(match_types, map_col, sep = '__')
  )

  if (!isTRUE(all(expected_columns %in% colnames(data)))) {
    stop("`colnames(data)` does not contain all expected columns in call to `diff_file_matches`")
  }

  # MAIN LOGIC ----

  # Initialize List of Pair-Wise Discrepancy Comparisons
  diff_pairs <- as.list(as.data.frame(combn(length(match_types), 2)))

  # Initialize 'file_columns'
  file_columns <- c('file_name', 'file_upload_dt', 'shop_party', 'orig_row_num')

  # Subset 'data' columns
  result <- data %>% dplyr::select_at(c(file_columns, expected_columns))

  # Iterate over 'diff_pairs'
  for (i in 1:length(diff_pairs)) {

    pair <- diff_pairs[[i]]

    match_type1 <- match_types[pair[1]]
    match_type2 <- match_types[pair[2]]
    diff_col_name <- paste(match_type1, 'vs', match_type2, sep = '__')

    col1 <- paste(match_type1, map_col, sep = '__')
    col2 <- paste(match_type2, map_col, sep = '__')

    val1 <- result[[col1]]
    val2 <- result[[col2]]

    result[[diff_col_name]] <- ifelse(
      !is.na(val1) & !is.na(val2),
      ifelse(val1 != val2, TRUE, FALSE),
      FALSE
    )

  }

  # Return Result
  return(result)

}

#' Resolve Mapping Discrepancies in File Record Matches
#'
#' @param data data.frame
#' @param match_types character
#'
#' @return data.frame
#' @export
#'
#' @examples
#' \dontrun{
#' output <- final_file_matches(data, match_types)
#' }
final_file_matches <- function(data, match_types) {

  # Initialize Hard-Coded Column Names
  key_col <- 'key_hash'
  map_col <- 'twm_item_pos'
  twm_name_col <- 'twm_name'

  # Validate Inputs ----
  if (missing(data)) {stop("`data` is missing in call to `final_file_matches`")}
  if (missing(match_types)) {match_types <- c('item_name', 'upc_num', 'upc_text')}

  # Validate Input Expectations ----

  # * data ----
  if (!isTRUE(is.data.frame(data))) {
    stop("`data` must be data.frame in call to `final_file_matches`")
  }

  # * match_types ----

  if (!isTRUE(length(match_types) == length(unique(match_types)))) {
    stop("`match_types` must only contain unique values in call to `final_file_matches`")
  }

  expected_columns <- c(
    paste(match_types, key_col, sep = '__'),
    paste(match_types, map_col, sep = '__'),
    paste(match_types, twm_name_col, sep = '__')
  )

  if (!isTRUE(all(expected_columns %in% colnames(data)))) {
    stop("`colnames(data)` does not contain all expected columns in call to `final_file_matches`")
  }

  # MAIN LOGIC

  # Initialize 'final mapping' columns
  result <- data %>%
    dplyr::mutate(
      final__match_type = NA,
      final__key_hash = NA,
      final__twm_item_pos = NA,
      final__twm_name = NA
    )

  # Build Final Matches / Iterate over 'match_types'
  for (x in match_types) {

    # Column Names for match type 'x'
    x_key_col <- paste(x, key_col, sep = '__')
    x_map_col <- paste(x, map_col, sep = '__')
    x_twm_name_col <- paste(x, twm_name_col, sep = '__')

    # Column Values for match type 'x'
    x_key_col_val <- result[[x_key_col]]
    x_map_col_val <- result[[x_map_col]]
    x_twm_col_val <- result[[x_twm_name_col]]

    # Conditionally Fill in 'final__match_type'
    result[['final__match_type']] <- ifelse(
      is.na(result[['final__match_type']]),
      x, result[['final__match_type']]
    )

    # Conditionally Fill in 'final__key_hash'
    result[['final__key_hash']] <- ifelse(
      is.na(result[['final__key_hash']]),
      x_key_col_val, result[['final__key_hash']]
    )

    # Conditionally Fill in 'final__twm_item_pos'
    result[['final__twm_item_pos']] <- ifelse(
      is.na(result[['final__twm_item_pos']]),
      x_map_col_val, result[['final__twm_item_pos']]
    )

    # Conditionally Fill in 'final__twm_name'
    result[['final__twm_name']] <- ifelse(
      is.na(result[['final__twm_name']]),
      x_twm_col_val, result[['final__twm_name']]
    )

    # Remove Superfluous Columns
    result[[x_map_col]] <- NULL
    result[[x_twm_name_col]] <- NULL

  }

  # Return Result
  return(result)

}

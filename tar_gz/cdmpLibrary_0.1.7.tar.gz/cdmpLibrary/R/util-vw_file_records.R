
#' Query Record-Level Library Matches for a Selected File
#'
#' @param file_hash character
#' @param use_dev logical
#'
#' @return data.frame
#' @export
#'
#' @examples
#' \dontrun{
#' output <- vw_file_records(file_hash, use_dev = TRUE)
#' }
vw_file_records <- function(file_hash, use_dev = FALSE) {

  # Validate Inputs ----
  if (missing(file_hash)) {stop("`file_hash` is missing in call to `vw_file_records`")}
  if (missing(use_dev)) {use_dev <- FALSE}

  # Validate Input Expectations ----

  # * file_hash ----
  if (
    !isTRUE(is.character(file_hash))
    || !isTRUE(length(file_hash) == 1)
    || isTRUE(is.na(file_hash))
  ) {
    stop("`file_hash` must be scalar character in call to `vw_file_records`")
  }

  # * use_dev ----
  if (!isTRUE(identical(use_dev, TRUE)) && !isTRUE(identical(use_dev, FALSE))) {
    stop("`use_dev` must be TRUE/FALSE in call to `vw_file_records`")
  }

  # MAIN LOGIC ----

  # Fetch Parametrized SQL Query
  qry <- readr::read_file(system.file('sql/psql_helper/glue_sql/file_hash_records.sql', package = 'cdmpLibrary'))

  # Setup DB Connection
  if (isTRUE(identical(use_dev, TRUE))) {
    conn <- psql_db_connect('comp_map_lib_dev')
  } else {
    conn <- psql_db_connect('comp_map_lib_prod')
  }

  # Bind `file_hash` input value to `qry`
  qry <- glue::glue_sql(qry, .con = conn)

  # Execute `qry` / Fetch Results
  results <- DBI::dbGetQuery(conn, qry)

  # Close DB Connection
  DBI::dbDisconnect(conn)
  rm(conn)

  # Unnest JSONB
  jsonb_df <- jsonb_to_frame(results$record_jsonb)

  # Append `jsonb_df` to `results`
  results$record_jsonb <- NULL
  results <- results %>% cbind(jsonb_df)

  # Return Results
  return(results)

}

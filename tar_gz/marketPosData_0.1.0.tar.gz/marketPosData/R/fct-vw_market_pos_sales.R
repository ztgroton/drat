
#' Pull Latest Market Sales Data from 'market_pos'
#'
#' @param markets character
#' @param dept character
#' @param shop_party character
#'
#' @return data.frame
#' @export
#'
#' @examples
#' \dontrun{
#' output <- vw_market_pos_sales(markets, dept, shop_party)
#' }
vw_market_pos_sales <- function(markets, dept, shop_party = 'NLSN') {

  # Validate Inputs ----
  if (missing(markets)) {stop("`markets` is missing in call to `vw_market_pos_sales`")}
  if (missing(dept)) {stop("`dept` is missing in call to `vw_market_pos_sales`")}
  if (missing(shop_party)) {shop_party <- 'NLSN'}

  # Validate Input Expectations ----

  # * markets ----
  if (
      !isTRUE(is.character(markets))
    || isTRUE(any(purrr::map_lgl(markets, function(t){isTRUE(is.null(t)) || isTRUE(is.na(t))})))
    || !isTRUE(length(markets) > 0)
  ) {
    stop("`markets` has invalid value in call to `vw_market_pos_sales`")
  }

  # * dept ----
  if (
       !isTRUE(is.character(dept))
    || !isTRUE(length(dept) == 1)
    || isTRUE(is.null(dept))
    || isTRUE(is.na(dept))
  ) {
    stop("`dept` has invalid value in call to `vw_market_pos_sales`")
  }

  # * shop_party ----
  if (
       !isTRUE(is.character(shop_party))
    || !isTRUE(length(shop_party) == 1)
    || isTRUE(is.null(shop_party))
    || isTRUE(is.na(shop_party))
  ) {
    stop("`shop_party` has invalid value in call to `vw_market_pos_sales`")
  }

  # MAIN LOGIC ----

  # Setup DB Connection
  conn <- dbTools::psql_db_connect('market_pos')

  # Fetch Parametrized SQL Query ----
  qry <- readr::read_file(system.file('sql/psql/dql/vw_market_pos_sales.sql', package = 'marketPosData'))

  # Bind Parameter Values to Query
  qry <- glue::glue_sql(qry, .con = conn)

  tryCatch({

    # Execute SQL / Fetch Results
    results <- DBI::dbGetQuery(conn, qry)

    # Close DB Connection
    DBI::dbDisconnect(conn)
    rm(conn)

  }, error = function(e) {

    # Close DB Connection
    DBI::dbDisconnect(conn)
    rm(conn)

    # Throw Error Message
    stop(sprintf("Error in %s: %s", deparse(e[["call"]]), e[["message"]]))

  })

  # Return Results
  return(results)

}

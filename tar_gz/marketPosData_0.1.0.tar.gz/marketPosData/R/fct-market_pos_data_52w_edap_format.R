
#' Pull Market Data from PSQL DB 'market_pos', returned in EDAP Upload Format
#'
#' @param upload_date POSIXct/Date - Specify earliest upload date
#'
#' @return data.frane
#' @export
#'
#' @examples
#' \dontrun{
#' results <- market_pos_data_52w_edap_format('2023-01-01')
#' }
market_pos_data_52w_edap_format <- function(upload_date) {

  # Validate Inputs
  if (missing(upload_date)) {stop("`upload_date` is missing in call to `market_pos_data_52w_edap_format`")}

  # Validate Input Expectations

  # * `upload_date`
  is_len1 <- isTRUE(length(upload_date) == 1)
  is_non_na <- isTRUE(!is.na(upload_date))
  is_date <- isTRUE(inherits(upload_date, 'POSIXct')) || isTRUE(inherits(upload_date, 'Date'))
  if (!is_len1 || !is_non_na || !is_date) {
    stop("`upload_date` must be DATE in call to `market_pos_data_52w_edap_format`")
  }

  # Setup Connection to PSQL DB 'market_pos'
  conn_market_pos <- dbTools::psql_db_connect('market_pos')

  # Fetch Query Template
  qry <- readr::read_file(system.file("sql/psql/dql/market_pos_data_52w_edap_format.sql", package = 'marketPosData'))

  # Fill in SQL Query Parameters
  qry <- glue::glue_sql(qry, upload_date_val = upload_date, .con = conn_market_pos)

  # Execute SQL Query / Fetch Results
  result <- DBI::dbGetQuery(conn_market_pos, qry)

  # Close Connection to PSQL DB 'market_pos'
  DBI::dbDisconnect(conn_market_pos)
  rm(conn_market_pos)

  # Return Results
  return(result)

}

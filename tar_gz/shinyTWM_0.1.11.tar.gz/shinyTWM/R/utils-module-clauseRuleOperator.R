
#' Shiny Module UI - `clauseRuleOperator`
#'
#' @import shiny
#' @import shinyWidgets
#'
#' @param id character - Unique identifier for module instance
#' @param type character - Reactive Expression
#'
#' @return R Shiny Tags
#' @export
#'
#' @examples
#' \dontrun{
#' clauseRuleOperator_ui('test', type)
#' }
clauseRuleOperator_ui <- function(id, type) {

  # Session Namespace
  ns <- NS(id)

  if ( length(intersect(type(), c("character", "factor"))) > 0 ) {
    tagList(
      pickerInput(
        ns("rule_operator_control"),
        label = NULL,
        multiple = FALSE,
        selected = '==',
        choices = c('==', '!='),
        width = '100%'
      )
    )
  } else if (length(intersect(type(), c("logical"))) > 0) {
    tagList(
      pickerInput(
        ns("rule_operator_control"),
        label = NULL,
        multiple = FALSE,
        selected = '==',
        choices = c('==', '!='),
        width = '100%'
      )
    )
  } else if ( length(intersect(type(), c("integer", "numeric"))) > 0 ) {
    tagList(
      pickerInput(
        ns("rule_operator_control"),
        label = NULL,
        multiple = FALSE,
        selected = '==',
        choices = c('==', '!=', '<', '>', '<=', '>=', 'BETWEEN'),
        width = '100%'
      )
    )
  } else if ( length(intersect(type(), c("POSIXct", "Date"))) > 0 ) {
    tagList(
      pickerInput(
        ns("rule_operator_control"),
        label = NULL,
        multiple = FALSE,
        selected = '==',
        choices = c('==', '!=', '<', '>', '<=', '>=', 'BETWEEN', 'IN DATE RANGE'),
        width = '100%'
      )
    )
  } else {
    tagList(
      HTML(type())
    )
  }

}

#' Shiny Module Server - `clauseRuleColumn`
#'
#' @param id character - Unique identifier for module instance
#'
#' @return R Shiny Reactive Expression
#' @export
#'
#' @examples
#' \dontrun{
#' x <- clauseRuleOperator('test')
#' }
clauseRuleOperator_server <- function(id) {

  moduleServer(id, function(input, output, session){

    # Session Namespace
    ns <- session$ns

    # ____________ ----
    # MODULE RETURN VALUE ----
    result <- shiny::reactive({

      req(input$rule_operator_control)

      # Return Selected Operator
      input$rule_operator_control

    })

    return(result)

    # _______________________ ----
    # END OF MODULE SERVER ----

  })

}

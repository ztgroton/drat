
#' shinyTable_ui
#'
#' @param id character - A non-na, length 1 character vector
#'
#' @importFrom shiny tags
#'
#' @return fluidPage - UI for Shiny Module 'shinyTable'
#' @export
shinyTable_ui <- function(id) {

  ns <- shiny::NS(id)

  shiny::fluidPage(

    tags$head(
      # Note the wrapping of the string in HTML()
      tags$style(shiny::HTML("

      .dataTables_scroll {
        overflow-x:scroll;
        white-space: nowrap;
        display: flex;
        flex-direction: column;
        transform: rotateX(180deg);
      }

      .dataTables_scrollBody {
        overflow: unset !important;
        white-space: nowrap;
        order:1;
        transform: rotateX(180deg);
      }

      .dataTables_scrollHead {
        overflow: unset !important;
        white-space: nowrap;
        z-index: 10;
        order:2;
        transform: rotateX(180deg);
      }

      label {
        display: table-cell;
        text-align: center;
        vertical-align: middle;
        padding-right: 5px;
      }

      .form-group {
        display: table-row;
      }

      div.col-sm-3 {
        padding: 0px !important;
      }

      label.control-label {
        white-space: nowrap !important;
      }

      div.shiny_twm_footer {
        display: flex !important;
        justify-content: space-between !important;
      }

      div.shiny_twm_footer_elem {
        display: flex !important;
        justify-content: space-between !important;
      }

      "))
    ),

    shiny::column(
      width = 3,
      shinyWidgets::dropMenu(

        shiny::actionButton(
          inputId = ns('filter_btn'),
          label = 'Filter',
          width = '100%',
          shiny::icon("filter")
        ),

        shiny::splitLayout(
          style = "width:100%",
          shiny::actionButton(
            ns('add_clause_btn'),
            "Add Filter",
            width = '100%',
            style = "font-weight:bold;"
          ),
          shiny::actionButton(
            ns('drop_clause_btn'),
            "Drop Filter",
            width = '100%',
            style = "font-weight:bold;"
          )
        ),

        tags$div(id = ns('rule_builder_ui_placeholder'), style = "width:100%")

      )
    ),

    shiny::column(
      width = 3,
      shinyWidgets::dropMenu(

        shiny::actionButton(
          inputId = ns('layout_btn'),
          label = 'Layout',
          width = '100%',
          shiny::icon("list")
        ),

        shiny::numericInput(
          inputId = ns('table_page_length'),
          label = 'Page - # of Rows', value = 10,
          min = 0, max = 100, step = 1
        ),

        shiny::splitLayout(
          shiny::actionButton(inputId = ns('table_page_prev'), "Prev Page", width = '100%'),
          shiny::actionButton(inputId = ns('table_page_next'), "Next Page", width = '100%')
        )

      )
    ),

    shiny::column(
      width = 3,
      shinyWidgets::dropMenu(

        shiny::actionButton(
          inputId = ns('config_btn'),
          label = 'Config',
          width = '100%',
          shiny::icon("gear")
        ),

        shiny::radioButtons(
          inputId = ns("multi_row_selection"),
          label = NULL,
          choiceNames = c('Multi-Row', 'Single Only'),
          choiceValues = c(TRUE, FALSE),
          selected = TRUE, inline = TRUE
        )

      )
    ),

    shiny::column(
      width = 3,
      shinyWidgets::dropMenu(

        shiny::actionButton(
          inputId = ns('export_btn'),
          label = 'Export',
          width = '100%',
          shiny::icon("paper-plane")
        ),

        shiny::uiOutput(ns('download_ui'))
      )
    ),

    shiny::column(
      width = 12,
      DT::DTOutput(ns('table'))

    )

  )

}

#' shinyTable_server
#'
#' @param id character - A non-na, length 1 character vector
#' @param data data.frame - A valid data.frame object to display as table.
#' @param col_exclude character - Optional list of column names to exclude from display.
#'
#' @importFrom rlang .data
#' @importFrom utils write.csv
#'
#' @return moduleServer - SERVER for Shiny Module 'shinyTable'
#' @export
shinyTable_server <- function(id, data, col_exclude) {

  shiny::moduleServer(
    id = id,
    function(input, output, session) {

      # Session Namespace ----
      ns <- session$ns

      # _____________________________________ ----
      # MODULE INPUT REACTIVE EXPRESSIONS ----

      # * colExclude() ----
      colExclude <- shiny::reactive({

        shiny::req(col_exclude())

        if (!isTRUE(is.character(col_exclude()))) {
          shinyWidgets::show_toast(
            title = "Invalid Column Exclusions!!!",
            type = "error",
            position = "bottom"
          )
        }
        else {
          return(col_exclude())
        }

      })

      # * tableData() ----
      tableData <- shiny::reactive({

        shiny::req(data())
        shiny::req(colExclude())

        if (!isTRUE(is.data.frame(data()))) {
          shinyWidgets::show_toast(
            title = "Invalid Data Table!!!",
            type = "error",
            position = "bottom"
          )
        }
        else {

          col_include <- setdiff(colnames(data()), colExclude())
          res <- data()[, c(col_include), drop = F]

          return(res)
        }

      })

      # _______________________________ ----
      # GLOBAL REACTIVE VALUES ----

      # * rb ----
      rb <- shiny::reactiveValues(
        clause_num = 0,
        clause_reactive_list = list()
      )

      # _______________________________ ----
      # GLOBAL REACTIVE EXPRESSIONS ----

      # * tablePageLength() ----
      tablePageLength <- shiny::reactive({

        shiny::req(input$table_page_length)
        return(input$table_page_length)

      })

      # * tableRowSelection() ----
      tableRowSelection <- shiny::reactive({

        shiny::req(input$multi_row_selection)

        if (isTRUE(input$multi_row_selection == "TRUE")) {
          return('multiple')
        } else {
          return('single')
        }

      })

      # * clauseReactive() ----
      clauseReactive <- shiny::reactive({

        if (isTRUE(length(rb$clause_reactive_list) > 0)) {

          res <- purrr::map(names(rb$clause_reactive_list), function(x) {
            return(rb$clause_reactive_list[[x]]())
          })
          names(res) <- names(rb$clause_reactive_list)

          return(res)

        } else {
          return(list())
        }

      })

      # * clauseReactiveVal() ----
      clauseReactiveVal <- shiny::reactive({

        req(tableData())
        req(clauseReactive())

        if (isTRUE(length(clauseReactive()) > 0)) {

          res <- purrr::map(names(clauseReactive()), function(x) {

            clause_x <- clauseReactive()[[x]]

            if (!isTRUE(is.null(clause_x$condition))) {
              eval_clause(
                df = tableData(),
                column = clause_x$column,
                operator = clause_x$operator,
                condition = clause_x$condition
              ) -> res_x
            } else {
              res_x <- NA
            }

            return(res_x)

          })

          names(res) <- names(clauseReactive())
          return(res)

        } else {
          return(list())
        }

      })

      # * clauseReactiveIndex() ----
      clauseReactiveIndex <- shiny::reactive({

        req(clauseReactiveVal())

        crNonNa <- !is.na(clauseReactiveVal())
        cVal <- clauseReactiveVal()
        clauseReactiveNonNa <- cVal[crNonNa]

        if (isTRUE(length(clauseReactiveNonNa) > 0)) {

          res <- purrr::reduce(clauseReactiveNonNa, `&`)
          return(res)

        } else {
          return(list())
        }

      })

      # * tableDataDisplayed() ----
      tableDataDisplayed <- shiny::reactive({

        req(clauseReactiveIndex())

        if (isTRUE(length(clauseReactiveIndex()) == 0)) {
          tableData()
        } else {
          tableData()[clauseReactiveIndex(), , drop = F]
        }

      }) %>%
        shiny::debounce(millis = 250)

      # _______________________________ ----
      # OBSERVE EVENTS ----

      # _______________________________ ----
      # OBSERVER EVENTS ----

      # * input$add_clause_btn ----
      observeEvent(input$add_clause_btn, {

        btn <- rb$clause_num + 1
        ui_id <- paste0('rb_clause_', btn)

        insertUI(
          selector = paste0('#', ns('rule_builder_ui_placeholder')),
          ui = clauseDynamic_ui(id = ns(ui_id))
        )

        rb$clause_num <- btn
        rb$clause_reactive_list[[ui_id]] <- clauseDynamic_server(
          id = ui_id,
          data = tableData
        )

      })

      # * input$drop_clause_btn ----
      observeEvent(input$drop_clause_btn, {

        if (length(rb$clause_reactive_list) > 0) {

          if (!is.null(rb$clause_num)) {
            removeUI(selector = paste0('#', ns(paste0('rb_clause_', rb$clause_num))))
            rb$clause_reactive_list[[paste0('rb_clause_', rb$clause_num)]] <- NULL
          }

          rb$clause_num <- max(rb$clause_num - 1, 0, na.rm = TRUE)

        }

      })

      # ____________ ----
      # OUTPUTS ----

      # * output$table ----
      output$table <- DT::renderDT(expr = {

        shiny::req(tableData())
        shiny::req(tablePageLength())
        shiny::req(tableRowSelection())

        DT::datatable(
          data = shiny::isolate(tableData()),
          rownames = TRUE,
          selection = tableRowSelection(),
          options = list(
            pageLength = tablePageLength(),
            scrollX = TRUE,
            scrollY = TRUE,
            dom = '<t><"shiny_twm_footer"<"shiny_twm_footer_elem"i><"shiny_twm_footer_elem"fr>>',
            #columnDefs = list(
            #  list(targets = c(0), visible = FALSE)
            #),
            initComplete = DT::JS(c(
              "function(settings, json){",
              "  var table = settings.oInstance.api();",
              "  var pageinfo = table.page.info();",
              "}"
            ))
          ),
          callback = DT::JS(c(
            paste0("$('#", ns('table_page_prev'), "').on('click', function(){", collapse = ''),
            "  table.page('previous').draw('page');",
            "});",

            paste0("$('#", ns('table_page_next'), "').on('click', function(){", collapse = ''),
            "  table.page('next').draw('page');",
            "});"
          ))
        )

      })

      # * table proxy ----
      proxy__table <- DT::dataTableProxy('table')

      # ** proxy update - 'tableDataDisplayed()' ----
      shiny::observeEvent(tableDataDisplayed(), {
        DT::replaceData(proxy__table, tableDataDisplayed(), resetPaging = FALSE, rownames = TRUE)
      }, ignoreNULL = TRUE, ignoreInit = TRUE)

      # * output$download_ui ----
      output$download_ui <- shiny::renderUI({

        cond <- isTRUE(is.data.frame(tableData()))

        if (isTRUE(cond)) {
          shiny::downloadButton(
            outputId = ns('download_btn'),
            label = 'Download Data'
          )
        }
        else {
          shiny::tagList(shiny::HTML("<b>NO DATA</b>"))
        }

      })

      # * output$download_btn ----
      output$download_btn <- shiny::downloadHandler(
        filename = function() {
          paste0('table_export_', gsub(' ', '_', Sys.time()), '.csv')
        },
        content = function(file) {
          write.csv(tableDataDisplayed(), file, row.names = FALSE, na = '')
        }
      )

      # ____________ ----
      # MODULE RETURN VALUE ----
      result <- shiny::reactive({

        # Fetch Selected Row(s)
        input$table_rows_selected

      })

      return(result)

      # _______________________ ----
      # END OF MODULE SERVER ----
    }
  )

}

#' Display R DataFrame in R Shiny Table
#'
#' @importFrom utils read.csv
#'
#' @param data data.frame
#' @param ... ellipsis
#'
#' @export
#'
#' @examples
#' \dontrun{
#' shinyTable(raw_data)
#' }
shinyTable <- function(data, ...) {

  # Validate Input
  if (missing(data)) {data <- read.csv(system.file("sample_data/RDS_Sample.csv", package = 'shinyTWM'))}

  # Validate Input Expectations
  if (!isTRUE(is.data.frame(data))) {
    stop("`data` must be 'data.frame' in call to `shinyTable`")
  }

  # * `ui`
  ui <- shiny::tagList(
    shiny::column(
      width = 12,
      shinyTable_ui('shinytable1')
    )
  )

  # * `server`
  server <- function(input, output, session) {

    raw_data <- shiny::reactive({data})
    raw_colnames <- shiny::reactive({colnames(data)})
    exclude_colnames <- shiny::reactive({c('Party', 'Channel')})

    selected_rows <- shinyTable_server(
      id = 'shinytable1',
      data = raw_data,
      col_exclude = exclude_colnames
    )

    #shiny::observe({print(selected_rows())})

  }

  shiny::shinyApp(ui, server, ...)

}


SELECT
datname as db_name
FROM pg_database
WHERE datname NOT IN ('cloudsqladmin', 'template0', 'template1', 'postgres')

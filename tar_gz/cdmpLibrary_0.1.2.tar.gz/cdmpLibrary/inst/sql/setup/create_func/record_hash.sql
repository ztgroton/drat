
CREATE OR REPLACE FUNCTION public.record_hash(sch TEXT, tbl TEXT)
  RETURNS TEXT
  LANGUAGE PLPGSQL
AS $$
DECLARE

  jsonb_txt TEXT;
  result TEXT;

BEGIN

  -- Insert Record Columns into Text Array
  SELECT public.record_jsonb(sch::TEXT, tbl::TEXT) INTO jsonb_txt;

  -- Create JSONB Element Template from input Column text value
  SELECT CONCAT('encode(public.digest('::TEXT, jsonb_txt::TEXT, '::TEXT, ''sha256''), ''hex'')'::TEXT) INTO result;

  -- Return Result
  RETURN result;

END;
$$


#' Returns ALL Current Mappings for a List of TWM Items
#'
#' @param items list
#'
#' @return data.frame
#' @export
#'
#' @examples
#' \dontrun{
#' output <- lookup_all_item_maps(items = input_twm_item_list)
#' }
lookup_all_item_maps <- function(items) {

  # Validate Inputs
  if (missing(items)) {stop("`items` is missing in call to `lookup_all_item_maps`")}

  # Validate Input Expectations

  # * items
  if (!isTRUE(is.list(items)) || !isTRUE(length(items) > 0)) {
    stop("`items` must be list of non-zero length in call to `lookup_all_item_maps`")
  }

  purrr::walk(items, function(item) {

    if (!isTRUE(is.list(item)) || !isTRUE(length(item) > 0)) {
      stop("`item` elements must be list of non-zero length in call to `lookup_all_item_maps`")
    }

    if (!isTRUE(identical(sort(names(item)), sort(c('item_code', 'position_key'))))) {
      stop("`names(item)` must be identical to c('item_code', 'position_key') in call to `lookup_all_item_maps`")
    }

  })

  # MAIN LOGIC

  # Iterate over 'items'
  res <- purrr::map(items, function(item) {

    return(lookup_all_maps(
      item_code = item$item_code,
      position_key = item$position_key
    ))

  })

  res <- purrr::reduce(res, `rbind`) %>%
    dplyr::distinct() %>%
    dplyr::arrange(
      .data$shop_party, .data$map_name, .data$item_code, .data$position_key
    )

  # Return Results
  return(res)

}

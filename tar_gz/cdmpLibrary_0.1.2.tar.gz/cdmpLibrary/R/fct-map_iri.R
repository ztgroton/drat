
#' Helper Function for Mapping IRI Data
#'
#' @param data data.frame - contains the raw data to be mapped
#' @param upc character - name of column containing UPCs
#' @param item_name character - name of column containing Item Names
#'
#' @return TRUE
#' @export
#'
#' @examples
#' \dontrun{
#' map_iri(raw_iri_data, 'UPC', 'ITEM')
#' }
map_iri <- function(data, upc, item_name) {

  # Validate Inputs
  if (missing(data)) {stop("`data` is missing in call to `map_iri`")}
  if (missing(upc)) {upc <- NULL}
  if (missing(item_name)) {item_name <- NULL}

  # Validate Input Expectations

  # * `data`
  if (!isTRUE(is.data.frame(data))) {
    stop("`data` must be type 'data.frame' in call to `map_iri`")
  }

  cat("IRI...\n\n")

  # Conditionally Call 'map_iri_upc'
  if (!isTRUE(is.null(upc))) {
    cat("UPC...\n")
    tictoc::tic()
    map_iri_upc(data = data, upc_col = upc)
    tictoc::toc()
  }

  # Conditionally Call 'map_iri_name'
  if (!isTRUE(is.null(item_name))) {
    cat("\nITEM NAME...\n")
    tictoc::tic()
    map_iri_name(data = data, name_col = item_name)
    tictoc::toc()
    cat("\n")
  }

  # Return Success
  invisible(TRUE)

}

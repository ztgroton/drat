
#' Initialize Table Contents for Common Table
#'
#' @param conn DBIConnection
#' @param schema character
#' @param table character
#'
#' @return TRUE
#' @export
#'
#' @examples
#' \dontrun{
#' init_table_data(conn = psql_conn, schema = 'map_library', table = 'competitor')
#' }
init_table_data <- function(conn, schema, table) {

  # Validate Inputs
  if (missing(conn)) {stop("`conn` is missing in call to `init_table_data`")}
  if (missing(schema)) {stop("`schema` is missing in call to `init_table_data`")}
  if (missing(table)) {stop("`table` is missing in call to `init_table_data`")}

  # Validate Input Expectations

  # * `conn`
  if (!isTRUE(inherits(conn, 'DBIConnection'))) {
    stop("`conn` must inherit from 'DBIConnection' in call to `init_table_data`")
  }

  # * `schema`
  if (!isTRUE(is.character(schema)) || !isTRUE(length(schema) == 1) || !isFALSE(is.na(schema))) {
    stop("`schema` must be Non-NA length 1 character vector in call to `init_table_data`")
  }

  # * `table`
  if (!isTRUE(is.character(table)) || !isTRUE(length(table) == 1) || !isFALSE(is.na(table))) {
    stop("`table` must be Non-NA length 1 character vector in call to `init_table_data`")
  }

  # Generate Initialization Data Path
  init_path <- system.file(paste0('sql/setup/table_data/', schema), package = 'cdmpLibrary')
  init_file_name <- paste0(table, '.rds')
  init_file_path <- file.path(init_path, init_file_name)

  # Fetch Initialization RDS Data
  init_data <- readRDS(init_file_path)

  # Initialize Destination Table Id
  dest_table <- DBI::Id(schema = schema, table = table)

  # Insert Archived Data into Destination Table
  dbx::dbxInsert(
    conn = conn,
    table = dest_table,
    records = init_data
  )

  # Return Success
  invisible(TRUE)

}

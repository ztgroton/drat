
#' Setup 'Common Table' Schema for Competitor Mapping Library
#'
#' @param dbname character - Name of existing PSQL Database
#'
#' @return TRUE
#'
#' @examples
#' \dontrun{
#' setup_common_schema('comp_map_lib')
#' }
setup_common_schema <- function(dbname) {

  # Validate Inputs
  if (missing(dbname)) {dbname <- 'comp_map_lib'}

  # Validate Input Expectations
  dbTools::expect_scalar_char(dbname)

  # Setup Connection
  conn <- dbTools::psql_db_connect(dbname)

  # SETUP SCHEMA

  # SETUP TABLES

  # * `common.competitor`
  cat("Creating `common.competitor`... ")
  create_competitor_table(conn)

  # * `common.twm_map`
  cat("Creating `common.twm_map`... ")
  create_twm_map_table(conn)

  # * `common.map_lib`
  cat("Creating `common.map_lib`... ")
  create_map_lib_table(conn)

  # * `common.map_lib_update`
  cat("Creating `common.map_lib_update`... ")
  create_map_lib_update_table(conn)

  # * `common.valid_key`
  cat("Creating `common.valid_key`... ")
  create_valid_key_table(conn)

  # * `common.valid_key_field`
  cat("Creating `common.valid_key_field`... ")
  create_valid_key_field_table(conn)

  # Close Connection
  DBI::dbDisconnect(conn)
  rm(conn)

  # Return Success
  return(TRUE)

}

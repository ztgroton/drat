
#' Enable PSQL Extension Module 'pgcrypto'
#'
#' @param conn DBIConnection
#'
#' @return TRUE
#' @export
#'
#' @examples
#' \dontrun{
#' setup_triggers(psql_conn)
#' }
setup_pgcrypto <- function(conn) {

  # Validate Inputs
  if (missing(conn)) {stop("`conn` is missing in call to `setup_pgcrypto`")}

  # Validate Input Expectations

  # * `conn`
  if (!isTRUE(inherits(conn, 'DBIConnection'))) {
    stop("`conn` must inherit from 'DBIConnection' in call to `setup_pgcrypto`")
  }

  # Add 'pgcrypto' extension module to DB
  suppressMessages({DBI::dbExecute(conn, "CREATE EXTENSION IF NOT EXISTS pgcrypto;")})

  # Return Success
  invisible(TRUE)

}

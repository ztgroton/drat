
#' Generate Shiny Widget based on Column
#'
#' @param column character
#' @param data data.frame
#' @param ns function
#'
#' @return Shiny Tags
#' @export
#'
#' @examples
#' \dontrun{
#' output <- gen_rule_column_control(column = 'ItemName', data = TWM_Items, ns = shiny::NS)
#' }
gen_rule_column_control <- function(column, data, ns) {

  # Validate Inputs
  if (missing(column)) {stop("`column` is missing in call to `get_rule_column_control`")}
  if (missing(data)) {stop("`data` is missing in call to `get_rule_column_control`")}
  if (missing(ns)) {ns <- get('shiny::NS', envir = parent.frame())}

  # Validate Input Expectations

  # * `data`
  if (!isTRUE(is.data.frame(data))) {
    stop("`data` must be a data.frame in call to `gen_rule_column_control`")
  }

  # * `column`
  if (!isTRUE(length(column) == 1) || !isTRUE(column %in% colnames(data))) {
    stop("`column` must be member of `colnames(data)` in call to `gen_rule_column_control`")
  }

  # * ns
  if (!isTRUE(is.function(ns))) {
    stop("`ns` must be a function (shiny::NS) in call to `gen_rule_column_control`")
  }

  # Calculate Data Type from `column`
  type <- class(data[[column]])[1]

  # Return Shiny Widget based on `type`
  if ( length(intersect(type, c("character", "factor"))) > 0 ) {
    pickerInput(
      ns("rule_operator_control"),
      label = NULL,
      multiple = FALSE,
      selected = '==',
      choices = c('==', '!='),
      width = '100%'
    )
  } else if (length(intersect(type, c("logical"))) > 0) {
    pickerInput(
      ns("rule_operator_control"),
      label = NULL,
      multiple = FALSE,
      selected = '==',
      choices = c('==', '!='),
      width = '100%'
    )
  } else if ( length(intersect(type, c("integer", "numeric"))) > 0 ) {
    pickerInput(
      ns("rule_operator_control"),
      label = NULL,
      multiple = FALSE,
      selected = '==',
      choices = c('==', '!=', '<', '>', '<=', '>=', 'BETWEEN'),
      width = '100%'
    )
  } else if ( length(intersect(type, c("POSIXct", "Date"))) > 0 ) {
    pickerInput(
      ns("rule_operator_control"),
      label = NULL,
      multiple = FALSE,
      selected = '==',
      choices = c('==', '!=', '<', '>', '<=', '>=', 'BETWEEN', 'IN DATE RANGE'),
      width = '100%'
    )
  } else {
    HTML(type)
  }

}

#' Generate Shiny Widget based on Column
#'
#' @param column character
#' @param data data.frame
#' @param operator character
#' @param ns function
#'
#' @return Shiny Tags
#' @export
#'
#' @examples
#' \dontrun{
#' output <- gen_rule_condition_control(column = 'ItemName', data = TWM_Items, ns = shiny::NS)
#' }
gen_rule_condition_control <- function(column, data, operator, ns) {

  # Validate Inputs
  if (missing(column)) {stop("`column` is missing in call to `gen_rule_condition_control`")}
  if (missing(data)) {stop("`data` is missing in call to `gen_rule_condition_control`")}
  if (missing(operator)) {stop("`operator` is missing in call to `gen_rule_condition_control`")}
  if (missing(ns)) {ns <- get('shiny::NS', envir = parent.frame())}

  # Validate Input Expectations

  # * `data`
  if (!isTRUE(is.data.frame(data))) {
    stop("`data` must be a data.frame in call to `gen_rule_condition_control`")
  }

  # * `column`
  if (!isTRUE(length(column) == 1) || !isTRUE(column %in% colnames(data))) {
    stop("`column` must be member of `colnames(data)` in call to `gen_rule_condition_control`")
  }

  # * `operator`
  if (!isTRUE(is.character(operator)) || !isTRUE(length(operator) == 1)) {
    stop("`operator` must be length 1 character in call to `gen_rule_condition_control`")
  }

  # * `ns`
  if (!isTRUE(is.function(ns))) {
    stop("`ns` must be a function (shiny::NS) in call to `gen_rule_condition_control`")
  }

  # Calculate Data Type from `column`
  type <- class(data[[column]])[1]

  if ( length(intersect(type, c("character", "factor"))) > 0 ) {

    shinyWidgets::virtualSelectInput(
      ns("rule_condition_control"),
      label = NULL,
      choices = sort(unique(data[[column]])),
      selected = NULL,
      multiple = TRUE,
      search = TRUE,
      width = '100%'
    )

  } else if ( length(intersect(type, c("logical"))) > 0 ) {

    pickerInput(
      ns("rule_condition_control"),
      label = NULL,
      selected = TRUE,
      choices = c(TRUE, FALSE),
      width = '100%'
    )

  } else if ( length(intersect(type, c("integer", "numeric"))) > 0 ) {

    if (operator == "BETWEEN") {

      numericRangeInput(
        ns("rule_condition_control"),
        label = NULL,
        value = c(0,10),
        width = '100%'
      )

    } else {

      numericInput(
        ns("rule_condition_control"),
        label = NULL,
        value = 0,
        width = '100%'
      )

    }

  } else if ( length(intersect(type, c("POSIXct", "Date"))) > 0 ) {

    if (operator == "BETWEEN") {

      dateRangeInput(
        ns("rule_condition_control"),
        label = NULL,
        start = "2023-01-01",
        end = "2023-12-31",
        width = '100%'
      )

    } else if (operator == "IN DATE RANGE") {

      splitLayout(
        style = 'width: 100%%',
        pickerInput(
          ns("rule_condition_control_1"),
          label = NULL,
          selected = 'During',
          choices = c('Before', 'During', 'After'),
          width = '100%'
        ),
        pickerInput(
          ns("rule_condition_control_2"),
          label = NULL,
          selected = 'Last',
          choices = c('Last', 'Next'),
          width = '100%'
        ),
        numericInput(
          ns("rule_condition_control_3"),
          label = NULL,
          value = 1,
          min = 1,
          step = 1,
          width = '100%'
        ),
        pickerInput(
          ns("rule_condition_control_4"),
          label = NULL,
          selected = 'Month(s)',
          choices = c('Day(s)', 'Week(s)', 'Month(s)', 'Year(s)'),
          width = '100%'
        )
      )

    } else {

      dateInput(
        ns("rule_condition_control"),
        label = NULL,
        value = "2023-01-01",
        width = '100%'
      )

    }

  } else {
    HTML(type)
  }

}

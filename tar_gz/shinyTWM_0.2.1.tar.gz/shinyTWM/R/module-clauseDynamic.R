
#' Shiny Module UI - `clauseDynamic`
#'
#' @import shiny
#' @import shinyWidgets
#'
#' @param id character - Unique identifier for module instance
#'
#' @return R Shiny Tags
#' @export
#'
#' @examples
#' \dontrun{
#' clauseDynamic_ui('clause1')
#' }
clauseDynamic_ui <- function(id) {

  # Session Namespace
  ns <- NS(id)

  tagList(

    tags$head(tags$style(
      HTML(readr::read_file(system.file(
        "app/www/custom_styles/clauseDynamic.css"
        , package = 'shinyTWM'
      )))
    )),

    div(
      id = id,
      style = "display: flex; flex-direction: row; width: 100%;",
      shiny::uiOutput(ns('rule_column_control'), style = "flex-grow: 2 !important; width: 100%;"),
      shiny::uiOutput(ns('rule_operator_control'), style = "flex-grow: 1 !important; flex-shrink: 2 !important; width: 100%;"),
      shiny::uiOutput(ns('rule_condition_control'), style = "flex-grow: 2 !important; width: 100%;")
    )

  )

}

#' Shiny Module Server - `clauseDynamic`
#'
#' @import shiny
#'
#' @param id character - Unique identifier for module instance
#' @param data data.frame
#'
#' @return R Shiny Tags
#' @export
#'
#' @examples
#' \dontrun{
#' clauseDynamic_ui('clause1', datacolumns)
#' }
clauseDynamic_server <- function(id, data) {

  moduleServer(id, function(input, output, session){

    # Session Namespace
    ns <- session$ns

    # _____________________________ ----
    # INPUT REACTIVE EXPRESSIONS ----

    # * tableData() ----
    tableData <- shiny::reactive({

      shiny::req(data())

      if (!isTRUE(is.data.frame(data()))) {
        shinyWidgets::show_toast(
          title = "`clauseDynamic_server` - Invalid Data Table!!!",
          type = "error",
          position = "bottom"
        )
      } else {
        return(data())
      }

    })

    # * tableColumns() ----
    tableColumns <- shiny::reactive({

      shiny::req(tableData())

      res <- colnames(tableData())
      res <- c('(none)', res)

      # Return `c('(none)', colnames(tableData()))`
      return(res)

    })

    # * tableColumnTypes() ----
    tableColumnTypes <- shiny::reactive({

      shiny::req(tableData())
      shiny::req(tableColumns())

      # Get Data Types for each Column
      types <- purrr::map_chr(tableData(), function(t){class(t)[1]})
      names(types) <- colnames(tableData())

      # Return Data Types
      return(types)

    })

    # _______________________________ ----
    # MODULE REACTIVE EXPRESSIONS ----

    # * selected_column_control ----
    selected_column_control <- reactive({

      req(input$rule_column_control)

      if (
           !isTRUE(is.null(input$rule_column_control))
        && !isTRUE(input$rule_column_control == '(none)')
      ) {
        return(input$rule_column_control)
      } else {
        return(NULL)
      }

    })

    # * selected_column_type ----
    selected_column_type <- reactive({

      req(selected_column_control())
      class(tableData()[[selected_column_control()]])[1]

    })

    # ________ ----
    # OUTPUTS ----

    # * output$rule_column_control ----
    output$rule_column_control <- renderUI({

      req(tableColumns())

      pickerInput(
        ns("rule_column_control"),
        label = NULL,
        multiple = FALSE,
        selected = tableColumns()[1],
        choices = sort(unique(as.character(tableColumns()))),
        options = pickerOptions(liveSearch = TRUE),
        width = '100%'
      )

    })

    # * output$rule_operator_control ----
    output$rule_operator_control <- renderUI({

      req(selected_column_control())
      req(selected_column_type())

      if ( length(intersect(selected_column_type(), c("character", "factor"))) > 0 ) {
        pickerInput(
          ns("rule_operator_control"),
          label = NULL,
          multiple = FALSE,
          selected = '==',
          choices = c('==', '!='),
          width = '100%'
        )
      } else if (length(intersect(selected_column_type(), c("logical"))) > 0) {
        pickerInput(
          ns("rule_operator_control"),
          label = NULL,
          multiple = FALSE,
          selected = '==',
          choices = c('==', '!='),
          width = '100%'
        )
      } else if ( length(intersect(selected_column_type(), c("integer", "numeric"))) > 0 ) {
        pickerInput(
          ns("rule_operator_control"),
          label = NULL,
          multiple = FALSE,
          selected = '==',
          choices = c('==', '!=', '<', '>', '<=', '>=', 'BETWEEN'),
          width = '100%'
        )
      } else if ( length(intersect(selected_column_type(), c("POSIXct", "Date"))) > 0 ) {
        pickerInput(
          ns("rule_operator_control"),
          label = NULL,
          multiple = FALSE,
          selected = '==',
          choices = c('==', '!=', '<', '>', '<=', '>=', 'BETWEEN', 'IN DATE RANGE'),
          width = '100%'
        )
      } else {
        HTML(selected_column_type())
      }

    })

    # * output$rule_condition_control ----
    output$rule_condition_control <- renderUI({

      req(selected_column_control())
      req(input$rule_operator_control)
      req(selected_column_type())

      if ( length(intersect(selected_column_type(), c("character", "factor"))) > 0 ) {

        shinyWidgets::virtualSelectInput(
          ns("rule_condition_control"),
          label = NULL,
          choices = sort(unique(tableData()[[selected_column_control()]])),
          selected = NULL,
          multiple = TRUE,
          search = TRUE,
          width = '100%'
        )

      } else if ( length(intersect(selected_column_type(), c("logical"))) > 0 ) {

        pickerInput(
          ns("rule_condition_control"),
          label = NULL,
          selected = TRUE,
          choices = c(TRUE, FALSE),
          width = '100%'
        )

      } else if ( length(intersect(selected_column_type(), c("integer", "numeric"))) > 0 ) {

        if (input$rule_operator_control == "BETWEEN") {

          numericRangeInput(
            ns("rule_condition_control"),
            label = NULL,
            value = c(0,10),
            width = '100%'
          )

        } else {

          numericInput(
            ns("rule_condition_control"),
            label = NULL,
            value = 0,
            width = '100%'
          )

        }

      } else if ( length(intersect(selected_column_type(), c("POSIXct", "Date"))) > 0 ) {

        if (input$rule_operator_control == "BETWEEN") {

          dateRangeInput(
            ns("rule_condition_control"),
            label = NULL,
            start = "2023-01-01",
            end = "2023-12-31",
            width = '100%'
          )

        } else if (input$rule_operator_control == "IN DATE RANGE") {

          splitLayout(
            style = 'width: 100%%',
            pickerInput(
              ns("rule_condition_control_1"),
              label = NULL,
              selected = 'During',
              choices = c('Before', 'During', 'After'),
              width = '100%'
            ),
            pickerInput(
              ns("rule_condition_control_2"),
              label = NULL,
              selected = 'Last',
              choices = c('Last', 'Next'),
              width = '100%'
            ),
            numericInput(
              ns("rule_condition_control_3"),
              label = NULL,
              value = 1,
              min = 1,
              step = 1,
              width = '100%'
            ),
            pickerInput(
              ns("rule_condition_control_4"),
              label = NULL,
              selected = 'Month(s)',
              choices = c('Day(s)', 'Week(s)', 'Month(s)', 'Year(s)'),
              width = '100%'
            )
          )

        } else {

          dateInput(
            ns("rule_condition_control"),
            label = NULL,
            value = "2023-01-01",
            width = '100%'
          )

        }

      } else {
        HTML(selected_column_type())
      }

    })

    # Module Reactive Result
    result_list <- reactive({

      req(selected_column_control())
      req(input$rule_operator_control)

      list(
        column = selected_column_control(),
        operator = input$rule_operator_control,
        condition = if (input$rule_operator_control == 'IN DATE RANGE') {
          paste(
            input$rule_condition_control_1,
            input$rule_condition_control_2,
            input$rule_condition_control_3,
            input$rule_condition_control_4,
            sep = " "
          )
        } else {
          input$rule_condition_control
        }
      )

    })

    return(result_list)

  })

}

#' Display R DataFrame Dynamic Clause
#'
#' @importFrom utils read.csv
#'
#' @param data data.frame
#' @param ... ellipsis
#'
#' @export
#'
#' @examples
#' \dontrun{
#' clauseDynamic(raw_data)
#' }
clauseDynamic <- function(data, ...) {

  # Validate Input
  if (missing(data)) {data <- read.csv(system.file("sample_data/RDS_Sample.csv", package = 'shinyTWM'))}

  # Validate Input Expectations
  if (!isTRUE(is.data.frame(data))) {
    stop("`data` must be 'data.frame' in call to `clauseDynamic`")
  }

  # * `ui`
  ui <- shiny::tagList(
    shiny::column(
      width = 12,
      clauseDynamic_ui('clauseDynamic1')
    )
  )

  # * `server`
  server <- function(input, output, session) {

    raw_data <- shiny::reactive({data})
    raw_colnames <- shiny::reactive({colnames(data)})

    selected_rows <- clauseDynamic_server(
      id = 'clauseDynamic1',
      data = raw_data
    )

    shiny::observe({print(selected_rows())})

  }

  shiny::shinyApp(ui, server, ...)

}

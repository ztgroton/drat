
CREATE OR REPLACE FUNCTION public.record_log_insert_template(tbl TEXT, file_hash TEXT)
  RETURNS TEXT
  LANGUAGE PLPGSQL
AS $$
DECLARE

  result TEXT;

BEGIN

  -- Build SELECT statement to generate key values
  result := CONCAT(
    'insert into upload_files.record_log (file_hash, orig_row_num, record_jsonb, record_hash) ',
    'select '::TEXT,
    format('%L as file_hash, ', file_hash::TEXT)::TEXT,
    't.orig_row_num, '::TEXT,
    public.record_jsonb('public'::TEXT, tbl::TEXT)::TEXT, ' as record_jsonb, ',
    public.record_hash('public'::TEXT, tbl::TEXT)::TEXT, ' as record_hash ',
    format('from public.%I t ', tbl::TEXT)
  )::TEXT;

  -- Return Result
  RETURN result;

END;
$$

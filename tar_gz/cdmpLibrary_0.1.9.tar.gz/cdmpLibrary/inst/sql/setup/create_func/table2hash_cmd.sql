
CREATE OR REPLACE FUNCTION public.table2hash_cmd(
  sch TEXT,
  tbl TEXT,
  pk_only BOOLEAN DEFAULT FALSE,
  exclude_file_columns BOOLEAN DEFAULT FALSE,
  data_tbl TEXT DEFAULT NULL,
  log_tbl BOOLEAN DEFAULT FALSE,
  comp TEXT DEFAULT NULL
)
  RETURNS TEXT
  LANGUAGE PLPGSQL
AS $$
DECLARE

  jsonb_txt TEXT;
  result TEXT;

BEGIN

  -- Call 'public.table2jsonb_cmd'
  SELECT public.table2jsonb_cmd(sch, tbl, pk_only, exclude_file_columns, data_tbl, log_tbl, comp) INTO jsonb_txt;

  -- Create JSONB Element Template from input Column text value
  SELECT CONCAT('encode(public.digest('::TEXT, jsonb_txt::TEXT, '::TEXT, ''sha256''), ''hex'')'::TEXT) INTO result;

  -- Return Result
  RETURN result;

END;
$$

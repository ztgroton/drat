
-- jsonb_template -> primary key support
-- pk_col_jsonb -> primary key support
-- record_jsonb -> EXCLUDED COLUMN support
-- tmp_col_jsonb -> 'competitor' support ,  'data' table support

CREATE OR REPLACE FUNCTION public.col2array(
  sch TEXT,
  tbl TEXT,
  t_prefix BOOLEAN DEFAULT FALSE,
  pk_only BOOLEAN DEFAULT FALSE,
  exclude_file_columns BOOLEAN DEFAULT FALSE,
  data_tbl TEXT DEFAULT NULL
)
  RETURNS TEXT[]
  LANGUAGE PLPGSQL
AS $$
DECLARE

  select_col TEXT;
  select_clause TEXT;
  where_clause TEXT;
  where_tbl TEXT;
  order_clause TEXT;

  join__pk_only TEXT := ''::TEXT;
  where__exclude_file_columns TEXT := ''::TEXT;

  result TEXT[];

BEGIN

  -- Initialize 'select_column'
  IF (t_prefix = TRUE) THEN
    select_col := CONCAT('  SELECT CONCAT(''t."'', c.column_name::TEXT, ''"'') ');
  ELSE
    select_col := CONCAT('  SELECT c.column_name::TEXT ');
  END IF;

  -- Initialize Top-Level Select Clause
  select_clause := CONCAT(
    select_col,
    '  ',
    '  FROM information_schema.columns c ',
    '  ',
    '  INNER JOIN information_schema.tables t ',
    '  ON t.table_name = c.table_name ',
    '  AND t.table_schema = c.table_schema ',
    '  AND t.table_catalog = c.table_catalog '
  );

  IF (data_tbl IS NOT NULL) THEN
    where_tbl := data_tbl;
  ELSE
    where_tbl := tbl;
  END IF;

  -- Initialize Top-Level Where Clause
  where_clause := format(
    CONCAT(
      '  WHERE c.table_schema = %L '
      '  AND c.table_name = %L '
      '  AND t.table_type = ''BASE TABLE'''
    ),
    sch::TEXT, where_tbl::TEXT
  );

  -- Initialize Order By Clause
  order_clause := CONCAT(
    '  ORDER BY t.table_schema, t.table_name, c.ordinal_position '
  );

  -- Conditionally Populate 'join__pk_only'
  IF (pk_only = TRUE) THEN

    join__pk_only := CONCAT(
    '  INNER JOIN  ', -- primary keys
    '  ( ',
    '    SELECT DISTINCT ',
    '    tc.constraint_name, tc.table_name, tc.table_schema, tc.table_catalog, kcu.column_name ',
    '    FROM information_schema.table_constraints AS tc ',
    '    JOIN information_schema.key_column_usage AS kcu ',
    '    ON tc.constraint_name = kcu.constraint_name ',
    '    WHERE constraint_type = ''PRIMARY KEY'' ',
    '  ) pk ',
    '  ON pk.table_name = c.table_name ',
    '  AND pk.column_name = c.column_name ',
    '  AND pk.table_schema = c.table_schema ',
    '  AND pk.table_catalog = c.table_catalog '
  );

  END IF;

  -- Conditionally Populate 'where__exclude_file_columns'
  IF (exclude_file_columns = TRUE) THEN

    where__exclude_file_columns := CONCAT(
      'AND UPPER(c.column_name) not like ''%ORIG_ROW_NUM%'' ',
      'AND UPPER(c.column_name) not like ''%FILE_HASH%'' '
    );

  END IF;

  -- Insert Primary Key Columns into Text Array
  EXECUTE CONCAT(
    'SELECT ARRAY( ',
      select_clause,
      '  ',
      join__pk_only,
      '  ',
      where_clause,
      where__exclude_file_columns,
      '  ',
      order_clause,
    ') '
  ) INTO result;

  -- Return Result
  RETURN result;

END;
$$

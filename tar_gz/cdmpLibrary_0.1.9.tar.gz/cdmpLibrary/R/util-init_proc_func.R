
#' Initialize Stored Functions for Competitive Mapping Library
#'
#' @param conn DBIConnection
#' @param preclean TRUE/FALSE
#'
#' @return TRUE
#' @export
#'
#' @examples
#' \dontrun{
#' init_func(psql_conn, preclean = FALSE)
#' }
init_func <- function(conn, preclean = FALSE) {

  # Validate Inputs
  if (missing(conn)) {stop("`conn` is missing in call to `init_func`", call. = FALSE)}
  if (missing(preclean)) {preclean <- FALSE}

  # * `conn`
  if (!isTRUE(inherits(conn, 'DBIConnection'))) {
    stop("`conn` must inherit from 'DBIConnection' in call to `init_func`", call. = FALSE)
  }

  if (!isTRUE(identical(preclean, TRUE)) && !isTRUE(identical(preclean, FALSE))) {
    stop("`preclean` must be TRUE/FALSE in call to `init_func`", call. = FALSE)
  }

  # Initialize `create_func_dir`
  create_func_dir <- system.file('sql/setup/create_func', package = 'cdmpLibrary')

  # Initialize `func_files`
  func_files <- gsub(
    pattern = '.sql',
    replacement = '',
    x = list.files(
      path = create_func_dir,
      pattern = '*.sql'
    ),
    fixed = TRUE
  )

  # Iterate over `func_files` / Execute SQL
  purrr::walk(func_files, function(proc_name) {

    # Optionally Preclean Routine
    if (isTRUE(preclean)) {drop_routine(conn, proc_name)}

    # Read SQL File
    func_sql <- readr::read_file(file.path(create_func_dir, paste0(proc_name, '.sql')))

    # Execute SQL File
    tryCatch({
      DBI::dbExecute(conn, func_sql)
    }, error = function(e) {
      message(sprintf("Error in %s: %s", deparse(e[["call"]]), e[["message"]]))
    })

  })

  # Return Success
  invisible(TRUE)

}

#' Initialize Stored Procedures for Competitive Mapping Library
#'
#' @param conn DBIConnection
#' @param preclean TRUE/FALSE
#'
#' @return TRUE
#' @export
#'
#' @examples
#' \dontrun{
#' init_proc(psql_conn, preclean = FALSE)
#' }
init_proc <- function(conn, preclean = FALSE) {

  # Validate Inputs
  if (missing(conn)) {stop("`conn` is missing in call to `init_proc`", call. = FALSE)}
  if (missing(preclean)) {preclean <- FALSE}

  # * `conn`
  if (!isTRUE(inherits(conn, 'DBIConnection'))) {
    stop("`conn` must inherit from 'DBIConnection' in call to `init_proc`", call. = FALSE)
  }

  if (!isTRUE(identical(preclean, TRUE)) && !isTRUE(identical(preclean, FALSE))) {
    stop("`preclean` must be TRUE/FALSE in call to `init_proc`", call. = FALSE)
  }

  # MAIN LOGIC

  # Initialize `create_proc_dir`
  create_proc_dir <- system.file('sql/setup/create_proc', package = 'cdmpLibrary')

  # Initialize `proc_files`
  proc_files <- gsub(
    pattern = '.sql',
    replacement = '',
    x = list.files(
      path = create_proc_dir,
      pattern = '*.sql'
    ),
    fixed = TRUE
  )

  # Iterate over `proc_files` / Execute SQL
  purrr::walk(proc_files, function(proc_name) {

    # Optionally Preclean Routine
    if (isTRUE(preclean)) {drop_routine(conn, proc_name)}

    # Read SQL File
    proc_sql <- readr::read_file(file.path(create_proc_dir, paste0(proc_name, '.sql')))

    # Execute SQL File
    tryCatch({
      DBI::dbExecute(conn, proc_sql)
    }, error = function(e) {
      message(sprintf("Error in %s: %s", deparse(e[["call"]]), e[["message"]]))
    })

  })

  # Return Success
  invisible(TRUE)

}

#' Create Defined Function in Competitive Mapping Library
#'
#' @param conn DBIConnection
#' @param proc_name character
#'
#' @return TRUE
#' @export
#'
#' @examples
#' \dontrun{
#' create_func(psql_conn, proc_name = 'testname')
#' }
create_func <- function(conn, proc_name) {

  # Validate Inputs
  if (missing(conn)) {stop("`conn` is missing in call to `create_func`", call. = FALSE)}
  if (missing(proc_name)) {stop("`proc_name` is missing in call to `create_func`", call. = FALSE)}

  # * `conn`
  if (!isTRUE(inherits(conn, 'DBIConnection'))) {
    stop("`conn` must inherit from 'DBIConnection' in call to `create_func`", call. = FALSE)
  }

  # * `proc_name`
  if (!isTRUE(is.character(proc_name)) || !isTRUE(length(proc_name) == 1) || isTRUE(is.na(proc_name))) {
    stop("`proc_name` must be a character in call to `create_func`", call. = FALSE)
  }

  # Initialize `create_func_dir`
  create_func_dir <- system.file('sql/setup/create_func', package = 'cdmpLibrary')

  # Initialize `func_files`
  func_files <- gsub(
    pattern = '.sql',
    replacement = '',
    x = list.files(
      path = create_func_dir,
      pattern = '*.sql'
    ),
    fixed = TRUE
  )

  if (!isTRUE(proc_name %in% func_files)) {
    stop("`proc_name` was not found in project subfolder 'sql/create_func' in call to `create_func`", call. = FALSE)
  }

  # MAIN LOGIC

  # Read SQL File
  func_sql <- readr::read_file(file.path(create_func_dir, paste0(proc_name, '.sql')))

  # Execute SQL File
  tryCatch({
    DBI::dbExecute(conn, func_sql)
  }, error = function(e) {
    message(sprintf("Error in %s: %s", deparse(e[["call"]]), e[["message"]]))
  })

  # Return Success
  invisible(TRUE)

}

#' Create Defined Procedure in Competitive Mapping Library
#'
#' @param conn DBIConnection
#' @param proc_name character
#'
#' @return TRUE
#' @export
#'
#' @examples
#' \dontrun{
#' create_proc(psql_conn, proc_name = 'testname')
#' }
create_proc <- function(conn, proc_name) {

  # Validate Inputs
  if (missing(conn)) {stop("`conn` is missing in call to `create_proc`", call. = FALSE)}
  if (missing(proc_name)) {stop("`proc_name` is missing in call to `create_proc`", call. = FALSE)}

  # * `conn`
  if (!isTRUE(inherits(conn, 'DBIConnection'))) {
    stop("`conn` must inherit from 'DBIConnection' in call to `create_proc`", call. = FALSE)
  }

  # * `proc_name`
  if (!isTRUE(is.character(proc_name)) || !isTRUE(length(proc_name) == 1) || isTRUE(is.na(proc_name))) {
    stop("`proc_name` must be a character in call to `create_proc`", call. = FALSE)
  }

  # Initialize `create_proc_dir`
  create_proc_dir <- system.file('sql/setup/create_proc', package = 'cdmpLibrary')

  proc_files <- gsub(
    pattern = '.sql',
    replacement = '',
    x = list.files(
      path = create_proc_dir,
      pattern = '*.sql'
    ),
    fixed = TRUE
  )

  if (!isTRUE(proc_name %in% proc_files)) {
    stop("`proc_name` was not found in project subfolder 'sql/create_proc' in call to `create_proc`", call. = FALSE)
  }

  # MAIN LOGIC

  # Read SQL File
  proc_sql <- readr::read_file(file.path(create_proc_dir, paste0(proc_name, '.sql')))

  # Execute Procedure SQL File
  tryCatch({
    DBI::dbExecute(conn, proc_sql)
  }, error = function(e) {
    message(sprintf("Error in %s: %s", deparse(e[["call"]]), e[["message"]]))
  })

  # Return Success
  invisible(TRUE)

}

#' Drop Existing Routine from Competitive Mapping Library
#'
#' @param conn DBIConnection
#' @param proc_name character
#'
#' @return TRUE
#' @export
#'
#' @examples
#' \dontrun{
#' drop_routine(psql_conn, proc_name = 'testname')
#' }
drop_routine <- function(conn, proc_name) {

  # Validate Inputs
  if (missing(conn)) {stop("`conn` is missing in call to `drop_routine`", call. = FALSE)}
  if (missing(proc_name)) {stop("`proc_name` is missing in call to `drop_routine`", call. = FALSE)}

  # * `conn`
  if (!isTRUE(inherits(conn, 'DBIConnection'))) {
    stop("`conn` must inherit from 'DBIConnection' in call to `drop_routine`", call. = FALSE)
  }

  # * `proc_name`
  if (!isTRUE(is.character(proc_name)) || !isTRUE(length(proc_name) == 1) || isTRUE(is.na(proc_name))) {
    stop("`proc_name` must be a character in call to `drop_routine`", call. = FALSE)
  }

  # Initialize `create_func_dir`
  create_func_dir <- system.file('sql/setup/create_func', package = 'cdmpLibrary')

  # Initialize `create_proc_dir`
  create_proc_dir <- system.file('sql/setup/create_proc', package = 'cdmpLibrary')

  proc_files <- gsub(
    pattern = '.sql',
    replacement = '',
    x = list.files(
      path = create_proc_dir,
      pattern = '*.sql'
    ),
    fixed = TRUE
  )

  func_files <- gsub(
    pattern = '.sql',
    replacement = '',
    x = list.files(
      path = create_func_dir,
      pattern = '*.sql'
    ),
    fixed = TRUE
  )

  if (!isTRUE(proc_name %in% unique(c(proc_files, func_files)))) {
    stop("`proc_name` was not found in project subfolder 'sql/drop_routine' in call to `drop_routine`", call. = FALSE)
  }

  # MAIN LOGIC

  # Execute Drop Routine
  tryCatch({
    DBI::dbExecute(conn, glue::glue_sql("DROP ROUTINE IF EXISTS public.{`proc_name`}", .con = conn))
  }, error = function(e) {
    message(sprintf("Error in %s: %s", deparse(e[["call"]]), e[["message"]]))
  })

  # Return Success
  invisible(TRUE)

}

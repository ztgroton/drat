
#' Fetch Item Lookup Table from PostgreSQL Database
#'
#' @param use_dev logical
#'
#' @return data.frame
#' @export
#'
#' @examples
#' \dontrun{
#' output <- twm_item()
#' }
twm_item <- function(use_dev) {

  # Validate Inputs ----
  if (missing(use_dev)) {use_dev <- FALSE}

  # Validate Input Expectations ----
  if (!isTRUE(identical(use_dev, TRUE)) && !isTRUE(identical(use_dev, FALSE))) {
    stop("`use_dev` must be TRUE/FALSE in call to `cdmp_upc_lookup`")
  }

  # Open Connection to 'PSQL - comp_map_lib'
  if (isTRUE(use_dev)) {
    comp_map_lib <- dbTools::psql_db_connect('comp_map_lib_dev')
  } else {
    comp_map_lib <- dbTools::psql_db_connect('comp_map_lib_prod')
  }

  # Fetch SQL Query
  qry <- "select * from map_library.twm_item_upc"

  tryCatch({

    # Execute SQL Query / Fetch Results
    results <- DBI::dbGetQuery(comp_map_lib, qry)

    # Post-Process Results
    results <- results %>%
      dplyr::select(
        -.data$upc,
        -.data$is_primary,
        -.data$position_name
      ) %>%
      dplyr::distinct(
        .data$item_code,
        .data$position_key,
        .keep_all = TRUE
      ) %>%
      dplyr::relocate(
        .data$item_sales_dollars_r52w,
        .data$item_unit_sales_r52w,
        .data$item_case_sales_r52w
      ) %>%
      dplyr::mutate(
        item_sales_dollars_r52w = round(.data$item_sales_dollars_r52w, digits = 0),
        item_unit_sales_r52w = round(.data$item_unit_sales_r52w, digits = 0),
        item_case_sales_r52w = round(.data$item_case_sales_r52w, digits = 0)
      ) %>%
      dplyr::arrange(dplyr::desc(.data$item_sales_dollars_r52w))

    # Close Connection to PSQL - comp_map_lib'
    DBI::dbDisconnect(comp_map_lib)
    rm(comp_map_lib)

  }, error = function(e) {

    # Close DB Connection
    DBI::dbDisconnect(comp_map_lib)
    rm(comp_map_lib)

    # Throw Error Message
    stop(sprintf("Error in %s: %s", deparse(e[["call"]]), e[["message"]]))

  })

  # Return Results
  return(results)

}

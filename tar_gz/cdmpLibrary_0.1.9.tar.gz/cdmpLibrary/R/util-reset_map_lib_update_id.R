
#' Reset Starting Point for Auto-Incrementing ID on 'map_library.map_lib_update' table
#'
#' @param conn DBIConnection
#'
#' @return TRUE
#' @export
#'
#' @examples
#' \dontrun{
#' setup_triggers(psql_conn)
#' }
reset_map_lib_update_id <- function(conn) {

  # Validate Inputs
  if (missing(conn)) {stop("`conn` is missing in call to `reset_map_lib_update_id`")}

  # Validate Input Expectations

  # * `conn`
  if (!isTRUE(inherits(conn, 'DBIConnection'))) {
    stop("`conn` must inherit from 'DBIConnection' in call to `reset_map_lib_update_id`")
  }

  # Fetch Max Value of 'id' column in 'map_library.map_lib_update'
  max_id <- DBI::dbGetQuery(
    conn = conn,
    "select max(id) as max_id from map_library.map_lib_update"
  ) %>%
    dplyr::pull(.data$max_id)

  # Validate 'max_id'
  if (!isTRUE(is.numeric(max_id)) || !isTRUE(length(max_id) == 1) || isTRUE(is.na(max_id))) {
    stop("`max_id` must be non-na length 1 numeric vector in call to `reset_map_lib_update`")
  }

  # Prepare SQL DML Statement
  stmt <- glue::glue_sql(
    "ALTER SEQUENCE map_library.map_lib_update_id_seq RESTART {max_id};",
    max_id = max_id + 1,
    .con = conn
  )

  # Execute Statement
  DBI::dbExecute(conn, stmt)

}

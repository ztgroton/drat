
#' Helper Function for Mapping Nielsen Data
#'
#' @param data data.frame - contains the raw data to be mapped
#' @param upc character - name of column containing UPCs
#' @param item_name character - name of column containing Item Names
#'
#' @return TRUE
#' @export
#'
#' @examples
#' \dontrun{
#' map_nielsen(raw_nielsen_data, 'UPC', 'ITEM')
#' }
map_nielsen <- function(data, upc, item_name) {

  # Validate Inputs
  if (missing(data)) {stop("`data` is missing in call to `map_nielsen`")}
  if (missing(upc)) {upc <- NULL}
  if (missing(item_name)) {item_name <- NULL}

  # Initialize `data` variable name
  data_name <- deparse(substitute(data))

  # Validate Input Expectations

  # * `data`
  if (!isTRUE(is.data.frame(data))) {
    stop("`data` must be type 'data.frame' in call to `map_nielsen`")
  }

  # * `upc`
  is_char <- isTRUE(is.character(upc))
  is_len1 <- isTRUE(length(upc) == 1)
  is_colname <- isTRUE(upc %in% colnames(data))
  if (!isTRUE(is_char) || !isTRUE(is_len1) || !isTRUE(is_colname)) {
    stop("`upc` must be single column name of `data` in call to `map_nielsen_upc`")
  }

  # * `item_name`
  is_char <- isTRUE(is.character(item_name))
  is_len1 <- isTRUE(length(item_name) == 1)
  is_colname <- isTRUE(item_name %in% colnames(data))
  if (!isTRUE(is_char) || !isTRUE(is_len1) || !isTRUE(is_colname)) {
    stop("`item_name` must be single column name of `data` in call to `map_nielsen`")
  }

  # * `data_name`
  is_char <- isTRUE(is.character(data_name))
  is_len1 <- isTRUE(length(data_name) == 1)
  is_non_na <- isTRUE(!is.na(data_name))
  if (!isTRUE(is_char) || !isTRUE(is_len1) || !isTRUE(is_non_na)) {
    stop("`data_name` must be non-na length 1 character in call to `map_nielsen`")
  }

  cat("NIELSEN...\n\n")

  # Initialize Empty S3 Object of class 'cdmp_shop_data'
  nielsen_shop <- cdmp_shop_data()

  # Load `data` into `nielsen_shop`
  load_file(obj = nielsen_shop, name = data_name, data = data)

  # Set 'Shop Party' as 'nlsn'
  set_shop_party(obj = nielsen_shop, shop_party = 'nlsn')

  # Set Key Template
  upc_name_keys <- list(
    item_name = c(item_name = item_name),
    upc_num = c(upc = upc),
    upc_text = c(upc = upc)
  )
  set_key(obj = nielsen_shop, key = upc_name_keys)

  # Generate Keys
  generate_shop_key(obj = nielsen_shop)

  # Map Keys
  map_shop_key(obj = nielsen_shop)

  # Upload Mapped Keys
  upsert_shop_key(obj = nielsen_shop)

  # Return Success
  invisible(TRUE)

}

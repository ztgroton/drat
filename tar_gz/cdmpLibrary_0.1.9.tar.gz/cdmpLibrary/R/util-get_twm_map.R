
#' Return Active TWM Items in Mapping Library
#'
#' @return data.frame
#' @export
#'
get_twm_map <- function() {

  psql_conn <- psql_db_connect('comp_map_lib_prod')
  res <- DBI::dbGetQuery(psql_conn, "select * from map_library.twm_map")
  DBI::dbDisconnect(psql_conn)
  rm(psql_conn)

  return(res)

}

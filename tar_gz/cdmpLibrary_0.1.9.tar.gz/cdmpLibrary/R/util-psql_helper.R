
#' List all existing EDAP PSQL databases
#'
#' @return data.frame
#' @export
#'
list_psql_db <- function() {

  conn <- psql_db_connect('postgres')
  res <- DBI::dbGetQuery(conn, readr::read_file(system.file('sql/psql_helper/psql_list_databases.sql', package = 'cdmpLibrary')))
  DBI::dbDisconnect(conn)
  rm(conn)

  return(res)

}

#' List all existing EDAP PSQL schema across all existing databases
#'
#' @importFrom rlang .data
#'
#' @return data.frame
#' @export
#'
list_psql_schema <- function() {

  schema_qry <- readr::read_file(system.file('sql/psql_helper/psql_list_schemas.sql', package = 'cdmpLibrary'))
  db_list <- list_psql_db()

  res <- lapply(db_list$db_name, function(x) {

    conn <- psql_db_connect(x)

    rs <- DBI::dbGetQuery(conn, schema_qry) %>% as.data.frame()

    rs <- rs %>%
      dplyr::mutate(db_name = x) %>%
      dplyr::relocate(.data$db_name)

    DBI::dbDisconnect(conn)
    rm(conn)

    rs

  })

  dplyr::bind_rows(res)

}

#' List all existing EDAP PSQL stables across all existing database schemas
#'
#' @importFrom rlang .data
#'
#' @return data.frame
#' @export
#'
list_psql_table <- function() {

  table_qry <- readr::read_file(system.file('sql/psql_helper/psql_list_tables.sql', package = 'cdmpLibrary'))
  db_list <- list_psql_db()
  schema_list <- list_psql_schema()

  res <- lapply(db_list$db_name, function(db) {

    db_schema_list <- schema_list %>%
      dplyr::filter(.data$db_name == db) %>%
      dplyr::pull(.data$schema_name)

    db_conn <- psql_db_connect(db)

    db_schema_tables <- lapply(db_schema_list, function(sch) {

      rs <- DBI::dbGetQuery(
        db_conn,
        glue::glue_sql(
          table_qry,
          schema_val = sch,
          .con = db_conn
        )
      ) %>% as.data.frame()

      rs

    })

    DBI::dbDisconnect(db_conn)
    rm(db_conn)

    dplyr::bind_rows(db_schema_tables)

  })

  dplyr::bind_rows(res)

}

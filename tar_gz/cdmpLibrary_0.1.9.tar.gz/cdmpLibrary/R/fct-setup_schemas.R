
#' Setup Competitive Mapping Library Schemas
#'
#' @param conn DBIConnection
#'
#' @return TRUE
#' @export
#'
#' @examples
#' \dontrun{
#' setup_schemas(psql_conn)
#' }
setup_schemas <- function(conn) {

  # Validate Inputs
  if (missing(conn)) {stop("`conn` is missing in call to `setup_schemas`")}

  # Validate Input Expectations

  # * `conn`
  if (!isTRUE(inherits(conn, 'DBIConnection'))) {
    stop("`conn` must inherit from 'DBIConnection' in call to `setup_schemas`")
  }

  # ____________________________________ ----
  # CREATE SCHEMAS ----

  # * `NSLN` Shop Party ----
  suppressMessages({create_schema(conn, 'nlsn', preclean = TRUE)})

  # * `IRI` Shop Party ----
  suppressMessages({create_schema(conn, 'iri', preclean = TRUE)})

  # * `BST` Shop Party ----
  suppressMessages({create_schema(conn, 'bst', preclean = TRUE)})

  # * `TWM` Shop Party ----
  suppressMessages({create_schema(conn, 'twm', preclean = TRUE)})

  # * `TWS` Shop Party ----
  suppressMessages({create_schema(conn, 'tws', preclean = TRUE)})

  # * `MAP_LIBRARY` ----
  suppressMessages({create_schema(conn, 'map_library', preclean = TRUE)})

  # * `UPLOAD_FILES` ----
  suppressMessages({create_schema(conn, 'upload_files', preclean = TRUE)})

  # Return Success
  invisible(TRUE)

}


#' Initialize Triggers
#'
#' @param conn DBIConnection
#'
#' @return TRUE
#' @export
#'
#' @examples
#' \dontrun{
#' init_trig(psql_conn)
#' }
init_trig <- function(conn) {

  # Validate Inputs
  if (missing(conn)) {stop("`conn` is missing in call to `init_trig`", call. = FALSE)}

  # * `conn`
  if (!isTRUE(inherits(conn, 'DBIConnection'))) {
    stop("`conn` must inherit from 'DBIConnection' in call to `init_trig`", call. = FALSE)
  }

  # Iterate over `valid_mapping_schemas`
  purrr::walk(names(cdmpLibrary::valid_mapping_schemas), function(schema) {

    # Get Schema Tables
    tables <- cdmpLibrary::valid_mapping_schemas[[schema]]

    # Iterate Over `tables`
    for (table in tables) {

      # Initialize `map_library.map_lib` Trigger
      suppressMessages({init_map_lib_trigger(
        conn = conn,
        schema = schema,
        table = table
      )})

      # Initialize `map_library.map_lib_update` Trigger
      suppressMessages({init_map_lib_update_trigger(conn = conn)})

    }

  })

}

#' Initialize Table Triggers for Logging in Competitive Mapping Library
#'
#' @param conn DBIConnection
#' @param schema character
#' @param table character
#'
#' @return TRUE
#' @export
#'
#' @examples
#' \dontrun{
#' init_map_lib_trigger(psql_conn, 'nlsn', 'upc_num')
#' }
init_map_lib_trigger <- function(conn, schema, table) {

  # Validate Inputs
  if (missing(conn)) {stop("`conn` is missing in call to `init_map_lib_trigger`", call. = FALSE)}
  if (missing(schema)) {stop("`schema` is missing in call to `init_map_lib_trigger`", call. = FALSE)}
  if (missing(table)) {stop("`table` is missing in call to `init_map_lib_trigger`", call. = FALSE)}

  # * `conn`
  if (!isTRUE(inherits(conn, 'DBIConnection'))) {
    stop("`conn` must inherit from 'DBIConnection' in call to `init_map_lib_trigger`", call. = FALSE)
  }

  # * `schema`
  if (!isTRUE(is.character(schema)) || !isTRUE(length(schema) == 1) || isTRUE(is.na(schema))) {
    stop("`schema` must be a character in call to `init_map_lib_trigger`", call. = FALSE)
  }

  # * `table`
  if (!isTRUE(is.character(table)) || !isTRUE(length(table) == 1) || isTRUE(is.na(table))) {
    stop("`table` must be a character in call to `init_map_lib_trigger`", call. = FALSE)
  }

  # MAIN LOGIC

  # Initialize `schema_val` and `table_val`
  schema_val <- schema
  table_val <- table

  # Initialize `create_trig_dir`
  create_trig_dir <- system.file('sql/setup/create_trig', package = 'cdmpLibrary')

  # Pull Trigger Templates
  template_insert <- glue::glue(readr::read_file(file.path(create_trig_dir, 'map_lib__insert_trigger.sql')))
  template_update <- glue::glue(readr::read_file(file.path(create_trig_dir, 'map_lib__update_trigger.sql')))
  template_delete <- glue::glue(readr::read_file(file.path(create_trig_dir, 'map_lib__delete_trigger.sql')))

  # Drop Existing Triggers
  tryCatch({

    DBI::dbBegin(conn)
    suppressMessages({DBI::dbExecute(conn, glue::glue("DROP TRIGGER IF EXISTS map_lib_{schema_val}_{table_val}_insert_trig ON {schema_val}.{table_val}"))})
    suppressMessages({DBI::dbExecute(conn, glue::glue("DROP TRIGGER IF EXISTS map_lib_{schema_val}_{table_val}_update_trig ON {schema_val}.{table_val}"))})
    suppressMessages({DBI::dbExecute(conn, glue::glue("DROP TRIGGER IF EXISTS map_lib_{schema_val}_{table_val}_delete_trig ON {schema_val}.{table_val}"))})
    DBI::dbCommit(conn)

  }, error = function(e) {
    DBI::dbRollback(conn)
    message(sprintf("Error in %s: %s", deparse(e[["call"]]), e[["message"]]))
  })

  # Execute Create Statement
  tryCatch({

    DBI::dbBegin(conn)
    suppressMessages({DBI::dbExecute(conn, template_insert)})
    suppressMessages({DBI::dbExecute(conn, template_update)})
    suppressMessages({DBI::dbExecute(conn, template_delete)})
    DBI::dbCommit(conn)

  }, error = function(e) {
    DBI::dbRollback(conn)
    message(sprintf("Error in %s: %s", deparse(e[["call"]]), e[["message"]]))
  })

  # Return Success
  invisible(TRUE)

}

#' Initialize 'map_library.map_lib' Triggers for Logging into 'map_library.map_lib_update'
#'
#' @param conn DBIConnection
#'
#' @return TRUE
#' @export
#'
#' @examples
#' \dontrun{
#' init_map_lib_update_trigger(psql_conn)
#' }
init_map_lib_update_trigger <- function(conn) {

  # Validate Inputs
  if (missing(conn)) {stop("`conn` is missing in call to `init_map_lib_update_trigger`", call. = FALSE)}

  # * `conn`
  if (!isTRUE(inherits(conn, 'DBIConnection'))) {
    stop("`conn` must inherit from 'DBIConnection' in call to `init_map_lib_update_trigger`", call. = FALSE)
  }

  # MAIN LOGIC

  # Initialize `create_trig_dir`
  create_trig_dir <- system.file('sql/setup/create_trig', package = 'cdmpLibrary')

  # Pull Trigger Templates
  template_insert <- readr::read_file(file.path(create_trig_dir, 'map_lib_update__insert_trigger.sql'))
  template_update <- readr::read_file(file.path(create_trig_dir, 'map_lib_update__update_trigger.sql'))
  template_delete <- readr::read_file(file.path(create_trig_dir, 'map_lib_update__delete_trigger.sql'))

  # Drop Existing Triggers
  tryCatch({

    DBI::dbBegin(conn)
    suppressMessages({DBI::dbExecute(conn, "DROP TRIGGER IF EXISTS map_lib_update_trigger_insert ON map_library.map_lib")})
    suppressMessages({DBI::dbExecute(conn, "DROP TRIGGER IF EXISTS map_lib_update_trigger_update ON map_library.map_lib")})
    suppressMessages({DBI::dbExecute(conn, "DROP TRIGGER IF EXISTS map_lib_update_trigger_delete ON map_library.map_lib")})
    DBI::dbCommit(conn)

  }, error = function(e) {
    DBI::dbRollback(conn)
    message(sprintf("Error in %s: %s", deparse(e[["call"]]), e[["message"]]))
  })

  # Execute Create Statement
  tryCatch({

    DBI::dbBegin(conn)
    suppressMessages({DBI::dbExecute(conn, template_insert)})
    suppressMessages({DBI::dbExecute(conn, template_update)})
    suppressMessages({DBI::dbExecute(conn, template_delete)})
    DBI::dbCommit(conn)

  }, error = function(e) {
    DBI::dbRollback(conn)
    message(sprintf("Error in %s: %s", deparse(e[["call"]]), e[["message"]]))
  })

  # Return Success
  invisible(TRUE)

}

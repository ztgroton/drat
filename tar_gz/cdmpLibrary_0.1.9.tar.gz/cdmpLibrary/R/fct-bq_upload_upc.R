
#' Upload UPC Mappings to BigQuery Table 'merchandising.competitor_mapping_library_NEW'
#'
#' @importFrom rlang .data
#'
#' @param schema character - Specify 'nlsn' or 'iri'
#'
#' @return TRUE
#' @export
#'
#' @examples
#' \dontrun{
#' bq_upload_upc('iri')
#' bq_upload_upc('nlsn')
#' }
bq_upload_upc <- function(schema) {

  # Validate Inputs
  if (missing(schema)) {stop("`schema` is missing in call to `bq_upload_upc`")}

  # Validate Input Expectations
  valid_schemas <- c('nlsn', 'iri')
  if (!isTRUE(length(schema) == 1) || !isTRUE(schema %in% valid_schemas)) {
    stop("`schema` value must be valid in call to `bq_upload_upc`")
  }

  # Initialize Local Variables for Later Use
  if (isTRUE(schema == 'nlsn')) {
    upload_shop_party <- 'NLSN'
    upload_competitor <- 'NLSN'
  } else {
    upload_shop_party <- 'IRI'
    upload_competitor <- 'IRI'
  }

  # Get UPC Mappings
  upc_map <- vw_map_key(schema = schema, table = 'upc_num')

  # Filter Out Un-Mapped UPCs
  upc_map <- upc_map %>%
    dplyr::filter(
      !is.na(.data$twm_item_code),
      !is.na(.data$twm_position_key)
    )

  # Remove Extraneous Columns
  upc_map <- upc_map %>%
    dplyr::select(.data$upc, .data$twm_item_code, .data$twm_position_key)

  # Fill in Upload using 'upc_map'
  upload <- cdmpLibrary::competitor_mapping_library_NEW %>%
    dplyr::bind_rows(upc_map)

  # Fill in Remaining Columns as Required
  upload <- upload %>%
    dplyr::mutate(
      item_name = "DUMMY NAME - DO NOT USE",
      shop_party = upload_shop_party,
      competitor = upload_competitor,
      is_private_label = FALSE,
      last_modify_date = as.POSIXct(Sys.time(), tz = 'GMT'),
      modified_by = 'ZGroton'
    )

  # Upload to BigQuery Table 'merchandising.competitor_mapping_library_NEW'
  tbl <- bigrquery::bq_table('twm-edap-prod-1802', 'merchandising', table = 'competitor_mapping_library_NEW')
  bigrquery::bq_table_upload(tbl, values = upload, write_disposition = 'WRITE_APPEND', quiet = FALSE)

  # Return Success
  invisible(TRUE)

}

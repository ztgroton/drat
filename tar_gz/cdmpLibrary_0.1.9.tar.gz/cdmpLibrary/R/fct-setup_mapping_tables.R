
#' Setup Competitive Mapping Library 'Mapping' Tables
#'
#' @param conn DBIConnection
#'
#' @return TRUE
#' @export
#'
#' @examples
#' \dontrun{
#' setup_mapping_tables(psql_conn)
#' }
setup_mapping_tables <- function(conn) {

  # Validate Inputs
  if (missing(conn)) {stop("`conn` is missing in call to `setup_mapping_tables`")}

  # Validate Input Expectations

  # * `conn`
  if (!isTRUE(inherits(conn, 'DBIConnection'))) {
    stop("`conn` must inherit from 'DBIConnection' in call to `setup_mapping_tables`")
  }

  # ____________________________________ ----
  # CREATE MAPPING TABLES ----

  # Iterate over `names(valid_mapping_schemas)`
  purrr::walk(names(cdmpLibrary::valid_mapping_schemas), function(schema) {

    # Get Schema Tables
    tables <- cdmpLibrary::valid_mapping_schemas[[schema]]

    # Set Value for 'include_competitor'
    include_competitor <- isTRUE(schema %in% c('twm', 'tws'))

    # Iterate Over `tables`
    for (table in tables) {

      # Initialize Mapping Table
      cat(paste0(toupper(schema), ' - ', toupper(table), '... '))
      tictoc::tic()
      create_mapping_table(
        conn = conn,
        schema = schema,
        table = cdmpLibrary::valid_mapping_tables[[table]],
        tablename = table,
        include_competitor = include_competitor
      )
      tictoc::toc()

    }

  })

  # Return Success
  invisible(TRUE)

}

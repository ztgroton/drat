
#' Construct an Empty S3 Object of class 'cdmp_map'
#'
#' @param key S3 Object
#' @param item_pos S3 Object
#'
#' @return S3 Object
#' @examples
#' \dontrun{
#' output <- new_cdmp_map(key = cdmp_key_obj, item_pos = cdmp_item_pos_obj)
#' }
new_cdmp_map <- function(key, item_pos) {

  # Validate Inputs
  if (missing(key)) {stop("`key` is missing in call to `new_cdmp_map`")}
  if (missing(item_pos)) {stop("`item_pos` is missing in call to `new_cdmp_map`")}

  # Validate Input Expectations

  # * `key`
  if (!isTRUE(inherits(key, 'cdmp_key'))) {
    stop("`key` must inherit from 'cdmp_key' in call to `new_cdmp_map`")
  }

  # * `item_pos`
  if (!isTRUE(inherits(item_pos, 'cdmp_item_pos'))) {
    stop("`item_pos` must inherit from 'cdmp_item_pos' in call to `new_cdmp_map`")
  }

  # Define Class Environment
  rs <- new.env()

  # Define Class Members
  rs$key <- key
  rs$item_pos <- item_pos

  # Update Class Path
  class(rs) <- c(setdiff('cdmp_map', class(rs)), class(rs))

  # Return Object
  return(rs)

}

#' Validate that 'obj' is properly formatted S3 Object of class 'cdmp_key'
#'
#' @param obj S3 Object
#' @param bool TRUE/FALSE - indicates if function should invisibly return 'obj' or 'TRUE/FALSE'
#'
#' @return S3 Object, TRUE/FALSE
#'
#' @examples
#' \dontrun{
#'  output <- validate_cdmp_map(obj = cdmp_map_obj, bool = FALSE)
#' }
validate_cdmp_map <- function(obj, bool) {

  # Validate Inputs
  if (missing(obj)) {stop("`obj` is missing in call to `validate_cdmp_map`", call. = FALSE)}
  if (missing(bool)) {bool <- FALSE}

  # Validate Input Expectations
  expect_env(obj, c('key', 'item_pos'))
  expect_scalar_logical(bool)

  # * key
  if (!isTRUE(inherits(obj$key, 'cdmp_key'))) {
    stop("`obj$key` must inherit from 'cdmp_key' in call to `validate_cdmp_map`")
  }
  invisible(validate_cdmp_key(obj$key))

  # * item_pos
  if (!isTRUE(inherits(obj$item_pos, 'cdmp_item_pos'))) {
    stop("`obj$item_pos` must inherit from 'cdmp_item_pos' in call to `validate_cdmp_map`")
  }
  invisible(validate_cdmp_item_pos(obj$item_pos))

  # Return Result
  if (isTRUE(bool)) {return(TRUE)}
  else {invisible(obj)}

}

#' Helper Function for Constructing S3 Class 'cdmp_map'
#'
#' @param key S3 Object
#' @param item_pos S3 Object
#'
#' @return S3 Object
#' @export
#'
#' @examples
#' \dontrun{
#' map <- cdmp_map(key = cdmp_key_obj, item_pos = cdmp_item_pos_obj)
#' }
cdmp_map <- function(key, item_pos) {

  # Validate Inputs
  if (missing(key)) {stop("`key` is missing in call to `cdmp_map`")}
  if (missing(item_pos)) {stop("`item_pos` is missing in call to `cdmp_map`")}

  new_cdmp_map(key, item_pos) %>% validate_cdmp_map()

}

#' S3 Generic - Retrieve Internal Values from 'cdmp_map' object
#'
#' @param obj S3 Object of class 'cdmp_map'
#' @param name character
#'
#' @return NULL
#' @export
#'
#' @examples
#' \dontrun{
#' output <- get_elem(obj = cdmp_map_obj, name = 'key')
#' }
get_elem <- function(obj, name) {UseMethod("get_elem", obj)}

#' S3 Generic - Set Internal Values from 'cdmp_map' object
#'
#' @param obj S3 Object of class 'cdmp_map'
#' @param name character
#' @param value R Object
#'
#' @return NULL
#' @export
#'
#' @examples
#' \dontrun{
#' set_elem(obj = cdmp_map_obj, name = 'key', value = cdmp_key_obj)
#' }
set_elem <- function(obj, name, value) {UseMethod("set_elem", obj)}

#' S3 Generic - Clear Existing Mappings for 'cdmp_map' object
#'
#' @param obj S3 Object of class 'cdmp_map'
#' @param map_order integer
#'
#' @return NULL
#' @export
#'
#' @examples
#' \dontrun{
#' clear_map(obj = cdmp_map_obj, map_order = 1)
#' }
clear_map <- function(obj, map_order) {UseMethod("clear_map", obj)}

#' S3 Generic - Upload Mapping Defined by 'cdmp_map' object
#'
#' @param obj S3 Object of class 'cdmp_map'
#' @param map_order integer
#'
#' @return NULL
#' @export
#'
#' @examples
#' \dontrun{
#' update_map(obj = cdmp_map_obj, map_order = 1)
#' }
update_map <- function(obj, map_order) {UseMethod("update_map", obj)}

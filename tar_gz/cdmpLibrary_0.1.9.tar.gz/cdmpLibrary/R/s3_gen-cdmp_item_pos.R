
#' Construct an Empty S3 Object of class 'cdmp_item_pos'
#'
#' @param item_code numeric
#' @param position numeric
#'
#' @return S3 Object
#'
#' @examples
#' \dontrun{
#' output <- new_cdmp_item_pos(item_code = 123456789, position = 1)
#' }
new_cdmp_item_pos <- function(item_code, position) {

  # Validate Inputs
  if (missing(item_code)) {stop("`item_code` is missing in call to `new_cdmp_item_pos`")}
  if (missing(position)) {stop("`position` is missing in call to `new_cdmp_item_pos`")}

  # Define Class Environment
  rs <- new.env()

  # Define Class Members
  rs$item_code <- item_code
  rs$position <- position

  # Update Class Path
  class(rs) <- c(setdiff('cdmp_item_pos', class(rs)), class(rs))

  # Return Object
  return(rs)

}

#' Validate that 'obj' is properly formatted S3 Object of class 'cdmp_item_pos'
#'
#' @param obj S3 Object
#' @param bool TRUE/FALSE - indicates if function should invisibly return 'obj' or 'TRUE/FALSE'
#'
#' @return S3 Object, TRUE/FALSE
#'
#' @examples
#' \dontrun{
#' output <- validate_cdmp_item_pos(obj = cdmp_item_pos, bool = FALSE)
#' }
validate_cdmp_item_pos <- function(obj, bool) {

  # Validate Inputs
  if (missing(obj)) {stop("`obj` is missing in call to `validate_cdmp_item_pos`", call. = FALSE)}
  if (missing(bool)) {bool <- FALSE}

  # Validate Input Expectations
  expect_env(obj, c('item_code', 'position'))
  expect_scalar_logical(bool)

  # * item_code
  expect_data_type(obj$item_code, 'numeric', TRUE, TRUE, FALSE)
  if (!isTRUE(obj$item_code > 0)) {
    stop("`obj$item_code` must be greater than zero in call to `validate_cdmp_item_pos`")
  } else if (!isTRUE(obj$item_code %% 1 == 0)) {
    stop("`obj$item_code` must be whole integer in call to `validate_cdmp_item_pos`")
  }

  # * position
  expect_data_type(obj$position, 'numeric', TRUE, TRUE, FALSE)
  if (!isTRUE(obj$position %in% c(1,2,3))) {
    stop("`obj$position` must equal 1, 2 or 3 in call to `validate_cdmp_item_pos`")
  } else if (!isTRUE(obj$position %% 1 == 0)) {
    stop("`obj$position` must be whole integer in call to `validate_cdmp_item_pos`")
  }


  # Return Result
  if (isTRUE(bool)) {return(TRUE)}
  else {invisible(obj)}

}

#' Helper Function for Constructing S3 Class 'cdmp_item_pos'
#'
#' @param item_code numeric
#' @param position numeric
#'
#' @return S3 Object
#' @export
#'
#' @examples
#' \dontrun{
#' record <- cdmp_item_pos(item_code = 123456789, position = 1)
#' }
cdmp_item_pos <- function(item_code, position) {

  # Validate Inputs
  if (missing(item_code)) {stop("`item_code` is missing in call to `cdmp_item_pos`")}
  if (missing(position)) {stop("`position` is missing in call to `cdmp_item_pos`")}

  new_cdmp_item_pos(item_code, position) %>% validate_cdmp_item_pos()

}

#' S3 Generic - Retrieve Internal Values from 'cdmp_item_pos' object
#'
#' @param obj S3 Object of class 'cdmp_item_pos'
#' @param name character
#'
#' @return NULL
#' @export
#'
#' @examples
#' \dontrun{
#' output <- get_elem(obj = obj, name = 'item_name')
#' }
get_elem <- function(obj, name) {UseMethod("get_elem", obj)}

#' S3 Generic - Set Internal Values from 'cdmp_item_pos' object
#'
#' @param obj S3 Object of class 'cdmp_item_pos'
#' @param name character
#' @param value R Object
#'
#' @return NULL
#' @export
#'
#' @examples
#' \dontrun{
#' set_elem(obj = obj, name = 'item_name', value = list(item_name = "Tito's Handmade Vodka"))
#' }
set_elem <- function(obj, name, value) {UseMethod("set_elem", obj)}

#' S3 Generic - Upsert Values for 'cdmp_item_pos' object
#'
#' @param obj S3 Object of class 'cdmp_item_pos'
#'
#' @return NULL
#' @export
#'
#' @examples
#' \dontrun{
#' upsert_item_pos(obj = obj)
#' }
upsert_item_pos <- function(obj) {UseMethod("upsert_item_pos", obj)}

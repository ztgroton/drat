
#' Upload R Data.Frame to PSQL Table in 'public' schema
#'
#' @param data data.frame
#'
#' @return character
#' @export
#'
#' @examples
#' \dontrun{
#' upload_tbl_name <- upload_tmp_tbl(raw_data)
#' }
upload_tmp_tbl <- function(data) {

  # Validate Inputs
  if (missing(data)) {stop("`data` is missing in call to `upload_tmp_tbl`")}

  # Validate Input Expectations

  # * `data`
  if (!isTRUE(is.data.frame(data))) {
    stop("`data` must be data.frame in call to `upload_tmp_tbl`")
  }

  # Generate Random Table Name
  tbl_name <- gen_unq_name()

  # Initialize File Upload Table ID
  tbl_id <- DBI::Id(schema = 'public', table = tbl_name)

  # Generate Table Hash
  tbl_hash <- digest::digest(object = tbl_id, algo = 'sha256', serialize = TRUE)

  # Setup DB Connection
  psql_conn <- psql_db_connect('comp_map_lib_prod')

  tryCatch({

    # Create Empty Table
    DBI::dbCreateTable(
      conn = psql_conn,
      name = tbl_id,
      fields = data
    )

    # Upload Data
    dbx::dbxInsert(
      conn = psql_conn,
      table = tbl_id,
      records = data
    )

    # Close DB Connection
    DBI::dbDisconnect(psql_conn)
    rm(psql_conn)

    # Return `tbl_name`
    return(tbl_name)

  }, error = function(e) {

    # Close DB Connection
    DBI::dbDisconnect(psql_conn)
    rm(psql_conn)

    # Stop with Error
    stop(sprintf("Error in %s: %s", deparse(e[["call"]]), e[["message"]]))

  })

}

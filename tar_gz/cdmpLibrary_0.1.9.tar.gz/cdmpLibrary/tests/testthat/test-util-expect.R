
test_that("`expect_dbi` works", {
  expect_true(expect_dbi(obj = psql_db_connect('comp_map_lib_prod')))
  expect_true(expect_dbi(obj = psql_db_connect('market_pos')))
  expect_error(expect_dbi(obj = 'comp_map_lib_prod'))
})


test_that("`expect_scalar_char` works", {
  expect_true(expect_scalar_char(obj = 'test'))
  expect_true(expect_scalar_char(obj = 'te st2'))
  expect_true(expect_scalar_char(obj = 'tes_t3'))
  expect_error(expect_scalar_char(obj = 2))
  expect_error(expect_scalar_char(obj = TRUE))
  expect_error(expect_scalar_char(obj = NA))
  expect_error(expect_scalar_char(obj = c('test', 'test2')))
  expect_error(expect_scalar_char(obj = c('test', NA)))
})

test_that("`expect_data_frame` works", {
  expect_true(expect_data_frame(df = data.frame()))
  expect_true(expect_data_frame(df = data.frame(test = c())))
  expect_true(expect_data_frame(df = data.frame(test = 'f', stringsAsFactors = FALSE)))
  expect_true(expect_data_frame(df = data.frame(test = 'f', stringsAsFactors = TRUE)))
  expect_true(expect_data_frame(df = data.frame(test_spamf = 'f', stringsAsFactors = TRUE), columns = c('test_spamf')))
  expect_true(expect_data_frame(df = data.frame(test_spamf = 'f', more_spamf = 2, stringsAsFactors = TRUE), columns = c('test_spamf', 'more_spamf')))
  expect_error(expect_data_frame(df = data.frame(test_spamfd = 'f', more_spadmf = 2, stringsAsFactors = TRUE), columns = c('test_spamf', 'more_spamf')))
  expect_error(expect_data_frame(df = 2))
  expect_error(expect_data_frame(df = TRUE))
  expect_error(expect_data_frame(df = NA))
  expect_error(expect_data_frame(df = c('test', 'test2')))
  expect_error(expect_data_frame(df = c('test', NA)))
})

test_that("`expect_col_exists` works", {
  expect_true(expect_col_exists(df = data.frame(test = vector()), columns = 'test'))
  expect_true(expect_col_exists(df = data.frame(test2 = vector(mode = 'character')), columns = 'test2'))
  expect_true(expect_col_exists(df = data.frame(test3 = vector(mode = 'numeric', length = 2)), columns = 'test3'))
  expect_error(expect_col_exists(df = data.frame(test4 = vector()), columns = 'test'))
  expect_error(expect_col_exists(df = data.frame(test9 = vector(mode = 'character')), columns = 'test2'))
  expect_error(expect_col_exists(df = data.frame(test = vector(mode = 'numeric', length = 2)), columns = 'test3'))
})

test_that("`expect_list` works", {
  expect_true(
    expect_list(
      obj = list(aa = c(aa = 'x')),
      names = c('aa'),
      type = 'character'
    )
  )
  expect_error(
    expect_list(
      obj = list(aa = c(a = 'x')),
      names = c('ax'),
      type = 'character'
    )
  )
  expect_true(
    expect_list(
      obj = list(aa = c('x')),
      names = c('aa'),
      type = 'character'
    )
  )
  expect_true(
    expect_list(
      obj = list(aa = c(xy = 'x')),
      names = c('aa'),
      type = 'character'
    )
  )
})

test_that("`expect_list_equal` works", {
  expect_true(
    expect_list_equal(
      obj1 = list(aa = c(a = 'x')),
      obj2 = list(aa = c(a = 'x')),
      type = 'character'
    )
  )
  expect_true(
    expect_list_equal(
      obj1 = list(aa = c(a = 1)),
      obj2 = list(aa = c(a = 1)),
      type = 'numeric'
    )
  )
  expect_error(
    expect_list_equal(
      obj1 = list(aa = c(a = 'x')),
      obj2 = list(aa = c(a = 'x')),
      type = 'numeric'
    )
  )
  expect_error(
    expect_list_equal(
      obj1 = list(aa = c(a = 'x')),
      obj2 = list(aa = c(a = 'y')),
      type = 'character'
    )
  )
  expect_error(
    expect_list_equal(
      obj1 = list(az = c(a = 'x')),
      obj2 = list(aa = c(a = 'x')),
      type = 'character'
    )
  )
  expect_error(
    expect_list_equal(
      obj1 = list(aa = c(ad = 'x')),
      obj2 = list(aa = c(a = 'x')),
      type = 'character'
    )
  )
})

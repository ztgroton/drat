
CREATE TABLE IF NOT EXISTS common.fk_col
(
  parent_tab_id INTEGER NOT NULL,
  parent_col_id INTEGER NOT NULL,
  child_tab_id INTEGER NOT NULL,
  child_col_id INTEGER NOT NULL,
  fk_id INTEGER NOT NULL,

  CONSTRAINT common_fk_col_pkey PRIMARY KEY (parent_tab_id, parent_col_id, child_tab_id, child_col_id),
  CONSTRAINT common_fk_col_fkey1 FOREIGN KEY (parent_tab_id, parent_col_id) REFERENCES common.tab_col (tab_id, col_id) ON UPDATE CASCADE ON DELETE RESTRICT,
  CONSTRAINT common_fk_col_fkey2 FOREIGN KEY (child_tab_id, child_col_id) REFERENCES common.tab_col (tab_id, col_id) ON UPDATE CASCADE ON DELETE RESTRICT,
  CONSTRAINT common_fk_col_fkey3 FOREIGN KEY (fk_id, parent_tab_id) REFERENCES common.fk (id, tab_id) ON UPDATE CASCADE ON DELETE RESTRICT
)

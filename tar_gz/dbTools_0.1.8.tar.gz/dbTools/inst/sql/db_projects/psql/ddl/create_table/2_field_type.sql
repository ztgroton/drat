
CREATE TABLE IF NOT EXISTS common.field_type
(
  id SERIAL,
  name TEXT NOT NULL,

  CONSTRAINT common_field_type_pkey PRIMARY KEY (id),
  CONSTRAINT common_field_type_unq1 UNIQUE (name)
)

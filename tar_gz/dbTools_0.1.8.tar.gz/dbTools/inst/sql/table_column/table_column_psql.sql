
SELECT DISTINCT
t.table_schema as schema,
t.table_name as table,
c.column_name as column,
c.ordinal_position as column_id,
case c.is_nullable when 'YES' then 0 else 1 end as mandatory,
c.data_type as type

from information_schema.columns c

inner join information_schema.tables t
on t.table_name = c.table_name
and t.table_schema = c.table_schema
and t.table_catalog = c.table_catalog

where c.table_schema = {schema}
and t.table_type = 'BASE TABLE'

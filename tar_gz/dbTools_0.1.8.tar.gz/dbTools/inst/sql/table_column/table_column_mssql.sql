
select distinct
schemas.name as [schema],
tabs.name as [table],
cols.name as [column],
cols.column_id,
1 - cols.is_nullable as mandatory,
types.name as [type]

from {db_sql}.sys.all_columns cols

inner join {db_sql}.sys.tables tabs
on cols.object_id = tabs.object_id

inner join {db_sql}.sys.schemas schemas
on tabs.schema_id = schemas.schema_id

left outer join {db_sql}.sys.systypes [types]
on types.xusertype = cols.system_type_id

where not (schemas.name = 'dbo' and tabs.name = 'store' and cols.name = 'primary_bank')
and schemas.name = {schema}

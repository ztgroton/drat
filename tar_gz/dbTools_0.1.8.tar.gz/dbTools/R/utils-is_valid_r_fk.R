
#' Validate if a set of columns 'fk' is a Foreign Key on data frames 'x' and 'y'
#'
#' @param x data.frame - The first 'data.frame' containing data to be tested.
#' @param y data.frame - The second 'data.frame' containing data to be tested.
#' @param fk character - Vector of column names defining a candidate 'foreign key' for 'x' and 'y'.
#' @param verbose TRUE/FALSE - In case of any Foreign Key Violations: Specifies if records are returned or just FALSE.
#' @param all_records TRUE/FALSE - In case of any Foreign Key Violations: Specifies if all records are returned or just violations.
#'
#' @return R Object
#' @export
#'
is_valid_r_fk <- function(x, y, fk, verbose = FALSE, all_records = FALSE) {

  cat("Validating FK\n")

  # Validate Inputs

  # * `x`
  if (missing(x)) {stop("`x` is missing in call to `is_valid_r_fk`", call. = FALSE)}
  if (!isTRUE(is.data.frame(x))) {stop("`x` must be `data.frame` in call to `is_valid_r_fk`", call. = FALSE)}

  # * `y`
  if (missing(y)) {stop("`y` is missing in call to `is_valid_r_fk`", call. = FALSE)}
  if (!isTRUE(is.data.frame(y))) {stop("`y` must be `data.frame` in call to `is_valid_r_fk`", call. = FALSE)}

  # * `fk`
  if (missing(fk)) {stop("`fk` is missing in call to `is_valid_r_fk`", call. = FALSE)}

  # * `verbose`
  if (!isTRUE(identical(verbose, TRUE)) && !isTRUE(identical(verbose, FALSE))) {
    stop("`verbose` must be TRUE/FALSE in call to `is_valid_r_fk`", call. = FALSE)
  }

  # * `all_records`
  if (!isTRUE(identical(all_records, TRUE)) && !isTRUE(identical(all_records, FALSE))) {
    stop("`all_records` must be TRUE/FALSE in call to `is_valid_r_fk`", call. = FALSE)
  }

  # Compute `xy_nest`
  cat("Nesting Columns... ")
  tictoc::tic()
  xy_nest <- r_nest_fk(x = x, y = y, fk = fk)
  tictoc::toc()

  # Filter for Primary Key Violations
  cat("Searching for Violations... ")
  tictoc::tic()
  xy_violation <- xy_nest %>% dplyr::filter(isTRUE(is.null(.data$orig_row_num_y)))
  tictoc::toc()
  cat("Complete\n")

  # Return Result
  if (isTRUE(verbose)) {

    if (isTRUE(all_records)) {
      return(xy_nest)
    } else {
      return(xy_violation)
    }

  } else {

    if (isTRUE(nrow(xy_violation) == 0)) {
      return(TRUE)
    } else {
      return(FALSE)
    }

  }

}

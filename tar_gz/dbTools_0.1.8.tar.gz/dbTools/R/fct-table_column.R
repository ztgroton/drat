
#' Returns Table Field Data for MSSQL DB
#'
#' @param db character vector
#' @param schema character vector
#'
#' @return data.frame
#'
table_column_mssql <- function(db, schema) {

  if (missing(db)) {stop("`db` is missing in call to `table_column_mssql`", call. = FALSE)}
  if (missing(schema)) {schema <- 'dbo'}

  expect_scalar_char(db)
  expect_scalar_char(schema)
  conn <- mssql_db_connect(db)

  qry <- readr::read_file(system.file('sql/table_column/table_column_mssql.sql', package='dbTools'))
  db_sql <- DBI::dbQuoteIdentifier(conn, db)
  qry <- glue::glue_sql(qry, .con = conn)

  qry <- glue::glue_sql(qry, .con = conn)
  res <- DBI::dbGetQuery(conn, qry)

  DBI::dbDisconnect(conn)
  rm(conn)

  return(res)

}

#' Returns Table Field Data for PSQL DB
#'
#' @param db character vector
#' @param schema character vector
#'
#' @return data.frame
#'
table_column_psql <- function(db, schema) {

  if (missing(db)) {stop("`db` is missing in call to `table_column_psql`", call. = FALSE)}
  if (missing(schema)) {schema <- 'dbo'}

  expect_scalar_char(db)
  expect_scalar_char(schema)
  conn <- psql_db_connect(db)

  qry <- readr::read_file(system.file('sql/table_column/table_column_psql.sql', package='dbTools'))
  qry <- glue::glue_sql(qry, .con = conn)

  qry <- glue::glue_sql(qry, .con = conn)
  res <- DBI::dbGetQuery(conn, qry)

  DBI::dbDisconnect(conn)
  rm(conn)

  return(res)

}


#' Validate if a set of columns is a Foreign Key on two EDAP Tables
#'
#' @param result character
#' @param tables list - Named list of length 2. Elements specify 'parent' and 'child' tables
#' @param columns list - Named list of length 2. Elements specify ordered columns from tables to be used for Foreign Key.
#'
#' @return R Object
#' @export
#'
bq_nest_fk <- function(result, tables, columns) {

  # Validate Inputs
  if (missing(result)) {stop("`result` is missing in call to `bq_nest_fk`", call. = FALSE)}
  if (missing(tables)) {stop("`tables` is missing in call to `bq_nest_fk`", call. = FALSE)}
  if (missing(columns)) {stop("`columns` is missing in call to `bq_nest_fk`", call. = FALSE)}

  # Validate Expectations

  # * `result`
  expect_scalar_char(result)

  # * `tables`
  tables_ind1 <- purrr::map_lgl(tables, function(x){expect_list(x, names = c('schema', 'table'), type = 'character')})
  if (!isTRUE(all(tables_ind1))) {
    stop("`tables` elements invalidly formatted in call to `bq_nest_fk`", call. = FALSE)
  }

  # * `columns`
  columns_ind1 <- purrr::map_lgl(columns, function(x){expect_data_type(obj = x, type = 'character', nz_len = TRUE)})
  if (!isTRUE(all(columns_ind1))) {
    stop("`columns` elements invalidly formatted in call to `bq_nest_fk`", call. = FALSE)
  }

  columns_length <- purrr::map_dbl(columns, function(x){length(x)})
  if (!isTRUE(length(columns_length) == 2)){stop("`columns` must have length 2 in call to `bq_nest_fk`", call. = FALSE)}
  if (!isTRUE(length(unique(columns_length)) == 1)) {stop("`columns` elements must have equal lengths in call to `bq_nest_fk`", call. = FALSE)}

  # # Compute `child_nest`
  # child_nest <- bq_col_nest(
  #   result = "child_nest",
  #   dataset = tables$child$schema,
  #   table = tables$child$table,
  #   columns = columns$child
  # )
  #
  # # Compute `parent_nest`
  # parent_nest <- bq_col_nest(
  #   result = "parent_nest",
  #   dataset = tables$parent$schema,
  #   table = tables$parent$table,
  #   columns = columns$parent
  # )

  # Use 'bq_fk_sql' to generate final SQL statement
  stmt <- bq_fk_sql(
    result = result,
    child = list(schema = tables$child$schema, table = tables$child$table),
    parent = list(schema = tables$parent$schema, table = tables$parent$table),
    columns = list(child = columns$child, parent = columns$parent)
  )

  # Execute Final SQL Statement
  conn_merch <- gsql_db_connect('merchandising')
  DBI::dbExecute(conn_merch, stmt)
  DBI::dbDisconnect(conn_merch)
  rm(conn_merch)

  # Return Success
  invisible(TRUE)

}

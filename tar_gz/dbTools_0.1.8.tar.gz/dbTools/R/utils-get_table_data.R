
#' Query Data from an existing EDAP PSQL table
#'
#' @param conn character - name of the database containing desired table
#' @param schema character - name of schema containing desired table
#' @param table character - name of desired table
#' @param chunk_size numeric - optionally specify number of rows to pull per result set chunk
#'
#' @return data.frame
#'
get_table_data <- function(conn, schema, table, chunk_size) {

  # Validate Inputs
  if (missing(conn)) {stop("`conn` is missing in call to `get_table_data`", call. = FALSE)}
  if (missing(schema)) {stop("`schema` is missing in call to `get_table_data`", call. = FALSE)}
  if (missing(table)) {stop("`table` is missing in call to `get_table_data`", call. = FALSE)}
  if (missing(chunk_size)) {chunk_size <- NA_real_}

  # Validate Input Expectations

  # * `conn`
  expect_dbi(conn)

  # * `schema`
  expect_scalar_char(schema)

  # * `table`
  expect_scalar_char(table)

  # * `chunk_size`
  expect_data_type(obj = chunk_size, type = 'numeric', is_scalar = TRUE, allow_na = TRUE)
  if (!isTRUE(chunk_size %% 1 == 0) && !isTRUE(is.na(chunk_size))) {
    stop("`chunk_size` must be NA or whole integer in call to `get_table_data`", call. = FALSE)
  }

  # Main Logic
  table_qry <- glue::glue_sql("select * from {`schema`}.{`table`}", .con = conn)

  if (isTRUE(is.na(chunk_size))) {
    res <- DBI::dbGetQuery(conn, table_qry)
  } else {

    res <- list()
    rcnt <- 0

    cursor_has_completed <- FALSE
    cursor <- DBI::dbSendQuery(conn, table_qry)

    while (!isTRUE(cursor_has_completed)) {

      cat("\nFetching Chunk...")
      tictoc::tic()
      chunk <- DBI::dbFetch(cursor, chunk_size) %>% data.table::as.data.table()
      gc()

      if (isTRUE(nrow(chunk) > 0)) {
        res[[length(res)+1]] <- chunk
        rcnt <- rcnt + nrow(chunk)
        cat(paste0("Total Rows: ", rcnt, " - "))
      } else {
        cursor_has_completed <- TRUE
      }

      tictoc::toc()

    }

    cat("\nBinding Results...")
    tictoc::tic()
    res <- data.table::rbindlist(res)
    tictoc::toc()

  }

  # Return Results
  return(res)

}

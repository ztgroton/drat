
# db_proj_field_type ----

#' Construct an Empty S3 Object of class 'db_proj_field_type'
#'
#' @param name character
#'
#' @return S3 Object
#'
new_db_proj_field_type <- function(name) {

  # Define Class Environment
  rs <- new.env()

  # Define Class Members
  rs$name <- name

  # Update Class Path
  class(rs) <- c(setdiff('db_proj_field_type', class(rs)), class(rs))

  # Return Object
  return(rs)

}

#' Validate that 'obj' is properly formatted S3 Object of class 'db_proj_field_type'
#'
#' @param obj S3 Object
#' @param bool TRUE/FALSE - indicates if function should invisibly return 'obj' or 'TRUE/FALSE'
#'
#' @return S3 Object, TRUE/FALSE
#'
validate_db_proj_field_type <- function(obj, bool) {

  # Validate Inputs
  if (missing(obj)) {stop("`obj` is missing in call to `validate_db_proj_field_type`", call. = FALSE)}
  if (missing(bool)) {bool <- FALSE}

  # Validate Input Expectations
  expect_env(obj)
  expect_scalar_logical(bool)

  if (!isTRUE(inherits(obj, 'db_proj_field_type'))) {
    stop("`obj` must inherit from 'db_proj_field_type' in call to `validate_db_proj_field_type`", call. = FALSE)
  }

  # Initialize Empty Error Messages
  errors <- c()

  # * `name`
  if (!isTRUE(expect_scalar_char(obj$name))) {
    err_msg <- "`obj$name` must be a scalar character"
    errors <- c(err_msg, errors)
  }

  # Return Result
  if (isTRUE(length(errors) > 0)) {return(errors)}
  else if (isTRUE(bool)) {return(TRUE)}
  else {invisible(obj)}

}

#' Initialize an S3 Object of class 'db_proj_field_type'
#'
#' @param name character
#'
#' @return S3 Object
#' @export
#'
db_proj_field_type <- function(name) {

  if (missing(name)) {
    stop("`name` is missing in call to `db_proj_field_type`", call. = FALSE)
  }

  new_db_proj_field_type(name) %>% validate_db_proj_field_type()

}

# db_proj_conn_type ----

#' Construct an Empty S3 Object of class 'db_proj_conn_type'
#'
#' @param name character
#'
#' @return S3 Object
#'
new_db_proj_conn_type <- function(name) {

  # Define Class Environment
  rs <- new.env()

  # Define Class Members
  rs$name <- name

  # Update Class Path
  class(rs) <- c(setdiff('db_proj_conn_type', class(rs)), class(rs))

  # Return Object
  return(rs)

}

#' Validate that 'obj' is properly formatted S3 Object of class 'db_proj_conn_type'
#'
#' @param obj S3 Object
#' @param bool TRUE/FALSE - indicates if function should invisibly return 'obj' or 'TRUE/FALSE'
#'
#' @return S3 Object, TRUE/FALSE
#'
validate_db_proj_conn_type <- function(obj, bool) {

  # Validate Inputs
  if (missing(obj)) {stop("`obj` is missing in call to `validate_db_proj_conn_type`", call. = FALSE)}
  if (missing(bool)) {bool <- FALSE}

  # Validate Input Expectations
  expect_env(obj)
  expect_scalar_logical(bool)

  if (!isTRUE(inherits(obj, 'db_proj_conn_type'))) {
    stop("`obj` must inherit from 'db_proj_conn_type' in call to `validate_db_proj_conn_type`", call. = FALSE)
  }

  # Initialize Empty Error Messages
  errors <- c()

  # * `name`
  if (!isTRUE(expect_scalar_char(obj$name))) {
    err_msg <- "`obj$name` must be a scalar character"
    errors <- c(err_msg, errors)
  }

  # Return Result
  if (isTRUE(length(errors) > 0)) {return(errors)}
  else if (isTRUE(bool)) {return(TRUE)}
  else {invisible(obj)}

}

#' Initialize an S3 Object of class 'db_proj_conn_type'
#'
#' @param name character
#'
#' @return S3 Object
#' @export
#'
db_proj_conn_type <- function(name) {

  if (missing(name)) {
    stop("`name` is missing in call to `db_proj_conn_type`", call. = FALSE)
  }

  new_db_proj_conn_type(name) %>% validate_db_proj_conn_type()

}

# db_proj_default_type_map ----

#' Construct an Empty S3 Object of class 'db_proj_default_type_map'
#'
#' @param conn_type character
#' @param field_type character
#' @param sql_type character
#'
#' @return S3 Object
#'
new_db_proj_default_type_map <- function(conn_type, field_type, sql_type) {

  # Define Class Environment
  rs <- new.env()

  # Define Class Members
  rs$conn_type <- conn_type
  rs$field_type <- field_type
  rs$sql_type <- sql_type

  # Update Class Path
  class(rs) <- c(setdiff('db_proj_default_type_map', class(rs)), class(rs))

  # Return Object
  return(rs)

}

#' Validate that 'obj' is properly formatted S3 Object of class 'db_proj_default_type_map'
#'
#' @param obj S3 Object
#' @param bool TRUE/FALSE - indicates if function should invisibly return 'obj' or 'TRUE/FALSE'
#'
#' @return S3 Object, TRUE/FALSE
#'
validate_db_proj_default_type_map <- function(obj, bool) {

  # Validate Inputs
  if (missing(obj)) {stop("`obj` is missing in call to `validate_db_proj_default_type_map`", call. = FALSE)}
  if (missing(bool)) {bool <- FALSE}

  # Validate Input Expectations
  expect_env(obj)
  expect_scalar_logical(bool)

  if (!isTRUE(inherits(obj, 'db_proj_default_type_map'))) {
    stop("`obj` must inherit from 'db_proj_default_type_map' in call to `validate_db_proj_default_type_map`", call. = FALSE)
  }

  # Initialize Empty Error Messages
  errors <- c()

  # * `conn_type`
  if (!isTRUE(expect_scalar_char(obj$conn_type))) {
    err_msg <- "`obj$conn_type` must be a scalar character"
    errors <- c(err_msg, errors)
  }

  # * `field_type`
  if (!isTRUE(expect_scalar_char(obj$field_type))) {
    err_msg <- "`obj$field_type` must be a scalar character"
    errors <- c(err_msg, errors)
  }

  # * `sql_type`
  if (!isTRUE(expect_scalar_char(obj$sql_type))) {
    err_msg <- "`obj$sql_type` must be a scalar character"
    errors <- c(err_msg, errors)
  }

  # Return Result
  if (isTRUE(length(errors) > 0)) {return(errors)}
  else if (isTRUE(bool)) {return(TRUE)}
  else {invisible(obj)}

}

#' Initialize an S3 Object of class 'db_proj_default_type_map'
#'
#' @param conn_type character
#' @param field_type character
#' @param sql_type character
#'
#' @return S3 Object
#' @export
#'
db_proj_default_type_map <- function(conn_type, field_type, sql_type) {

  if (missing(conn_type)) {
    stop("`conn_type` is missing in call to `db_proj_default_type_map`", call. = FALSE)
  }

  if (missing(field_type)) {
    stop("`field_type` is missing in call to `db_proj_default_type_map`", call. = FALSE)
  }

  if (missing(sql_type)) {
    stop("`sql_type` is missing in call to `db_proj_default_type_map`", call. = FALSE)
  }

  new_db_proj_default_type_map(conn_type, field_type, sql_type) %>%
    validate_db_proj_default_type_map()

}

# db_proj_conn ----

#' Construct an Empty S3 Object of class 'db_proj_conn'
#'
#' @param conn character
#' @param type character
#'
#' @return S3 Object
#'
new_db_proj_conn <- function(conn, type) {

  # Define Class Environment
  rs <- new.env()

  # Define Class Members
  rs$conn <- conn
  rs$type <- type

  # Update Class Path
  class(rs) <- c(setdiff('db_proj_conn', class(rs)), class(rs))

  # Return Object
  return(rs)

}

#' Validate that 'obj' is properly formatted S3 Object of class 'db_proj_conn'
#'
#' @param obj S3 Object
#' @param bool TRUE/FALSE - indicates if function should invisibly return 'obj' or 'TRUE/FALSE'
#'
#' @return S3 Object, TRUE/FALSE
#'
validate_db_proj_conn <- function(obj, bool) {

  # Validate Inputs
  if (missing(obj)) {stop("`obj` is missing in call to `validate_db_proj_conn`", call. = FALSE)}
  if (missing(bool)) {bool <- FALSE}

  # Validate Input Expectations
  expect_env(obj)
  expect_scalar_logical(bool)

  if (!isTRUE(inherits(obj, 'db_proj_conn'))) {
    stop("`obj` must inherit from 'db_proj_conn' in call to `validate_db_proj_conn`", call. = FALSE)
  }

  # Initialize Empty Error Messages
  errors <- c()

  # * `conn`
  if (!isTRUE(expect_scalar_char(obj$conn))) {
    err_msg <- "`obj$conn` must be a scalar character"
    errors <- c(err_msg, errors)
  }

  # * `type`
  if (!isTRUE(expect_scalar_char(obj$type))) {
    err_msg <- "`obj$type` must be a scalar character"
    errors <- c(err_msg, errors)
  }

  # Return Result
  if (isTRUE(length(errors) > 0)) {return(errors)}
  else if (isTRUE(bool)) {return(TRUE)}
  else {invisible(obj)}

}

#' Initialize an S3 Object of class 'db_proj_conn'
#'
#' @param conn character
#' @param type character
#'
#' @return S3 Object
#' @export
#'
db_proj_conn <- function(conn, type) {

  if (missing(conn)) {
    stop("`conn` is missing in call to `db_proj_conn`", call. = FALSE)
  }

  if (missing(type)) {
    stop("`type` is missing in call to `db_proj_conn`", call. = FALSE)
  }

  new_db_proj_conn(conn, type) %>%
    validate_db_proj_conn()

}

# db_proj_conn_param ----

#' Construct an Empty S3 Object of class 'db_proj_conn_param'
#'
#' @param conn character
#' @param param character
#' @param value character
#'
#' @return S3 Object
#'
new_db_proj_conn_param <- function(conn, param, value) {

  # Define Class Environment
  rs <- new.env()

  # Define Class Members
  rs$conn <- conn
  rs$param <- param
  rs$value <- value

  # Update Class Path
  class(rs) <- c(setdiff('db_proj_conn_param', class(rs)), class(rs))

  # Return Object
  return(rs)

}

#' Validate that 'obj' is properly formatted S3 Object of class 'db_proj_conn_param'
#'
#' @param obj S3 Object
#' @param bool TRUE/FALSE - indicates if function should invisibly return 'obj' or 'TRUE/FALSE'
#'
#' @return S3 Object, TRUE/FALSE
#'
validate_db_proj_conn_param <- function(obj, bool) {

  # Validate Inputs
  if (missing(obj)) {stop("`obj` is missing in call to `validate_db_proj_conn_param`", call. = FALSE)}
  if (missing(bool)) {bool <- FALSE}

  # Validate Input Expectations
  expect_env(obj)
  expect_scalar_logical(bool)

  if (!isTRUE(inherits(obj, 'db_proj_conn'))) {
    stop("`obj` must inherit from 'db_proj_conn' in call to `validate_db_proj_conn`", call. = FALSE)
  }

  # Initialize Empty Error Messages
  errors <- c()

  # * `conn`
  if (!isTRUE(expect_scalar_char(obj$conn))) {
    err_msg <- "`obj$conn` must be a scalar character"
    errors <- c(err_msg, errors)
  }

  # * `param`
  if (!isTRUE(expect_scalar_char(obj$param))) {
    err_msg <- "`obj$param` must be a scalar character"
    errors <- c(err_msg, errors)
  }

  # * `value`
  if (!isTRUE(expect_scalar_char(obj$value))) {
    err_msg <- "`obj$value` must be a scalar character"
    errors <- c(err_msg, errors)
  }

  # Return Result
  if (isTRUE(length(errors) > 0)) {return(errors)}
  else if (isTRUE(bool)) {return(TRUE)}
  else {invisible(obj)}

}

#' Initialize an S3 Object of class 'db_proj_conn_param'
#'
#' @param conn character
#' @param param character
#' @param value character
#'
#' @return S3 Object
#' @export
#'
db_proj_conn_param <- function(conn, param, value) {

  new_db_proj_conn_param(conn, param, value) %>%
    validate_db_proj_conn_param()

}

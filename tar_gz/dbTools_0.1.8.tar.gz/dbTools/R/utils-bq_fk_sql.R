
#' Generate BigQuery SQL Statement for Generating 'nest_fk' table from two existing 'nest_pk' tables
#'
#' @param result character
#' @param child list
#' @param parent list
#' @param columns list
#'
#' @return TRUE
#' @export
#'
bq_fk_sql <- function(result, child, parent, columns) {

  # Validate Inputs
  if (missing(result)) {stop("`result` is missing in call to `bk_fk_sql`", call. = FALSE)}
  if (missing(child)) {stop("`child` is missing in call to `bq_fk_sql`", call. = FALSE)}
  if (missing(parent)) {stop("`parent` is missing in call to `bq_fk_sql`", call. = FALSE)}
  if (missing(columns)) {stop("`columns` is missing in call to `bq_fk_sql`", call. = FALSE)}

  # Validate Input Expectations

  # * `result`
  expect_scalar_char(result)

  # * `child`
  expect_list(child, names = c('schema', 'table'), type = 'character')

  # * `parent`
  expect_list(parent, names = c('schema', 'table'), type = 'character')

  # * `columns`
  expect_list(columns, names = c('child', 'parent'), type = 'character')
  columns_ind <- purrr::map_lgl(columns, function(x){expect_data_type(obj = x, type = 'character', nz_len = TRUE)})
  if (!isTRUE(all(columns_ind))) {
    stop("`columns` elements invalidly formatted in call to `bq_nest_fk`", call. = FALSE)
  }

  columns_length <- purrr::map_dbl(columns, function(x){length(x)})
  if (!isTRUE(length(columns_length) == 2)){stop("`columns` must have length 2 in call to `bq_nest_fk`", call. = FALSE)}
  if (!isTRUE(length(unique(columns_length)) == 1)) {stop("`columns` elements must have equal lengths in call to `bq_nest_fk`", call. = FALSE)}

  # Read SQL Template
  sql_tmp <- readr::read_file(system.file("sql/col_nest/bq_fk.sql", package = 'dbTools'))

  # Initialize SQL 'glue' parameters

  # * `child_columns_w_comma`
  child_columns_w_comma <- paste0(paste0('t1.', columns$child), collapse = ', ')

  # * `child_schema`
  child_schema <- child$schema

  # * `child_table`
  child_table <- child$table

  # * `child_join`
  child_join <- paste('ON ', paste0(paste0('t.', columns$child, ' = ct.', columns$child), collapse = ' AND '))

  # * `parent_columns_w_comma_and_names`
  parent_columns_w_comma_and_names <- paste0(paste0('t2.', columns$parent, ' as ', columns$child), collapse = ', ')

  # * `parent_columns_w_comma`
  parent_columns_w_comma <- paste0(paste0('t2.', columns$parent), collapse = ', ')

  # * `parent_schema`
  parent_schema <- parent$schema

  # * `parent_table`
  parent_table <- parent$table

  # * `parent_join`
  parent_join <- paste('ON ', paste0(paste0('t.', columns$child, ' = pt.', columns$parent), collapse = ' AND '))

  # Generate SQL Statement
  stmt <- glue::glue(sql_tmp)

  # Return Statement
  return(stmt)

}

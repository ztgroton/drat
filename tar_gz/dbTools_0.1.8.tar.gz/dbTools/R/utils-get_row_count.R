
#' Query Row Count from an existing EDAP PSQL table
#'
#' @param conn character - name of the database containing desired table
#' @param schema character - name of schema containing desired table
#' @param table character - name of desired table
#'
#' @return data.frame
#'
get_row_count <- function(conn, schema, table) {

  # Validate Inputs
  if (missing(conn)) {stop("`conn` is missing in call to `get_row_count`", call. = FALSE)}
  if (missing(schema)) {stop("`schema` is missing in call to `get_row_count`", call. = FALSE)}
  if (missing(table)) {stop("`table` is missing in call to `get_row_count`", call. = FALSE)}

  # Validate Input Expectations
  expect_dbi(conn)
  expect_scalar_char(schema)
  expect_scalar_char(table)

  table_qry <- glue::glue_sql(
    "select count(*) as rowcnt from {`schema`}.{`table`}",
    .con = conn
  )

  res <- DBI::dbGetQuery(conn, table_qry)

  return(res$rowcnt)

}


#' Validate if a set of columns 'x' is a Primary Key on data.frame 'data'
#'
#' @importFrom rlang .data
#'
#' @param data data.frame - The data.frame containing data to be tested.
#' @param x character - Vector of column names from 'data', defining the LHS of a functional dependency candidate.
#' @param y character - Vector of column names from 'data', defining the RHS of a functional dependency candidate.
#'
#' @return R Object
#' @export
#'
r_col_fd <- function(data, x, y) {

  # Validate Inputs

  # * `data`
  if (missing(data)) {stop("`data` is missing in call to `r_col_fd`", call. = FALSE)}
  if (!isTRUE(is.data.frame(data))) {stop("`data` must be `data.frame` in call to `r_col_fd`", call. = FALSE)}

  # * `x`
  if (missing(x)) {stop("`x` is missing in call to `r_col_fd`", call. = FALSE)}
  if (!isTRUE(all(x %in% colnames(data)))) {
    stop("`x` must be subset of `colnames(data)` in call to `r_col_fd`", call. = FALSE)
  }

  # * `y`
  if (missing(y)) {stop("`y` is missing in call to `r_col_fd`", call. = FALSE)}
  if (!isTRUE(all(y %in% colnames(data)))) {
    stop("`y` must be subset of `colnames(data)` in call to `r_col_fd`", call. = FALSE)
  }

  # * `x` and `y`
  if (!isTRUE(length(intersect(x,y)) == 0)) {
    stop("`x` and `y` must be disjoint sets in call to `r_col_fd`", call. = FALSE)
  }

  # Nest row numbers of `data` by `x` columns
  x_nest <- r_col_nest(data, x) %>%
    dplyr::rename(
      x_row_num = .data$nest_row_num,
      x_row_cnt = .data$nest_row_cnt
    )

  # Nest row numbers of `data` by `x` and `y` columns
  xy_nest <- r_col_nest(data, union(x,y)) %>%
    dplyr::rename(
      xy_row_num = .data$nest_row_num,
      xy_row_cnt = .data$nest_row_cnt
    )

  # Full Join `x_nest` and `xy_nest`
  result <- xy_nest %>% dplyr::left_join(x_nest)

  # Return Result
  class(result) <- c('r_col_fd', unique(setdiff(class(result), 'r_col_fd')))
  return(result)

}

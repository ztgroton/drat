
#' Validates that the input object is an S3 Object of class 'bq_table'
#'
#' @param tbl S3 Object
#'
#' @return TRUE
#' @export
#'
bq_tbl_validate <- function(tbl) {

  # Validate Inputs
  if (missing(tbl)) {stop("`tbl` is missing in call to `bq_tbl_validate`", call. = FALSE)}

  # Validate Input Expectations
  if (!isTRUE(inherits(tbl, 'bq_table'))) {return(FALSE)}

  # Return TRUE
  return(TRUE)

}

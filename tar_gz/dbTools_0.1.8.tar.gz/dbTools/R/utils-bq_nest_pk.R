
#' Validate if a set of columns 'pk' is a Primary Key on data.frame 'x'
#'
#' @importFrom rlang .data
#'
#' @param result character
#' @param dataset character
#' @param table character
#' @param columns character
#'
#' @return R Object
#' @export
#'
bq_nest_pk <- function(result, dataset, table, columns) {

  # Validate Inputs
  if (missing(result)) {stop("`result` is mising in call to `bq_col_nest`", call. = FALSE)}
  if (missing(dataset)) {stop("`dataset` is mising in call to `bq_col_nest`", call. = FALSE)}
  if (missing(table)) {stop("`table` is missing in call to `bq_col_nest`", call. = FALSE)}
  if (missing(columns)) {stop("`columns` is missing in call to `bq_col_nest`", call. = FALSE)}

  # Validate Input Expectations
  expect_scalar_char(result)
  expect_scalar_char(dataset)
  expect_scalar_char(table)
  expect_data_type(obj = columns, type = 'character', nz_len = TRUE)

  # Nest row numbers of `x` by `pk` columns
  x_nest <- bq_col_nest(result, dataset, table, columns)

  # Return Result
  class(x_nest) <- c(setdiff('bq_nest_pk', class(x_nest)), class(x_nest))
  return(x_nest)

}


#' Create Blank 'db_projects' Database
#'
#' @export
#'
setup_db_projects <- function() {

  # Initialize Root Directory
  ddl_dir <- system.file(paste0('sql/db_projects/psql/ddl/create_table/'), package = 'dbTools')
  if (!isTRUE(dir.exists(ddl_dir))) {
    stop(paste0("`psql` directory does not exist in call to `setup_db_projects`"), call. = FALSE)
  }

  # Query Directory Contents
  ddl_contents <- list.files(path = ddl_dir, pattern = "*.sql", full.names = FALSE, recursive = FALSE)
  if (isTRUE(length(ddl_contents) == 0)) {
    stop("`ddl_dir` contains no SQL queries in call to `setup_db_projects`", call. = FALSE)
  }

  # Open PSQL Connection
  psql_conn <- psql_db_connect('db_projects')

  # Clear Existing Schema
  clear_db_projects()

  # Create `common` schema
  DBI::dbExecute(psql_conn, "CREATE SCHEMA common")

  # Iterate over Directory Contents
  for (ddl_file in sort(ddl_contents)) {
    qry <- readr::read_file(file.path(ddl_dir, ddl_file))
    DBI::dbExecute(psql_conn, qry)
  }

  # Close PSQL Connection
  DBI::dbDisconnect(psql_conn)
  rm(psql_conn)

  # Return Success
  invisible(TRUE)

}

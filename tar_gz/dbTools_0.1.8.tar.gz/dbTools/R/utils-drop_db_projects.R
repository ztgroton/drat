
#' Drop 'db_projects' Database
#'
#' @export
#'
drop_db_projects <- function() {

  # Open PSQL Connection
  psql_conn <- psql_db_connect('postgres')

  # Drop Database
  DBI::dbExecute(psql_conn, "DROP DATABASE db_projects")

  # Close PSQL Connection
  DBI::dbDisconnect(psql_conn)
  rm(psql_conn)

}


#' dbLearn
#'
#' @param db character vector
#' @param schema character vector
#'
#' @importFrom rlang .data
#'
#' @return R Object
#' @export
#'
dbLearn <- function(db, schema) {

  # Validate Inputs

  # * `db`
  if (missing(db)) {stop("`db` is missing in call to `dbLearn`", call. = FALSE)}
  expect_scalar_char(db)

  mssql_db_list <- get_db('mssql')
  psql_db_list <- get_db('psql')

  is_db_mssql <- isTRUE(db %in% mssql_db_list)
  is_db_psql <- isTRUE(db %in% psql_db_list)

  if (!isTRUE(is_db_mssql) && !isTRUE(is_db_psql)) {
    stop("`db` must be a known PSQL or MSSQL database in call to `dbLearn`")
  } else if (isTRUE(is_db_mssql) && isTRUE(is_db_psql)) {
    stop("ERROR: `db` has ambiguous database type", call. = FALSE)
  }

  # * `schema`
  if (missing(schema)) {stop("`schema` is missing in call to `dbLearn`", call. = FALSE)}
  expect_scalar_char(schema)

  cat(paste0("`dbLearn` ", db, " - ", schema, " \n\n"))

  # Learn Tables/Columns ----
  cat("Learning Tables/Columns... ")
  tictoc::tic()
  if (isTRUE(is_db_psql)) {tables <- table_column_psql(db = db, schema = schema)}
  else if (isTRUE(is_db_mssql)) {tables <- table_column_mssql(db = db, schema = schema)}
  tictoc::toc()

  # Learn Primary Keys ----
  cat("Learning Primary Keys... ")
  tictoc::tic()
  if (isTRUE(is_db_psql)) {primary_key <- pk_psql(db = db, schema = schema)}
  else if (isTRUE(is_db_mssql)) {primary_key <- pk_mssql(db = db, schema = schema)}
  tictoc::toc()

  # Learn Foreign Keys ----
  cat("Learning Foreign Keys... ")
  tictoc::tic()
  if (isTRUE(is_db_psql)) {foreign_key <- fk_psql(db = db, schema = schema)}
  else if (isTRUE(is_db_mssql)) {foreign_key <- fk_mssql(db = db, schema = schema)}
  tictoc::toc()

  # Return Results
  res <- list(
    tables = tables,
    primary_key = primary_key,
    foreign_key = foreign_key
  )

  cat("`dbLearn` Complete\n\n")

  class(res) <- append('dbLearn', class(res))
  return(res)

}

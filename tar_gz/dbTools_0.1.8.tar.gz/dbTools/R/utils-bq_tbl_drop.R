
#' Drop an existing BigQuery table referenced by 'tbl'
#'
#' @param tbl S3 Object
#'
#' @return TRUE
#' @export
#'
bq_tbl_drop <- function(tbl) {

  # Validate Inputs
  if (missing(tbl)) {stop("`tbl` is missing in call to `bq_tbl_drop`", call. = FALSE)}

  # Validate Input Expectations
  if (!isTRUE(inherits(tbl, 'bq_table'))) {
    stop("`tbl` must inherit from S3 class 'bq_table' in call to `bq_tbl_drop`", call. = FALSE)
  }

  # Return Result
  res <- isTRUE(bigrquery::bq_table_delete(tbl))
  return(res)

}

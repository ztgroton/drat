test_that("`mssql_db_connect` works", {
  expect_true(is_mssql(mssql_db_connect('Apex')))
})


#' Validate User-Specified Cell Edit Constraints against Target DataFrame
#'
#' @param dt data.frame
#' @param constraints named list
#'
#' @return TRUE
#' @export
#'
#' @examples
#' \dontrun{
#' output <- validate_dt_edit_constraint(
#'    dt = input_data,
#'    constraints = list(lte_prev = c('sales_dollars'))
#' )
#' }
validate_dt_edit_constraint <- function(dt, constraints) {

  # Validate Inputs ----
  if (missing(dt)) {stop("`dt` is missing in call to `validate_dt_edit_constraint`")}
  if (missing(constraints)) {stop("`constraints` is missing in call to `validate_dt_edit_contraint`")}

  # Validate Input Exectations ----

  # * dt ----
  if (!isTRUE(is.data.frame(dt))) {
    stop("`dt` must be data.frame in call to `validate_dt_edit_constraint`")
  }

  # * constraints ----
  if (!isTRUE(is.list(constraints)) || !isTRUE(length(constraints) > 0)) {
    stop("`constraints` must be non-empty list in call to `validate_dt_edit_constraint`")
  }

  expected_names <- c('rank_range')
  if (
       !isTRUE(names(constraints) %in% expected_names)
    || !isTRUE(length(names(constraints)) == length(unique(names(constraints))))
  ) {
    stop("`names(constraints)` must be unique and be a subset of expected names in call to `validate_dt_edit_constraint`")
  }

  # elem_is_valid <- purrr::map_lgl(constraints, function(x){isTRUE(is.character(x))})
  # if (!isTRUE(all(elem_is_valid))) {
  #   stop("`constraints` must only contain elements that are character vectors in call to `validate_dt_edit_constraint`")
  # }
  #
  # elem_is_subset <- purrr::map_lgl(constraints, function(x) {isTRUE(all(x %in% colnames(dt)))})
  # if (!isTRUE(all(elem_is_subset))) {
  #   stop("`constraints` must only contain elements that are subsets of `colnames(dt)` in call to `validate_dt_edit_constraint`")
  # }

  if (isTRUE('rank_range' %in% names(constraints))) {

    if (!isTRUE(identical(names(constraints[['rank_range']]), c('rank', 'min_rank', 'max_rank', 'rank_label')))) {
      stop("`names(constraints[['rank_range']])` does not have expected values in call to `validate_dt_edit_constraint`")
    }

    elem_is_valid <- purrr::map_lgl(constraints[['rank_range']], function(x){isTRUE(is.character(x))})
    if (!isTRUE(all(elem_is_valid))) {
      stop("`constraints[['rank_range']]` must only contain elements that are character vectors in call to `validate_dt_edit_constraint`")
    }

    elem_is_subset <- purrr::map_lgl(constraints[['rank_range']], function(x) {isTRUE(all(x %in% colnames(dt))) && isTRUE(length(x) == 1)})
    if (!isTRUE(all(elem_is_subset))) {
      stop("`constraints[['rank_range']]` must only contain elements that are elements of `colnames(dt)` in call to `validate_dt_edit_constraint`")
    }

  }

  # MAIN LOGIC ----

  # Return Success
  invisible(TRUE)

}

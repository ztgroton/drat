
#' Perform Clause Operation
#'
#' @param df data.frame
#' @param operator character
#' @param column character
#' @param condition R Object
#'
#' @return logical
#' @export
#'
#' @examples
#' \dontrun{
#' output <- do_clause_op(df, 'Item_Name', '==', "Tito's Handmade Vodka")
#' }
do_clause_op <- function(df, operator, column, condition) {

  # Validate Inputs
  if (missing(df)) {stop("`df` is missing in call to `do_clause_op`")}
  if (missing(operator)) {stop("`operator` is missing in call to `do_clause_op`")}
  if (missing(column)) {stop("`column` is missing in call to `do_clause_op`")}
  if (missing(condition)) {stop("`condition` is missing in call to `do_clause_op`")}

  # Validate Input Expectations

  # * `column`
  if (!isTRUE(is.character(column)) ||
      !isTRUE(length(column) == 1) ||
      isTRUE(is.na(column))
  ) {
    stop("`column` is missing in call to `do_clause_op`")
  }

  # * `operator`
  if (!isTRUE(is.character(operator)) ||
      !isTRUE(length(operator) == 1) ||
      isTRUE(is.na(operator))
  ) {
    stop("`operator` is missing in call to `do_clause_op`")
  }

  # Define `%notin%`
  `%notin%` <- Negate(`%in%`)

  # MAIN LOGIC

  if (operator == '==') {
    column <- df[[column]]
    return(column %in% condition)
  }

  ###### '!=' ######
  if (operator == '!=') {
    column <- df[[column]]
    return(column %notin% condition)
  }

  ###### '<' ######
  else if (operator == '<') {
    column <- df[[column]]
    return(column < condition)
  }

  ###### '>' ######
  else if (operator == '>') {
    column <- df[[column]]
    return(column > condition)
  }

  ###### '<=' ######
  else if (operator == '<=') {
    column <- df[[column]]
    return(column <= condition)
  }

  ###### '>=' ######
  else if (operator == '>=') {
    column <- df[[column]]
    return(column >= condition)
  }

  ###### 'BETWEEN' ######
  else if (operator == 'BETWEEN') {
    column <- df[[column]]
    return(dplyr::between(x = column, left = condition[1], right = condition[2]))
  }

  ###### 'IN' ######
  else if (operator == 'IN') {
    column <- df[[column]]
    return(column %in% condition)
  }

  ###### 'DATE RANGE' ######
  else if (operator == 'IN DATE RANGE') {

    column <- as.Date(df[[column]])

    op2_tokens <- unlist(strsplit(condition, " "))

    num <- as.numeric(op2_tokens[3])
    last_next <- ""
    bda <- ""
    intr <- ""
    final_expr <- ""

    if (op2_tokens[2] == 'Last') { last_next <- 'Last' } else { last_next <- 'Next' }

    if (op2_tokens[1] == 'Before') { bda <- 'Before' }
    else if (op2_tokens[1] == 'During') { bda <- 'During'}
    else { bda <- 'After' }

    if (op2_tokens[4] == 'Day(s)') {

      if (last_next == 'Last') { intr <- lubridate::interval(start = lubridate::today() - lubridate::days(num), end = lubridate::today()) }
      else { intr <- lubridate::interval(start = lubridate::today(), end = lubridate::today() + lubridate::days(num)) }

    }
    else if (op2_tokens[4] == 'Week(s)') {

      if (last_next == 'Last') { intr <- lubridate::interval(start = lubridate::today() - lubridate::weeks(num), end = lubridate::today()) }
      else { intr <- lubridate::interval(start = lubridate::today(), end = lubridate::today() + lubridate::weeks(num)) }

    }
    else if (op2_tokens[4] == 'Month(s)') {

      if (last_next == 'Last') { intr <- lubridate::interval(start = lubridate::today() - months(num), end = lubridate::today()) }
      else { intr <- lubridate::interval(start = lubridate::today(), end = lubridate::today() + months(num)) }

    }
    else {

      if (last_next == 'Last') { intr <- lubridate::interval(start = lubridate::today() - lubridate::years(num), end = lubridate::today()) }
      else { intr <- lubridate::interval(start = lubridate::today(), end = lubridate::today() + lubridate::years(num)) }

    }

    if (bda == 'Before') { return(column < lubridate::int_start(intr)) }
    else if (bda == 'After') { return(column > lubridate::int_end(intr)) }
    else { return(lubridate::`%within%`(column, intr)) }

  }

}

#' Convert 'clauseDynamic' Module Outputs into R Expression (Returned as String)
#'
#' @param df data.frame
#' @param column character
#' @param operator character
#' @param condition R Object
#'
#' @return logical
#' @export
#'
#' @examples
#' \dontrun{
#' output <- eval_clause('Item_Name', '==', "Tito's Handmade Vodka")
#' }
eval_clause <- function(df, column, operator, condition) {

  # Validate Inputs
  if (missing(df)) {stop("`df` is missing in call to `eval_clause`")}
  if (missing(column)) {stop("`column` is missing in call to `eval_clause`")}
  if (missing(operator)) {stop("`operator` is missing in call to `eval_clause`")}
  if (missing(condition)) {stop("`condition` is missing in call to `eval_clause`")}

  # Validate Input Expectations

  # * `df`
  if (!isTRUE(is.data.frame(df))) {
    stop("`df` must be data.frame in call to `eval_clause`")
  }

  # * `column`
  if (!isTRUE(is.character(column)) ||
      !isTRUE(length(column) == 1) ||
      isTRUE(is.na(column))
     ) {
    stop("`column` must be non-NA, length 1 character in call to `eval_clause`")
  }

  # * `operator`
  if (!isTRUE(is.character(operator)) ||
      !isTRUE(length(operator) == 1) ||
      isTRUE(is.na(operator))
  ) {
    stop("`operator` must be non-NA, length 1 character in call to `eval_clause`")
  }

  # Evaluate Clause Expression
  op_result <- do_clause_op(operator = operator, column = column, condition = condition, df = df)
  op_result <- tidyr::replace_na(op_result, FALSE)

  # Return `op_result`
  return(op_result)

}

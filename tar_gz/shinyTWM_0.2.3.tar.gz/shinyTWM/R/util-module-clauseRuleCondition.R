
#' Shiny Module UI - `clauseRuleOperator`
#'
#' @import shiny
#' @import shinyWidgets
#'
#' @param id character - Unique identifier for module instance
#' @param data data.frame - Reactive Expression
#' @param column character - Reactive Expression
#' @param type character - Reactive Expression
#' @param operator character - Reactive Expression
#'
#' @return R Shiny Tags
#' @export
#'
#' @examples
#' \dontrun{
#' clauseRuleCondition_ui('test', data, column, type, operator)
#' }
clauseRuleCondition_ui <- function(id, data, column, type, operator) {

  # Session Namespace
  ns <- NS(id)

  if ( length(intersect(type(), c("character", "factor"))) > 0 ) {

    tagList(
      shinyWidgets::virtualSelectInput(
        ns("rule_condition_control"),
        label = NULL,
        choices = sort(unique(data()[[column()]])),
        selected = NULL,
        multiple = TRUE,
        search = TRUE,
        width = '100%'
      )
    )

  } else if ( length(intersect(type(), c("logical"))) > 0 ) {

    tagList(
      pickerInput(
        ns("rule_condition_control"),
        label = NULL,
        selected = TRUE,
        choices = c(TRUE, FALSE),
        width = '100%'
      )
    )

  } else if ( length(intersect(type(), c("integer", "numeric"))) > 0 ) {

    if (operator() == "BETWEEN") {

      tagList(
        numericRangeInput(
          ns("rule_condition_control"),
          label = NULL,
          value = c(0,10),
          width = '100%'
        )
      )

    } else {

      tagList(
        numericInput(
          ns("rule_condition_control"),
          label = NULL,
          value = 0,
          width = '100%'
        )
      )

    }

  } else if ( length(intersect(type(), c("POSIXct", "Date"))) > 0 ) {

    if (operator() == "BETWEEN") {

      tagList(
        dateRangeInput(
          ns("rule_condition_control"),
          label = NULL,
          start = "2023-01-01",
          end = "2023-12-31",
          width = '100%'
        )
      )

    } else if (operator() == "IN DATE RANGE") {

      tagList(
        splitLayout(
          style = 'width: 100%%',
          pickerInput(
            ns("rule_condition_control_1"),
            label = NULL,
            selected = 'During',
            choices = c('Before', 'During', 'After'),
            width = '100%'
          ),
          pickerInput(
            ns("rule_condition_control_2"),
            label = NULL,
            selected = 'Last',
            choices = c('Last', 'Next'),
            width = '100%'
          ),
          numericInput(
            ns("rule_condition_control_3"),
            label = NULL,
            value = 1,
            min = 1,
            step = 1,
            width = '100%'
          ),
          pickerInput(
            ns("rule_condition_control_4"),
            label = NULL,
            selected = 'Month(s)',
            choices = c('Day(s)', 'Week(s)', 'Month(s)', 'Year(s)'),
            width = '100%'
          )
        )
      )

    } else {

      tagList(
        dateInput(
          ns("rule_condition_control"),
          label = NULL,
          value = "2023-01-01",
          width = '100%'
        )
      )

    }

  } else {
    tagList(
      HTML(type())
    )
  }

}

#' Shiny Module Server - `clauseRuleCondition`
#'
#' @param id character - Unique identifier for module instance
#' @param column character - Reactive Expression
#' @param operator character - Reactive Expression
#'
#' @return R Shiny Reactive Expression
#' @export
#'
#' @examples
#' \dontrun{
#' x <- clauseRuleCondition_server('test', column, operator)
#' }
clauseRuleCondition_server <- function(id, column, operator) {

  moduleServer(id, function(input, output, session) {

    # Session Namespace
    ns <- session$ns

    # ____________ ----
    # MODULE RETURN VALUE ----
    result <- shiny::reactive({

      req(column())
      req(operator())

      list(
        column = column(),
        operator = operator(),
        condition = if (operator() == 'IN DATE RANGE') {
          paste(
            input$rule_condition_control_1,
            input$rule_condition_control_2,
            input$rule_condition_control_3,
            input$rule_condition_control_4,
            sep = " "
          )
        } else {
          input$rule_condition_control
        }
      )

    })

    return(result)

    # _______________________ ----
    # END OF MODULE SERVER ----

  })

}

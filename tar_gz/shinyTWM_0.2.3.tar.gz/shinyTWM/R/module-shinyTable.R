
#' shinyTable_ui
#'
#' @param id character - A non-na, length 1 character vector
#'
#' @importFrom shiny tags
#'
#' @return fluidPage - UI for Shiny Module 'shinyTable'
#' @export
shinyTable_ui <- function(id) {

  ns <- shiny::NS(id)

  shiny::fluidPage(

    tags$head(
      # Note the wrapping of the string in HTML()
      tags$style(shiny::HTML("

      .dataTables_scroll {
        overflow-x:scroll;
        white-space: nowrap;
        display: flex;
        flex-direction: column;
        transform: rotateX(180deg);
      }

      .dataTables_scrollBody {
        overflow: unset !important;
        white-space: nowrap;
        order:1;
        transform: rotateX(180deg);
      }

      .dataTables_scrollHead {
        overflow: unset !important;
        white-space: nowrap;
        z-index: 10;
        order:2;
        transform: rotateX(180deg);
      }

      label {
        display: table-cell;
        text-align: center;
        vertical-align: middle;
        padding-right: 5px;
      }

      .form-group {
        display: table-row;
      }

      div.col-sm-3 {
        padding: 0px !important;
      }

      label.control-label {
        white-space: nowrap !important;
      }

      div.shiny_twm_footer {
        display: flex !important;
        justify-content: space-between !important;
      }

      div.shiny_twm_footer_elem {
        display: flex !important;
        justify-content: space-between !important;
      }

      "))
    ),

    shiny::column(
      width = 3,
      shinyWidgets::dropMenu(

        shiny::actionButton(
          inputId = ns('filter_btn'),
          label = 'Filter',
          width = '100%',
          shiny::icon("filter")
        ),

        shiny::splitLayout(
          style = "width:100%",
          shiny::actionButton(
            ns('add_clause_btn'),
            "Add Filter",
            width = '100%',
            style = "font-weight:bold;"
          ),
          shiny::actionButton(
            ns('drop_clause_btn'),
            "Drop Filter",
            width = '100%',
            style = "font-weight:bold;"
          )
        ),

        tags$div(id = ns('rule_builder_ui_placeholder'), style = "width:100%")

      )
    ),

    shiny::column(
      width = 3,
      shinyWidgets::dropMenu(

        shiny::actionButton(
          inputId = ns('layout_btn'),
          label = 'Layout',
          width = '100%',
          shiny::icon("list")
        ),

        shiny::numericInput(
          inputId = ns('table_page_length'),
          label = 'Page - # of Rows', value = 10,
          min = 0, max = 100, step = 1
        ),

        shiny::splitLayout(
          shiny::actionButton(inputId = ns('table_page_prev'), "Prev Page", width = '100%'),
          shiny::actionButton(inputId = ns('table_page_next'), "Next Page", width = '100%')
        )

      )
    ),

    shiny::column(
      width = 3,
      shinyWidgets::dropMenu(

        shiny::actionButton(
          inputId = ns('config_btn'),
          label = 'Config',
          width = '100%',
          shiny::icon("gear")
        ),

        shiny::radioButtons(
          inputId = ns("multi_row_selection"),
          label = NULL,
          choiceNames = c('Single Only', 'Multi-Row'),
          choiceValues = c(FALSE, TRUE),
          selected = FALSE, inline = TRUE
        )

      )
    ),

    shiny::column(
      width = 3,
      shinyWidgets::dropMenu(

        shiny::actionButton(
          inputId = ns('export_btn'),
          label = 'Export',
          width = '100%',
          shiny::icon("paper-plane")
        ),

        shiny::uiOutput(ns('download_ui'))
      )
    ),

    shiny::column(
      width = 12,
      DT::DTOutput(ns('table'))

    )

  )

}

#' shinyTable_server
#'
#' @param id character - A non-na, length 1 character vector
#' @param data data.frame - A valid data.frame object to display as table.
#' @param col_hide character - Optional list of column names to hide from display.
#' @param cnst list
#'
#' @importFrom rlang .data
#' @importFrom utils write.csv
#'
#' @return moduleServer - SERVER for Shiny Module 'shinyTable'
#' @export
shinyTable_server <- function(id, data, col_hide, cnst) {

  shiny::moduleServer(
    id = id,
    function(input, output, session) {

      # Session Namespace ----
      ns <- session$ns

      # _____________________________________ ----
      # MODULE INPUT REACTIVE EXPRESSIONS ----

      # * col_show() ----
      col_show <- shiny::reactive({

        shiny::req(rvalues$col_hidden)
        shiny::req(rvalues$table_data)

        if (!isTRUE(is.data.frame(rvalues$table_data))) {
          shinyWidgets::show_toast(
            title = "Invalid Data Table!!!",
            type = "error",
            position = "bottom"
          )
        } else {
          res <- setdiff(colnames(rvalues$table_data), rvalues$col_hidden)
          return(res)
        }

      })

      # * table_show ----
      table_show <- shiny::reactive({

        shiny::req(col_show())
        shiny::req(rvalues$table_data)

        res <- rvalues$table_data[, c(col_show()), drop = F]
        return(res)

      })

      # _______________________________ ----
      # GLOBAL REACTIVE VALUES ----

      # * rrules ----
      rrules <- shiny::reactiveValues(
        clause_num = 0,
        clause_reactive_list = list()
      )

      # * rvalues ----
      rvalues <- shiny::reactiveValues(
        cell_clicked = NULL,
        cell_edit = NULL,
        table_data = NULL,
        col_hidden = NULL
      )

      # * rcnst ----
      rcnst <- shiny::reactiveValues(
        values = cnst
      )

      # _______________________________ ----
      # GLOBAL REACTIVE EXPRESSIONS ----

      # * table_page_length() ----
      table_page_length <- shiny::reactive({

        shiny::req(input$table_page_length)
        return(input$table_page_length)

      })

      # * table_row_selection() ----
      table_row_selection <- shiny::reactive({

        shiny::req(input$multi_row_selection)

        if (isTRUE(input$multi_row_selection == "TRUE")) {
          return('multiple')
        } else {
          return('single')
        }

      })

      # * clause_reactive() ----
      clause_reactive <- shiny::reactive({

        if (isTRUE(length(rrules$clause_reactive_list) > 0)) {

          res <- purrr::map(names(rrules$clause_reactive_list), function(x) {
            return(rrules$clause_reactive_list[[x]]())
          })
          names(res) <- names(rrules$clause_reactive_list)

          return(res)

        } else {
          return(list())
        }

      })

      # * clause_reactive_val() ----
      clause_reactive_val <- shiny::reactive({

        req(rvalues$table_data)
        req(clause_reactive())

        if (isTRUE(length(clause_reactive()) > 0)) {

          res <- purrr::map(names(clause_reactive()), function(x) {

            clause_x <- clause_reactive()[[x]]

            if (!isTRUE(is.null(clause_x$condition))) {
              eval_clause(
                df = rvalues$table_data,
                column = clause_x$column,
                operator = clause_x$operator,
                condition = clause_x$condition
              ) -> res_x
            } else {
              res_x <- NA
            }

            return(res_x)

          })

          names(res) <- names(clause_reactive())
          return(res)

        } else {
          return(list())
        }

      })

      # * clause_reactive_index() ----
      clause_reactive_index <- shiny::reactive({

        req(clause_reactive_val())

        crNonNa <- !is.na(clause_reactive_val())
        cVal <- clause_reactive_val()
        clause_reactiveNonNa <- cVal[crNonNa]

        if (isTRUE(length(clause_reactiveNonNa) > 0)) {

          res <- purrr::reduce(clause_reactiveNonNa, `&`)
          return(res)

        } else {
          return(list())
        }

      })

      # * table_data_filtered() ----
      table_data_filtered <- shiny::reactive({

        req(clause_reactive_index())
        req(rvalues$table_data)

        if (isTRUE(length(clause_reactive_index()) == 0)) {
          rvalues$table_data
        } else {
          rvalues$table_data[clause_reactive_index(), , drop = F]
        }

      }) #%>% shiny::debounce(millis = 250)

      # * table_show_displayed() ----
      table_show_displayed <- shiny::reactive({

        req(clause_reactive_index())
        req(table_show())

        if (isTRUE(length(clause_reactive_index()) == 0)) {
          table_show()
        } else {
          table_show()[clause_reactive_index(), , drop = F]
        }

      }) #%>% shiny::debounce(millis = 250)

      # * cells_selected() ----
      cells_selected <- shiny::reactive({

        res <- tryCatch({

          if (isTRUE(is.null(input$table_cells_selected))) {
            data.frame(row = vector('integer'), col = vector('integer'))
          } else {
            tmp <- as.data.frame(input$table_cells_selected)
            colnames(tmp) <- c('row', 'col')
            tmp
          }

        }, error = function(e) {
          message(sprintf("Error in %s: %s", deparse(e[["call"]]), e[["message"]]))
          data.frame(row = vector('integer'), col = vector('integer'))
        })

        res

      })

      # _______________________________ ----
      # OBSERVE EVENTS ----

      # * data() ----
      observe({

        shiny::req(data())

        if (!isTRUE(is.data.frame(data()))) {
          shinyWidgets::show_toast(
            title = "Invalid Data Table!!!",
            type = "error",
            position = "bottom"
          )
        }
        else {
          rvalues$table_data <- data()
        }

      })

      # * col_hide() ----
      observe({

        shiny::req(col_hide())

        if (!isTRUE(is.character(col_hide()))) {
          shinyWidgets::show_toast(
            title = "Invalid Column Exclusions!!!",
            type = "error",
            position = "bottom"
          )
        }
        else {

          if (isTRUE(length(col_hide()) == 0)) {
            res <- c('_DUMMY_COLUMN_NAME_7g6uvkyid4590nxa75_DONT_USE_ME_EVER_')
          } else {
            res <- col_hide()
          }

          rvalues$col_hidden <- res

        }

      })

      # _______________________________ ----
      # OBSERVER EVENTS ----

      # * input$add_clause_btn ----
      observeEvent(input$add_clause_btn, {

        btn <- rrules$clause_num + 1
        ui_id <- paste0('rrules_clause_', btn)

        insertUI(
          selector = paste0('#', ns('rule_builder_ui_placeholder')),
          ui = clauseDynamic_ui(id = ns(ui_id))
        )

        rrules$clause_num <- btn
        rrules$clause_reactive_list[[ui_id]] <- clauseDynamic_server(
          id = ui_id,
          data = table_show
        )

      })

      # * input$drop_clause_btn ----
      observeEvent(input$drop_clause_btn, {

        if (length(rrules$clause_reactive_list) > 0) {

          if (!is.null(rrules$clause_num)) {
            removeUI(selector = paste0('#', ns(paste0('rrules_clause_', rrules$clause_num))))
            rrules$clause_reactive_list[[paste0('rrules_clause_', rrules$clause_num)]] <- NULL
          }

          rrules$clause_num <- max(rrules$clause_num - 1, 0, na.rm = TRUE)

        }

      })

      # * input$table_cell_clicked ----
      observeEvent(input$table_cell_clicked, {

        shiny::req(table_show_displayed())

        rvalues$cell_clicked <- tryCatch({

          res <- input$table_cell_clicked

          if (!isTRUE(length(res) == 0)) {

            if (isTRUE(is.null(res[['value']]))) {res[['value']] <- NA}
            as.data.frame(res)

          } else {
            NULL
          }

        }, error = function(e) {
          browser()
          NULL
        })

      }, ignoreInit = TRUE)

      # * input$table_cell_edit ----
      observeEvent(input$table_cell_edit, {

        shiny::req(input$table_cell_edit)
        shiny::req(rvalues$cell_clicked)

        # Save Cell Edit Data
        cell_edit <- input$table_cell_edit

        # Validate that Edited Cell is Last Clicked Cell
        equal_row <- isTRUE(cell_edit$row == rvalues$cell_clicked$row)
        equal_col <- isTRUE(cell_edit$col == rvalues$cell_clicked$col)

        if (!isTRUE(all(equal_row, equal_col))) {
          stop("`input$table_cell_edit` and `rvalues$cell_clicked` are not aligned in call to `shinyTable_server`")
        }

        # Save Cell Edit Column Name
        edit_column <- colnames(table_show_displayed())[cell_edit$col]

        # Save Cell Edit Row Name
        edit_row <- row.names(table_show_displayed()[cell_edit$row, , drop = F])

        # Conditionally Replace Original Cell Value
        if (!isTRUE(edit_column %in% rcnst$values)) {cell_edit[['value']] <- rvalues$cell_clicked[['value']]}

        # Edit/Update Underlying Table Data
        rvalues$table_data <<- DT::editData(table_show_displayed(), cell_edit, 'table')

      }, ignoreInit = TRUE)

      # ____________ ----
      # OUTPUTS ----

      # * output$table ----
      output$table <- DT::renderDT(expr = {

        DT::datatable(
          data = shiny::isolate(table_show()),
          rownames = TRUE,
          editable = list(target = 'cell'),
          selection = list(mode = 'multiple', target = "cell"), # table_row_selection(),
          options = list(
            pageLength = table_page_length(),
            scrollX = TRUE,
            scrollY = TRUE,
            server = TRUE,
            dom = '<t><"shiny_twm_footer"<"shiny_twm_footer_elem"i><"shiny_twm_footer_elem"fr>>',
             columnDefs = list(
               list(targets = c(0), visible = FALSE)
             ),
            initComplete = DT::JS(c(
              "function(settings, json){",
              "  var table = settings.oInstance.api();",
              "  var pageinfo = table.page.info();",
              "}"
            ))
          ),
          callback = DT::JS(c(
            paste0("$('#", ns('table_page_prev'), "').on('click', function(){", collapse = ''),
            "  table.page('previous').draw('page');",
            "});",

            paste0("$('#", ns('table_page_next'), "').on('click', function(){", collapse = ''),
            "  table.page('next').draw('page');",
            "});"
          ))
        )

      })

      # * table proxy ----
      proxy__table <- DT::dataTableProxy('table')

      # ** proxy update - 'table_show_displayed()' ----
      shiny::observeEvent(table_show_displayed(), {
        DT::replaceData(proxy__table, table_show_displayed(), resetPaging = FALSE, rownames = TRUE)
      }, ignoreNULL = TRUE, ignoreInit = TRUE)

      # * output$download_ui ----
      output$download_ui <- shiny::renderUI({

        cond <- isTRUE(is.data.frame(table_data_filtered()))

        if (isTRUE(cond)) {
          shiny::downloadButton(
            outputId = ns('download_btn'),
            label = 'Download Data'
          )
        }
        else {
          shiny::tagList(shiny::HTML("<b>NO DATA</b>"))
        }

      })

      # * output$download_btn ----
      output$download_btn <- shiny::downloadHandler(
        filename = function() {
          paste0('table_export_', gsub(' ', '_', Sys.time()), '.csv')
        },
        content = function(file) {
          write.csv(table_data_filtered(), file, row.names = FALSE, na = '')
        }
      )

      # ____________ ----
      # MODULE RETURN VALUE ----
      result <- shiny::reactive({

        res <- list(
          data = table_show_displayed(),
          cells_selected = cells_selected(),
          rows_selected = sort(unique(cells_selected()$row)),
          cols_selected = sort(unique(cells_selected()$col))
        )

        return(res)

      })

      return(result)

      # _______________________ ----
      # END OF MODULE SERVER ----
    }
  )

}

#' Display R DataFrame in R Shiny Table
#'
#' @importFrom utils read.csv
#'
#' @param data data.frame
#' @param ... ellipsis
#'
#' @export
#'
#' @examples
#' \dontrun{
#' shinyTable(raw_data)
#' }
shinyTable <- function(data, ...) {

  # Validate Input
  if (missing(data)) {
    #data <- read.csv(system.file("sample_data/RDS_Sample.csv", package = 'shinyTWM'))
    data <- readRDS(system.file("sample_data/default_role_rank_group.rds", package = 'shinyTWM'))
  }

  # Validate Input Expectations
  if (!isTRUE(is.data.frame(data))) {
    stop("`data` must be 'data.frame' in call to `shinyTable`")
  }

  # * `ui`
  ui <- shiny::tagList(
    shiny::column(
      width = 12,
      shinyTable_ui('shinytable1')
    )
  )

  # * `server`
  server <- function(input, output, session) {

    raw_data <- shiny::reactive({data})
    raw_colnames <- shiny::reactive({colnames(data)})
    #hide_colnames <- shiny::reactive({vector(mode = 'character')})
    hide_colnames <- shiny::reactive({c('Party', 'Channel')})

    selected_rows <- shinyTable_server(
      id = 'shinytable1',
      data = raw_data,
      col_hide = hide_colnames,
      cnst = c('item_roles_rank_range')
    )

    shiny::observe({
      req(selected_rows())
      print(selected_rows())
    })

  }

  shiny::shinyApp(ui, server, ...)

}


#' S3 Generic - Validate DataFrame Fields and Types
#'
#' @param data S3 Object
#'
#' @return S3 Object
#' @export
#'
#' @examples
#' \dontrun{
#' output <- validate_shinytable_data(data)
#' }
validate_shinytable_data <- function(data) {UseMethod("validate_shinytable_data", data)}

#' S3 Method - Validate DataFrame Fields and Types for 'item_roles_rank_range'
#'
#' @importFrom rlang .data
#'
#' @param data data.frame
#'
#' @return list
#' @export
#' @examples
#' \dontrun{
#' results <- item_roles_rank_ranges(
#'    data = rvalues$table_data,
#'    cell_edit = input$table_cell_edit
#' )
#' }
validate_shinytable_data.default <- function(data) {
  stop("`class(data)` was not able to find suitable S3 Method for `validate_shinytable_data`")
}

#' S3 Method - Validate DataFrame Fields and Types for 'item_roles_rank_range'
#'
#' @importFrom rlang .data
#'
#' @param data data.frame
#'
#' @return list
#' @export
#' @examples
#' \dontrun{
#' results <- item_roles_rank_ranges(
#'    data = rvalues$table_data,
#'    cell_edit = input$table_cell_edit
#' )
#' }
validate_shinytable_data.item_roles_rank_ranges <- function(data) {

  # Validate Input
  if (missing(data)) {stop("`data` is missing in call to `validate_shinytable_data.item_roles_rank_ranges`")}

  # Validate Input Expectations

  # * data
  if (!isTRUE(is.data.frame(data))) {
    stop("`data` must be data.frame in call to ")
  }

  expected_colnames <- c('min_rank', 'rank', 'max_rank', 'rank_range', 'item_role')
  if (!isTRUE(identical(colnames(data), expected_colnames))) {
    stop("`colnames(data)` does not match expected values in call to `validate_shinytable_data.item_roles_rank_ranges`")
  }

  # ** numeric columns ----
  data_numeric <- data %>% dplyr::select(.data$min_rank, .data$rank, .data$max_rank, .data$item_role)
  if (!isTRUE(all(purrr::map_lgl(data_numeric, function(t){is.numeric(t)})))) {
    stop("`data` does not have expected set of numeric columns in call to `validate_shinytable_data.item_roles_rank_ranges`")
  }

  # ** character columns ----
  data_character <- data %>% dplyr::select(.data$rank_range)
  if (!isTRUE(all(purrr::map_lgl(data_character, function(t){is.character(t)})))) {
    stop("`data` does not have expected set of character columns in call to `validate_shinytable_data.item_roles_rank_ranges`")
  }

  # Return Data
  invisible(data)

}

#' Compares Latest 'Cell Edit' against Input DataFrame and Hard-Coded Constraints
#'
#' @importFrom rlang .data
#'
#' @param data data.frame
#' @param row_name character
#' @param col_name character
#' @param orig_val R Object
#'
#' @return list
#'
item_roles_rank_ranges <- function(data, row_name, col_name, orig_val) {

  # Validate Input
  if (missing(data)) {stop("`data` is missing in call to `item_roles_rank_ranges`")}

  # Validate Input Expectations

  # * data
  if (!isTRUE(is.data.frame(validate_shinytable_data.item_roles_rank_ranges(data)))) {
    stop("`data` must be VALID data.frame in call to `item_role_rank_ranges`")
  }

  # MAIN LOGIC ----

  if (!isTRUE(col_name == 'rank')) {



  } else {

    data[row_name, col_name, drop = F] <<- orig_val
    status <- 'RESET'

  }

  # Compile Final Results
  results <- list(data = data, status = status)

  # Return Final Results
  invisible(results)

}

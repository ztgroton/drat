
#' Shiny Module UI - `clauseDynamic`
#'
#' @import shiny
#' @import shinyWidgets
#'
#' @param id character - Unique identifier for module instance
#' @param data reactive - Reactive Expression that returns data.frame
#'
#' @return R Shiny Tags
#' @export
#'
#' @examples
#' \dontrun{
#' clauseDynamic_ui('clause1', datacolumns)
#' }
clauseDynamic_ui <- function(id, data) {

  # Session Namespace
  ns <- NS(id)

  # * dataColumns() ----
  dataColumns <- shiny::reactive({

    shiny::req(data())

    if (!isTRUE(is.data.frame(data()))) {
      shinyWidgets::show_toast(
        title = "`clauseDynamic_ui` - Invalid Data Table!!!",
        type = "error",
        position = "bottom"
      )
    }
    else {
      return(colnames(data()))
    }

  })

  #
  init_column <- sort(unique(as.character(dataColumns())))[1]

  div(
    id = id,
    tagList(
      tags$head(
        tags$style(
          HTML(
          "
          .shiny-split-layout > div {overflow: visible; margin: 0; width: 100%;}
          div.form-group.shiny-input-container { margin: 0 !important; width: 100%;}
          "
          )
        )
      ),
      splitLayout(
        style = 'width:99%;',
        cellWidths = c('25%', '25%', '50%'),
        pickerInput(
          ns("rule_column_control"),
          label = NULL,
          multiple = FALSE,
          selected = init_column,
          choices = sort(unique(as.character(dataColumns()))),
          options = pickerOptions(liveSearch = TRUE)
        ),
        uiOutput(ns("ui_rule_operator_control")),
        uiOutput(ns("ui_rule_condition_control"))
      )
    )
  )

}

#' Shiny Module Server - `clauseDynamic`
#'
#' @import shiny
#'
#' @param id character - Unique identifier for module instance
#' @param data data.frame
#'
#' @return R Shiny Tags
#' @export
#'
#' @examples
#' \dontrun{
#' clauseDynamic_ui('clause1', datacolumns)
#' }
clauseDynamic_server <- function(id, data) {

  moduleServer(id, function(input, output, session){

    # Session Namespace
    ns <- session$ns

    # _____________________________________ ----
    # MODULE INPUT REACTIVE EXPRESSIONS ----

    # * tableData() ----
    tableData <- shiny::reactive({

      shiny::req(data())

      if (!isTRUE(is.data.frame(data()))) {
        shinyWidgets::show_toast(
          title = "`clauseDynamic_server` - Invalid Data Table!!!",
          type = "error",
          position = "bottom"
        )
      } else {
        return(data())
      }

    })

    # * tableColumns() ----
    tableColumns <- shiny::reactive({

      shiny::req(tableData())

      # Return `colnames(tableData())`
      return(colnames(tableData()))

    })

    # * tableColumnTypes() ----
    tableColumnTypes <- shiny::reactive({

      shiny::req(tableData())
      shiny::req(tableColumns())

      # Get Data Types for each Column
      types <- purrr::map_chr(tableData(), function(t){class(t)[1]})
      names(types) <- colnames(tableData())

      # Return Data Types
      return(types)

    })

    # ____________ ----
    # OUTPUTS ----

    # * output$ui_rule_operator_control ----
    output$ui_rule_operator_control <- renderUI({

      rule_column_type <- tableColumnTypes()[[input$rule_column_control]]

      print(input$rule_column_control)
      print(rule_column_type)

      if ( length(intersect(rule_column_type, c("character", "factor"))) > 0 ) {
        pickerInput(
          ns("rule_operator_control"),
          label = NULL,
          multiple = FALSE,
          selected = '==',
          choices = c('==', '!=')
        )
      } else if (length(intersect(rule_column_type, c("logical"))) > 0) {
        pickerInput(
          ns("rule_operator_control"),
          label = NULL,
          multiple = FALSE,
          selected = '==',
          choices = c('==', '!=')
        )
      } else if ( length(intersect(rule_column_type, c("integer", "numeric"))) > 0 ) {
        pickerInput(
          ns("rule_operator_control"),
          label = NULL,
          multiple = FALSE,
          selected = '==',
          choices = c('==', '!=', '<', '>', '<=', '>=', 'BETWEEN')
        )
      } else if ( length(intersect(rule_column_type, c("POSIXct", "Date"))) > 0 ) {
        pickerInput(
          ns("rule_operator_control"),
          label = NULL,
          multiple = FALSE,
          selected = '==',
          choices = c('==', '!=', '<', '>', '<=', '>=', 'BETWEEN', 'IN DATE RANGE')
        )
      } else {

        HTML(rule_column_type)

      }

    })

    # * output$ui_rule_condition_control ----
    output$ui_rule_condition_control <- renderUI({

      rule_column_type <- tableColumnTypes()[[input$rule_column_control]]

      if ( length(intersect(rule_column_type, c("character", "factor"))) > 0 ) {

        shinyvs::virtualSelectInput(
          ns("rule_condition_control"),
          label = NULL,
          choices = sort(unique(tableData()[[input$rule_column_control]])),
          selected = NULL,
          multiple = TRUE,
          search = TRUE
        )

      } else if ( length(intersect(rule_column_type, c("logical"))) > 0 ) {
        pickerInput(
          ns("rule_condition_control"),
          label = NULL,
          selected = TRUE,
          choices = c(TRUE, FALSE)
        )
      } else if ( length(intersect(rule_column_type, c("integer", "numeric"))) > 0 ) {

        if (input$rule_operator_control == "BETWEEN") {

          numericRangeInput(
            ns("rule_condition_control"),
            label = NULL,
            value = c(0,10)
          )

        } else {

          numericInput(
            ns("rule_condition_control"),
            label = NULL,
            value = 0
          )

        }

      } else if ( length(intersect(rule_column_type, c("POSIXct", "Date"))) > 0 ) {

        if (input$rule_operator_control == "BETWEEN") {

          dateRangeInput(
            ns("rule_condition_control"),
            label = NULL,
            start = "2023-01-01",
            end = "2023-12-31"
          )

        } else if (input$rule_operator_control == "IN DATE RANGE") {

          splitLayout(
            style = 'width:99%',
            pickerInput(
              ns("rule_condition_control_1"),
              label = NULL,
              selected = 'During',
              choices = c('Before', 'During', 'After')
            ),
            pickerInput(
              ns("rule_condition_control_2"),
              label = NULL,
              selected = 'Last',
              choices = c('Last', 'Next')
            ),
            numericInput(
              ns("rule_condition_control_3"),
              label = NULL,
              value = 1,
              min = 1,
              step = 1
            ),
            pickerInput(
              ns("rule_condition_control_4"),
              label = NULL,
              selected = 'Month(s)',
              choices = c('Day(s)', 'Week(s)', 'Month(s)', 'Year(s)')
            )
          )

        } else {

          dateInput(
            ns("rule_condition_control"),
            label = NULL,
            value = "2019-01-01"
          )

        }

      } else {

        HTML(rule_column_type)

      }

    })

    # Module Reactive Result
    result_list <- reactive({

      list(
        column = input$rule_column_control,
        operator = input$rule_operator_control,
        condition = if (input$rule_operator_control == 'IN DATE RANGE') {
          paste(
            input$rule_condition_control_1,
            input$rule_condition_control_2,
            input$rule_condition_control_3,
            input$rule_condition_control_4,
            sep = " "
          )
        } else {
          input$rule_condition_control
        }
      )

    })

    return(result_list)

  })

}

#' Display R DataFrame Dynamic Clause
#'
#' @importFrom utils read.csv
#'
#' @param data data.frame
#' @param ... ellipsis
#'
#' @export
#'
#' @examples
#' \dontrun{
#' clauseDynamic(raw_data)
#' }
clauseDynamic <- function(data, ...) {

  # Validate Input
  if (missing(data)) {data <- read.csv(system.file("sample_data/RDS_Sample.csv", package = 'shinyTWM'))}

  # Validate Input Expectations
  if (!isTRUE(is.data.frame(data))) {
    stop("`data` must be 'data.frame' in call to `clauseDynamic`")
  }

  # * `ui`
  ui <- shiny::tagList(
    shiny::column(
      width = 12,
      clauseDynamic_ui('clauseDynamic1')
    )
  )

  # * `server`
  server <- function(input, output, session) {

    raw_data <- shiny::reactive({data})
    raw_colnames <- shiny::reactive({colnames(data)})

    selected_rows <- clauseDynamic_server(
      id = 'clauseDynamic1',
      data = raw_data
    )

    shiny::observe({print(selected_rows())})

  }

  shiny::shinyApp(ui, server, ...)

}

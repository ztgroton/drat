
#' Convert JSONB Column into R DataFrame
#'
#' @param jsonb character - stores JSON data represented as text
#'
#' @return data.frame
#' @export
#'
#' @examples
#' \dontrun{
#' output <- jsonb_to_frame(jsonb)
#' }
jsonb_to_frame <- function(jsonb) {

  # Validate Inputs ----
  if (missing(jsonb)) {stop("`jsonb` is missing in call to `jsonb_to_frame`")}

  # Validate Input Expectations ----

  # * `jsonb` ----
  if (!isTRUE(is.character(jsonb)) || !isTRUE(length(jsonb) > 0)) {
    stop("`jsonb` must be a non-empty character vector in call to `jsonb_to_frame`")
  }

  # MAIN LOGIC ----

  # Convert `jsonb` to list
  jsonb_list <- purrr::map(jsonb, jsonlite::fromJSON)

  # Transpose Top-Level of List / Bring Column Names to Top
  jsonb_list <- purrr::transpose(jsonb_list)

  # Convert NULL values to NA
  jsonb_list <- purrr::map(jsonb_list, function(x) {
    purrr::map(x, function(t) {
      if(isTRUE(any(is.null(t)))) {
        return(NA)
      } else {
        return(t)
      }
    })
  })

  # Determine Appropriate Data Type for each Column Name
  jsonb_data_types <- purrr::map_chr(jsonb_list, function(x) {

    data.frame(
      elem_class = purrr::map_chr(x, function(t){class(t)[[1]]}),
      stringsAsFactors = FALSE
    ) %>%
      dplyr::group_by(.data$elem_class) %>%
      dplyr::tally() %>%
      dplyr::ungroup() %>%
      dplyr::filter(.data$elem_class != 'NULL') %>%
      dplyr::arrange(dplyr::desc(.data$n)) %>%
      dplyr::slice_head() %>%
      dplyr::pull(.data$elem_class)

  })
  names(jsonb_data_types) <- names(jsonb_list)

  # Convert `jsonb_list` list elements into vectors of appropriate data type
  jsonb_list <- purrr::map(names(jsonb_list), function(x) {

    x_data_type <- jsonb_data_types[[x]]
    x_jsonb <- jsonb_list[[x]]
    x_jsonb <- purrr::reduce(x_jsonb, `c`)

    if (isTRUE(x_data_type %in% c('integer', 'numeric'))) {
      res <- as.numeric(x_jsonb)
    } else {
      res <- as.character(x_jsonb)
    }

    return(res)

  })
  names(jsonb_list) <- names(jsonb_data_types)

  # Return `jsonb_list`
  return(as.data.frame(jsonb_list))

}

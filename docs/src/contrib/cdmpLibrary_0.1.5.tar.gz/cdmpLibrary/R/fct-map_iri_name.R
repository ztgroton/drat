
#' Helper Function for Mapping IRI Item Names
#'
#' @param data data.frame - contains the raw data to be mapped
#' @param name_col character - name of column containing Item Names
#'
#' @return TRUE
#' @export
#'
#' @examples
#' \dontrun{
#' map_iri_name(raw_iri_data, 'PRODUCT')
#' }
map_iri_name <- function(data, name_col) {

  # Validate Inputs
  if (missing(data)) {stop("`data` is missing in call to `map_iri_name`")}
  if (missing(name_col)) {stop("`name_col` is missing in call to `map_iri_name`")}

  # Initialize `data` variable name
  data_name <- deparse(substitute(data))

  # Validate Input Expectations

  # * `data`
  if (!isTRUE(is.data.frame(data))) {
    stop("`data` must be type 'data.frame' in call to `map_iri_name`")
  }

  # * `name_col`
  is_char <- isTRUE(is.character(name_col))
  is_len1 <- isTRUE(length(name_col) == 1)
  is_colname <- isTRUE(name_col %in% colnames(data))
  if (!isTRUE(is_char) || !isTRUE(is_len1) || !isTRUE(is_colname)) {
    stop("`name_col` must be single column name of `data` in call to `map_iri_name`")
  }

  # * `data_name`
  is_char <- isTRUE(is.character(data_name))
  is_len1 <- isTRUE(length(data_name) == 1)
  is_non_na <- isTRUE(!is.na(data_name))
  if (!isTRUE(is_char) || !isTRUE(is_len1) || !isTRUE(is_non_na)) {
    stop("`data_name` must be non-na length 1 character in call to `map_iri_name`")
  }

  # Initialize Empty S3 Object of class 'cdmp_shop_data'
  iri_shop <- cdmp_shop_data()

  # Load `data` into `iri_shop`
  load_file(obj = iri_shop, name = data_name, data = data)

  # Set 'Shop Party' as 'nlsn'
  set_shop_party(obj = iri_shop, shop_party = 'iri')

  # Set Item Name Key Template
  name_keys <- list(item_name = c(item_name = name_col))
  set_key(obj = iri_shop, key = name_keys)

  # Generate Keys
  generate_shop_key(obj = iri_shop)

  # Map Keys
  map_shop_key(obj = iri_shop)

  # Upload Mapped Keys
  upsert_shop_key(obj = iri_shop)

  # Return Success
  invisible(TRUE)

}

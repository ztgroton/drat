
#' Fetch Item-UPC Lookup Table from PostgreSQL Database
#'
#' @param conn DBIConnection
#'
#' @return data.frame
#' @export
#'
#' @examples
#' \dontrun{
#' output <- twm_item_upc(conn = conn_edw)
#' }
twm_item_upc <- function(conn) {

  # Validate Inputs
  if (missing(conn)) {conn <- dbTools::psql_db_connect('comp_map_lib_prod')}

  # Fetch SQL Query
  qry <- "select * from map_library.twm_item_upc"

  # Execute SQL Query / Fetch Results
  results <- DBI::dbGetQuery(conn, qry)

  # Close Connection to 'PSQL - conn'
  DBI::dbDisconnect(conn)
  rm(conn)

  # Return Results
  return(results)

}

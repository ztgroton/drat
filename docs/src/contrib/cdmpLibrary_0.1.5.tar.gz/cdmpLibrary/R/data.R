
#' 'Competitor Mapping Library - NEW' BigQuery Upload Template
#'
#' Report ...
#'
#' \describe{
#'   \item{item_name}{character}
#'   \item{type}{character}
#'   \item{container_type}{character}
#'   \item{vintage}{character}
#'   \item{brand}{character}
#'   \item{party_product_id}{character}
#'   \item{department}{character}
#'   \item{upc}{numeric}
#'   \item{twm_item_code}{numeric}
#'   \item{twm_position_key}{numeric}
#'   \item{shop_party}{character}
#'   \item{competitor}{character}
#'   \item{is_private_label}{logical}
#'   \item{last_modify_date}{POSIXct}
#'   \item{modified_by}{character}
#'   \item{comp_retail}{numeric}
#'   ...
#' }
#' @docType data
#' @keywords datasets
#' @name competitor_mapping_library_NEW
#' @usage data(competitor_mapping_library_NEW)
#' @format A data frame with 0 rows and 16 variables
NULL

#' Valid Keys
#'
#' Report ...
#'
#' \describe{
#'   \item{name}{character}
#'   ...
#' }
#' @docType data
#' @keywords datasets
#' @name valid_keys
#' @usage data(valid_keys)
#' @format A data frame with 8 rows and 1 variable
NULL

#' Valid Key Fields
#'
#' Report ...
#'
#' \describe{
#'   \item{key}{character}
#'   \item{field}{character}
#'   \item{type}{character}
#'   ...
#' }
#' @docType data
#' @keywords datasets
#' @name valid_key_fields
#' @usage data(valid_key_fields)
#' @format A data frame with 15 rows and 3 variables
NULL

#' Valid Mapping Tables
#'
#' Report ...
#'
#' @docType data
#' @keywords datasets
#' @name valid_mapping_tables
#' @usage data(valid_mapping_tables)
#' @format A list of data.frames
NULL

#' Valid Mapping Schemas
#'
#' Report ...
#'
#' @docType data
#' @keywords datasets
#' @name valid_mapping_schemas
#' @usage data(valid_mapping_schemas)
#' @format A named list of character vectors
NULL

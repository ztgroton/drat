
refresh_twm_map <- function(maps, use_dev = FALSE) {

  # Validate Inputs ----
  if (missing(maps)) {stop("`maps` is missing in call to `refresh_twm_map`")}
  if (missing(use_dev)) {use_dev <- FALSE}

  # Validate Input Expectations ----

  # * `maps` ----
  if (!isTRUE(is.data.frame(maps))) {
    stop("`maps` must be data.frame in call to `refresh_twm_map`")
  } else if (!isTRUE(identical(sort(colnames(maps)), sort(c('twm_item_code', 'twm_position_key'))))) {
    stop("`colnames(maps)` must be `c('twm_item_code', 'twm_position_key')` in call to `refresh_twm_map`")
  }

  any_item_code_na <- isTRUE(any(purrr::map_lgl(maps$twm_item_code, function(t) {isTRUE(is.na(t)) || isTRUE(is.null(t))})))
  any_position_key_na <- isTRUE(any(purrr::map_lgl(maps$twm_position_key, function(t) {isTRUE(is.na(t)) || isTRUE(is.null(t))})))

  if (isTRUE(any_item_code_na)) {
    stop("`maps$twm_item_code` cannot contain NA/NULL values in call to `refresh_twm_map`")
  } else if (isTRUE(any_position_key_na)) {
    stop("`maps$twm_position_key` cannot contain NA/NULL values in call to `refresh_twm_map`")
  }

  # * `use_dev` ----
  if (!isTRUE(identical(use_dev, TRUE)) && !isTRUE(identical(use_dev, FALSE))) {
    stop("`use_dev` must be TRUE/FALSE in call to `refresh_twm_map`")
  }

  # MAIN LOGIC ----

  # Setup DB Connection
  if (isTRUE(use_dev)) {
    conn <- psql_db_connect('comp_map_lib_dev')
  } else {
    conn <- psql_db_connect('comp_map_lib_prod')
  }

  # Upload `data` to Public Table ----
  tmp_tbl <- upload_tmp_tbl(data = maps)

  # Generate Dynamic SQL Select Statement
  qry_twm_map <- DBI::dbGetQuery(conn, glue::glue_sql(
    "select public.gen_twm_map_template({tmp_tbl})",
    .con = conn
  )) %>%
    dplyr::pull(.data$gen_twm_map_template)

  browser()

  # Execute Dynamic SQL / Fetch Results
  tryCatch({
    DBI::dbBegin(conn)
    DBI::dbExecute(conn, qry_twm_map)
    DBI::dbCommit(conn)
  }, error = function(e) {
    DBI::dbRollback(conn)
    message(sprintf("Error in %s: %s", deparse(e[["call"]]), e[["message"]]))
  })

  # Close DB Connection
  DBI::dbDisconnect(conn)
  rm(conn)

  # Remove Public Table Data
  drop_tmp_tbl(tmp_tbl)

  # Return Success
  invisible(TRUE)

}

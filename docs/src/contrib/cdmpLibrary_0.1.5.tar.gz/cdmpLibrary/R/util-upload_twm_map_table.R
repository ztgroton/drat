
#' Upload TWM Items to Competitive Mapping Library
#'
#' @importFrom rlang .data
#'
#' @param conn DBIConnection
#' @param df data.frame
#'
#' @return TRUE
#' @export
#'
#' @examples
#' \dontrun{
#' upload_twm_map_table(psql_conn, twm_map_data)
#' }
upload_twm_map_table <- function(conn, df) {

  # Validate Inputs

  # * `conn`
  if (missing(conn)) {stop("`conn` is missing in call to `upload_twm_map_table`", call. = FALSE)}

  if (!isTRUE(inherits(conn, 'DBIConnection'))) {
    stop("`conn` must inherit from 'DBIConnection' in call to `upload_twm_map_table`", call. = FALSE)
  }

  # * `df`
  if (missing(df)) {stop("`df` is missing in call to `upload_twm_map_table`", call. = FALSE)}

  if (!isTRUE(is.data.frame(df))) {
    stop("`df` must be data.frame in call to `upload_twm_map_table`", call. = FALSE)
  }

  expected_cols <- c('map_hash', 'twm_item_code', 'twm_position_key')
  if (!isTRUE(identical(colnames(df), expected_cols))) {
    stop("`colnames(df)` must match expected values in call to `upload_twm_map_table`", call. = FALSE)
  }

  #
  # Check if 'map_library' schema already exists
  exist_qry <- "SELECT schema_name FROM information_schema.schemata WHERE schema_name = 'map_library'"
  map_library_exists <- isTRUE(nrow(DBI::dbGetQuery(conn, exist_qry)) == 1)

  if (isTRUE(map_library_exists)) {

    # Check if 'twm_map' table already exists
    table_qry <- "SELECT EXISTS (SELECT FROM pg_tables WHERE schemaname = 'map_library' AND tablename  = 'twm_map')"
    table_ind <- isTRUE(as.logical(DBI::dbGetQuery(conn, table_qry)))

    # Check if 'twm_map' table is already populated
    if (isTRUE(table_ind)) {
      table_cnt <- DBI::dbGetQuery(conn, "select count(*) as table_cnt from map_library.twm_map") %>%
        dplyr::pull(.data$table_cnt)
      table_ind <- table_ind && isTRUE(table_cnt == 0)
    } else {
      message("table 'twm_map' DOES NOT EXIST")
    }

    if (isTRUE(table_ind)) {

      table_id <- DBI::Id(schema = "map_library", table = "twm_map")

      dbx::dbxInsert(
        conn = conn,
        table = table_id,
        records = as.data.frame(df),
        batch_size = 1000000
      )

    } else {
      message(paste0("table 'twm_map' is ALREADY POPULATED - ", table_cnt))
    }

  } else {
    message("schema `map_library` DOES NOT EXIST")
  }

  # Return Success
  invisible(TRUE)

}

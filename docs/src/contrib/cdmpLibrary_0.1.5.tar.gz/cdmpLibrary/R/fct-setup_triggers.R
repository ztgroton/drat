
#' Setup Competitive Mapping Library Triggers
#'
#' @param conn DBIConnection
#'
#' @return TRUE
#' @export
#'
#' @examples
#' \dontrun{
#' setup_triggers(psql_conn)
#' }
setup_triggers <- function(conn) {

  # Validate Inputs
  if (missing(conn)) {stop("`conn` is missing in call to `setup_triggers`")}

  # Validate Input Expectations

  # * `conn`
  if (!isTRUE(inherits(conn, 'DBIConnection'))) {
    stop("`conn` must inherit from 'DBIConnection' in call to `setup_triggers`")
  }

  # ____________________________________ ----
  # CREATE `MAP LIB` TRIGGERS ----

  # * NLSN ----
  init_map_lib_trigger(conn, 'nlsn', 'upc_text')
  init_map_lib_trigger(conn, 'nlsn', 'upc_num')
  init_map_lib_trigger(conn, 'nlsn', 'item_name')

  # * IRI ----
  init_map_lib_trigger(conn, 'iri', 'upc_text')
  init_map_lib_trigger(conn, 'iri', 'upc_num')
  init_map_lib_trigger(conn, 'iri', 'item_name')

  # * BST ----
  init_map_lib_trigger(conn, 'bst', 'upc_text')
  init_map_lib_trigger(conn, 'bst', 'upc_num')
  init_map_lib_trigger(conn, 'bst', 'party_product_id')
  init_map_lib_trigger(conn, 'bst', 'item_name')

  # * TWM ----
  init_map_lib_trigger(conn, 'twm', 'upc_text')
  init_map_lib_trigger(conn, 'twm', 'upc_num')
  init_map_lib_trigger(conn, 'twm', 'item_name')

  init_map_lib_trigger(conn, 'twm', 'item_name_type_container_vintage')
  init_map_lib_trigger(conn, 'twm', 'item_name_type_vintage')
  init_map_lib_trigger(conn, 'twm', 'item_name_vintage')
  init_map_lib_trigger(conn, 'twm', 'item_name_type')

  # * TWS ----
  init_map_lib_trigger(conn, 'tws', 'upc_text')
  init_map_lib_trigger(conn, 'tws', 'upc_num')
  init_map_lib_trigger(conn, 'tws', 'item_name')

  init_map_lib_trigger(conn, 'tws', 'item_name_type_container_vintage')
  init_map_lib_trigger(conn, 'tws', 'item_name_type_vintage')
  init_map_lib_trigger(conn, 'tws', 'item_name_vintage')
  init_map_lib_trigger(conn, 'tws', 'item_name_type')

  # ____________________________________ ----
  # INITIALIZE `MAP LIB UPDATE` TRIGGERS ----
  cat("Initalizing `Map Lib Update` Triggers... ")
  tictoc::tic()
  init_map_lib_update_trigger(conn)
  tictoc::toc()

  # Return Success
  invisible(TRUE)

}

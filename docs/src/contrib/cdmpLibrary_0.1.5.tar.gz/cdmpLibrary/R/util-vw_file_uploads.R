
#' Query File Upload Log for Competitive Mapping Library
#'
#' @param use_dev logical
#'
#' @return data.frame
#' @export
#'
#' @examples
#' \dontrun{
#' output <- vw_file_uploads()
#' }
vw_file_uploads <- function(use_dev = FALSE) {

  # Validate Inputs ----
  if (missing(use_dev)) {use_dev <- FALSE}

  # Validate Input Expectations ----

  # * `dev` ----
  if (!isTRUE(identical(use_dev, TRUE)) && !isTRUE(identical(use_dev, FALSE))) {
    stop("`dev` must be TRUE/FALSE in call to `vw_file_uploads`")
  }

  # MAIN LOGIC ----

  # Prepare SQL Query
  qry <- "select * from upload_files.file_log"

  # Setup DB Connection
  if (isTRUE(identical(use_dev, TRUE))) {
    conn <- psql_db_connect('comp_map_lib_dev')
  } else {
    conn <- psql_db_connect('comp_map_lib_prod')
  }

  # Execute SQL / Fetch Results
  tryCatch({
    res <- DBI::dbGetQuery(conn, qry)
  }, error = function(e) {
    stop(sprintf("Error in %s: %s", deparse(e[["call"]]), e[["message"]]))
  })

  # Close DB Connection
  DBI::dbDisconnect(conn)
  rm(conn)

  # Return Results
  return(res)

}

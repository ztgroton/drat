#' @include s3_gen-cdmp_shop_key.R
#' @include s3_method-cdmp_shop_key.R
NULL

#' Construct an Empty S3 Object of class 'cdmp_shop_data'
#'
#' @return S3 Object
#'
new_cdmp_shop_data <- function() {

  # Define Class Environment
  rs <- new.env()

  # Define Class Members
  rs$file <- NULL
  rs$data <- NULL
  rs$conn <- psql_db_connect('comp_map_lib_prod')
  rs$key <- cdmp_shop_key()
  rs$shop_party <- NULL
  rs$competitor <- NULL

  # Update Class Path
  class(rs) <- c(setdiff('cdmp_shop_data', class(rs)), class(rs))

  # Return Object
  return(rs)

}

#' Validate that 'obj' is properly formatted S3 Object of class 'cdmp_shop_data'
#'
#' @param obj S3 Object
#' @param bool TRUE/FALSE - indicates if function should invisibly return 'obj' or 'TRUE/FALSE'
#'
#' @return S3 Object, TRUE/FALSE
#'
validate_cdmp_shop_data <- function(obj, bool) {

  # Validate Inputs
  if (missing(obj)) {stop("`obj` is missing in call to `validate_cdmp_shop_data`", call. = FALSE)}
  if (missing(bool)) {bool <- FALSE}

  # Validate Input Expectations
  expect_env(obj, c('file', 'data', 'conn', 'key', 'shop_party', 'competitor'))
  expect_scalar_logical(bool)

  # * file
  if (!isTRUE(is.null(obj$file))) {expect_scalar_char(obj$file)}

  # * data
  if (!isTRUE(is.null(obj$data))) {expect_data_frame(obj$data)}

  # * conn
  expect_dbi(obj$conn)

  # * key
  is_valid_key <- isTRUE(validate_cdmp_shop_key(obj$key, bool = TRUE))
  if (!isTRUE(is_valid_key)) {
    stop("`obj$key` is invalid in call to `validate_cdmp_shop_data`", call. = FALSE)
  }

  # * competitor
  if (!isTRUE(is.null(obj$competitor))) {expect_valid_competitor(df = obj$data, column = obj$competitor)}

  # * shop_party
  if (!isTRUE(is.null(obj$shop_party))) {
    expect_scalar_char(obj$shop_party)
    valid_shop_parties <- c('nlsn', 'iri', 'bst', 'twm', 'tws')
    if (!isTRUE(obj$shop_party %in% valid_shop_parties)) {
      stop("`obj$shop_party` must be a valid value in call to `validate_cdmp_shop_data`", call. = FALSE)
    }
  }

  # Return Result
  if (isTRUE(bool)) {return(TRUE)}
  else {invisible(obj)}

}

#' Initialize an S3 Object of class 'cdmp_shop_data'
#'
#' @return S3 Object
#' @export
#'
cdmp_shop_data <- function() {

  new_cdmp_shop_data() %>% validate_cdmp_shop_data()

}

#' S3 Generic - Load File into S3 Object of class 'cdmp_shop_data'
#'
#' @param obj S3 Object of class 'cdmp_shop_data'
#' @param name character - name of file
#' @param data data.frame - tabluar data
#'
#' @return NULL
#' @export
#'
load_file <- function(obj, name, data) {UseMethod("load_file", obj)}

#' S3 Generic - Clear File Data from S3 Object of class 'cdmp_shop_data'
#'
#' @param obj S3 Object of class 'cdmp_shop_data'
#'
#' @return NULL
#' @export
#'
clear_file <- function(obj) {UseMethod("clear_file", obj)}


#' S3 Generic - Set Key Values for S3 Object of class 'cdmp_shop_data'
#'
#' @param obj S3 Object of class 'cdmp_shop_data'
#' @param key list - named list of keys and their desrired values
#'
#' @return NULL
#' @export
#'
set_key <- function(obj, key) {UseMethod("set_key", obj)}

#' S3 Generic - Clear Key Values for S3 Object of class 'cdmp_shop_data'
#'
#' @param obj S3 Object of class 'cdmp_shop_data'
#' @param key character - vector of key names to clear
#'
#' @return NULL
#' @export
#'
clear_key <- function(obj, key) {UseMethod("clear_key", obj)}

#' S3 Generic - Set Shop Party Value for S3 Object of class 'cdmp_shop_data'
#'
#' @param obj S3 Object of class 'cdmp_shop_data'
#' @param shop_party character - desired shop party
#'
#' @return NULL
#' @export
#'
set_shop_party <- function(obj, shop_party) {UseMethod("set_shop_party", obj)}

#' S3 Generic - Clear Shop Party Value for S3 Object of class 'cdmp_shop_data'
#'
#' @param obj S3 Object of class 'cdmp_shop_data'
#'
#' @return NULL
#' @export
#'
clear_shop_party <- function(obj) {UseMethod("clear_shop_party", obj)}

#' S3 Generic - Set Competitor Value for S3 Object of class 'cdmp_shop_data'
#'
#' @param obj S3 Object of class 'cdmp_shop_data'
#' @param competitor character - specified column in 'obj$data' indicating competitor
#'
#' @return NULL
#' @export
#'
set_competitor <- function(obj, competitor) {UseMethod("set_competitor", obj)}

#' S3 Generic - Clear Competitor Value for S3 Object of class 'cdmp_shop_data'
#'
#' @param obj S3 Object of class 'cdmp_shop_data'
#'
#' @return NULL
#' @export
#'
clear_competitor <- function(obj) {UseMethod("clear_competitor", obj)}

#' S3 Generic - Clear Key Values for S3 Object of class 'cdmp_shop_data'
#'
#' @param obj S3 Object of class 'cdmp_shop_data'
#'
#' @return NULL
#' @export
#'
generate_shop_key <- function(obj) {UseMethod("generate_shop_key", obj)}

#' S3 Generic - Map Key Values for S3 Object of class 'cdmp_shop_data'
#'
#' @param obj S3 Object of class 'cdmp_shop_data'
#'
#' @return NULL
#' @export
#'
map_shop_key <- function(obj) {UseMethod("map_shop_key", obj)}

#' S3 Generic - Upsert Key Values for S3 Object of class 'cdmp_shop_data'
#'
#' @param obj S3 Object of class 'cdmp_shop_data'
#'
#' @return NULL
#' @export
#'
upsert_shop_key <- function(obj) {UseMethod("upsert_shop_key", obj)}

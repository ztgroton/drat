
CREATE OR REPLACE PROCEDURE public.record_match_log_insert(tbl TEXT, file_hash TEXT, map_schema TEXT, map_table TEXT)
LANGUAGE plpgsql SECURITY DEFINER
AS $$
DECLARE

  template_txt TEXT;

BEGIN

  -- Initialize 'template_text'
  select public.record_match_log_insert_template(tbl::TEXT, file_hash::TEXT, map_schema::TEXT, map_table::TEXT) into template_txt;

  -- Execute SQL Commands in 'template_txt'
  EXECUTE template_txt;

END
$$


CREATE TRIGGER map_lib_{schema}_{tablename}_trigger_insert AFTER INSERT  
ON {schema}.{tablename} REFERENCING NEW TABLE AS new_table
FOR EACH STATEMENT EXECUTE PROCEDURE public.log_map_lib();

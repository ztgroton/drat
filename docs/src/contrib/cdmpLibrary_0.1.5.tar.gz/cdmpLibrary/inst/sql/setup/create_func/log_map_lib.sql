
CREATE OR REPLACE FUNCTION public.log_map_lib() 
   RETURNS TRIGGER 
   LANGUAGE PLPGSQL
AS $$
BEGIN
   
   IF (TG_OP = 'INSERT') THEN
      
      EXECUTE public.map_lib_insert_template(TG_TABLE_SCHEMA, TG_TABLE_NAME);
      
   ELSIF (TG_OP = 'UPDATE') THEN
      
      EXECUTE public.map_lib_update_template(TG_TABLE_SCHEMA, TG_TABLE_NAME);
      
   ELSIF (TG_OP = 'DELETE') THEN
      
      EXECUTE public.map_lib_delete_template(TG_TABLE_SCHEMA, TG_TABLE_NAME);
      
   END IF;

   RETURN NULL;
   
END;
$$

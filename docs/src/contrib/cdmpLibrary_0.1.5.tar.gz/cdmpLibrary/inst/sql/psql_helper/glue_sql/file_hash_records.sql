
select

rl.file_hash,
fl.name as file_name,
fl.shop_party,
fl.upload_dt as file_upload_dt,

rl.orig_row_num,
rl.record_jsonb

from upload_files.record_log rl

inner join upload_files.file_log fl
on rl.file_hash = fl.file_hash

where fl.file_hash = {file_hash}

order by rl.orig_row_num

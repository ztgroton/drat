
#' Archive Table Data for Postgres DB
#'
#' @param conn DBIConnection - R Object representing PSQL DB Connection
#' @param schema character - Schema containing table to be archived
#' @param table character - Name of table to be archived
#' @param archive_only TRUE/FALSE - Optionally indicate if the table data should be archived only, or also returned as a data.frame
#'
#' @return data.frame or TRUE
#' @export
#'
#' @examples
#' \dontrun{
#' archive_psql_table('market', TRUE)
#' results <- archive_psql_table('market', FALSE)
#' results <- archive_psql_table('market')
#' }
archive_psql_table <- function(conn, schema, table, archive_only) {

  # Validate Inputs
  if (missing(conn)) {stop("`conn` is missing in call to `archive_psql_table`")}
  if (missing(schema)) {schema <- 'public'}
  if (missing(table)) {stop("`table` is missing in call to `archive_psql_table`")}
  if (missing(archive_only)) {archive_only <- FALSE}

  # Validate Input Expectations

  # * `conn`
  if (!isTRUE(inherits(conn, 'DBIConnection')) || !isTRUE(inherits(conn, 'PqConnection'))) {
    stop("`conn` must represent a PSQL DB Connection in call to `archive_psql_table`")
  }

  # * `schema`
  dbTools::expect_scalar_char(schema)

  # * `table`
  dbTools::expect_scalar_char(table)

  # * `archive_only`
  dbTools::expect_scalar_logical(archive_only)

  # Check if Table Exists
  does_table_exists <- DBI::dbGetQuery(
    conn = conn,
    glue::glue_sql(
      "SELECT EXISTS (
        SELECT FROM information_schema.tables
        WHERE  table_schema = {schema}
        AND    table_name   = {table}
      )",
      .con = conn
    )
  ) %>% as.logical()

  if (!isTRUE(does_table_exists)) {
    stop("`schema.table` does not exist in `conn` in call to `archive_psql_table`")
  }

  # Pull Table Data (If Table Exists)
  qry <- glue::glue("select * from {schema}.{table}")
  result <- DBI::dbGetQuery(conn, qry)

  # Archive Results
  archive_dir_path <- system.file("rds/archive/psql", package = 'marketPosData')
  archive_file_path <- file.path(archive_dir_path, schema, paste0(table, ".rds"))
  saveRDS(result, archive_file_path)

  # Return
  if (!isTRUE(archive_only)) {
    return(result)
  } else {
    invisible(TRUE)
  }

}

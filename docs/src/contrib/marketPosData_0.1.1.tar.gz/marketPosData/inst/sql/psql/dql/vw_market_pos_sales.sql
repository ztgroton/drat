
WITH latest_upload AS
(
  select
  t.market_name,
  t.shop_party,
  t.department,
  t.week_ending,
  max(t.upload_date) as upload_date

  from common.market_scan_upload t

  where t.market_name IN ({markets*})
  and t.department IN ({dept*})
  and t.shop_party = {shop_party}

  group by t.market_name, t.shop_party, t.department, t.week_ending
),

latest_week_ending AS
(
  select
  t.market_name,
  t.shop_party,
  t.department,
  max(t.week_ending) as week_ending

  from latest_upload t
  group by t.market_name, t.shop_party, t.department
),

latest_file AS
(
  select distinct
  lu.market_name,
  lu.shop_party,
  lu.department,
  lu.week_ending,
  lu.upload_date

  from latest_upload lu

  inner join latest_week_ending lw
  on lu.market_name = lw.market_name
  and lu.shop_party = lw.shop_party
  and lu.department = lw.department
  and lu.week_ending = lw.week_ending
)

select
msud.shop_party,
msud.market_name as market,
mkt.type as market_type,
msud.department,
msud.week_ending as week_ending_scan_period,
msud.long_product_description as item_name,
CAST(msud.upc as NUMERIC) as upc,
msud.sales_dollars as sales_dollars,
msud.sales_dollars_ya as sales_dollars_ya

from common.market_scan_upload_detail msud

inner join common.file_upload fu
on msud.file_id = fu.id

inner join common.market_scan_upload msu
on msud.market_name = msu.market_name
and msud.shop_party = msu.shop_party
and msud.department = msu.department
and msud.week_ending = msu.week_ending
and msud.file_name = msu.file_name
and msud.upload_date = msu.upload_date

inner join common.market mkt
on msu.market_name = mkt.name

inner join latest_file
on msu.market_name = latest_file.market_name
and msu.shop_party = latest_file.shop_party
and msu.department = latest_file.department
and msu.week_ending = latest_file.week_ending
and msu.upload_date = latest_file.upload_date

where msu.market_name IN ({markets*})
and msu.department IN ({dept*})
and msu.shop_party = {shop_party}

order by msud.sales_dollars desc

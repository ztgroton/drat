
#' Log New Entry in 'upload_files.file_log' table
#'
#' @importFrom rlang .data
#'
#' @param data data.frame
#' @param name character
#' @param shop_party character
#'
#' @return character
#' @export
#'
#' @examples
#' \dontrun{
#' log_upload_file(raw_data, 'testname', 'nlsn')
#' }
log_upload_file <- function(data, name, shop_party) {

  # Validate Inputs
  if (missing(data)) {stop("`data` is missing in call to `log_upload_file`")}
  if (missing(name)) {name <- as.character(deparse(substitute(data)))}
  if (missing(shop_party)) {stop("`shop_party` is missing in call to `log_upload_file`")}

  # Validate Input Expectations

  # * `data`
  if (!isTRUE(is.data.frame(data))) {
    stop("`data` must be data.frame in call to `log_upload_fule`")
  }

  if (!isTRUE('_ORIG_ROW_NUMBER_' %in% colnames(data))) {
    stop("`colnames(data)` must contain '_ORIG_ROW_NUMBER_' in call to `log_upload_file`")
  }

  # Rename `data$`_ORIG_ROW_NUMBER_`
  data <- data %>%
    dplyr::rename(orig_row_num = .data$`_ORIG_ROW_NUMBER_`) %>%
    dplyr::relocate(.data$orig_row_num)

  # Validate that `data$orig_row_num` is DENSE
  if (!isTRUE(identical(sort(unique(data$orig_row_num)), 1:nrow(data)))) {
    stop("`data$orig_row_num` must be DENSE in call to `log_upload_file`")
  }

  # * `name`
  if (!isTRUE(is.character(name)) || !isTRUE(length(name) == 1) || !isFALSE(is.na(name))) {
    stop("`name` must be Non-NA length 1 character vector in call to `log_upload_file`")
  }

  # * `shop_party`
  if (!isTRUE(is.character(shop_party)) || !isTRUE(length(shop_party) == 1) || !isFALSE(is.na(shop_party))) {
    stop("`shop_party` must be Non-NA length 1 character vector in call to `log_upload_file`")
  }

  # Generate File Hash
  cat("Generating File Hash... ")
  tictoc::tic()
  file_hash <- digest::digest(
    object = list(data, name, shop_party, Sys.time()),
    algo = 'sha256', serialize = TRUE
  )
  tictoc::toc()

  # Upload `obj$data` to Temp Table
  cat("Uploading Table Data to Public Schema... ")
  tictoc::tic()
  tbl_name <- upload_tmp_tbl(data = data)
  tictoc::toc()

  # Setup DB Connection
  psql_conn <- psql_db_connect('comp_map_lib')

  tryCatch({

    # Post-Process `obj$data` and Load into `upload_files.record_log`
    cat("Loading `obj$data` into `upload_files.file_log`... ")
    tictoc::tic()
    qry <- glue::glue_sql(
      "CALL public.file_log_insert(
	      {file_hash}::TEXT,
	      {name}::TEXT,
	      {shop_party}::TEXT
      )"
      , .con = psql_conn
    )

    DBI::dbExecute(psql_conn, qry)
    tictoc::toc()

    cat("Loading `obj$data` into `upload_files.record_log`... ")
    tictoc::tic()
    qry <- glue::glue_sql(
      "CALL public.record_log_insert(
	      {tbl_name}::TEXT,
	      {file_hash}::TEXT
      )"
      , .con = psql_conn
    )

    DBI::dbExecute(psql_conn, qry)
    tictoc::toc()

    # Dropping Temporary Table
    cat("Cleaning Up `obj$data` from Public Schema... ")
    tictoc::tic()
    drop_tmp_tbl(name = tbl_name)
    tictoc::toc()

    # Close DB Connection
    DBI::dbDisconnect(psql_conn)
    rm(psql_conn)

    # Return `file_hash`
    return(file_hash)

  }, error = function(e) {

    # Close DB Connection
    DBI::dbDisconnect(psql_conn)
    rm(psql_conn)

    # Stop with Error
    stop(sprintf("Error in %s: %s", deparse(e[["call"]]), e[["message"]]))

  })

}

#' Upload R Data.Frame to PSQL Table in 'public' schema
#'
#' @param data data.frame
#'
#' @return character
#' @export
#'
#' @examples
#' \dontrun{
#' upload_tbl_name <- upload_tmp_tbl(raw_data)
#' }
upload_tmp_tbl <- function(data) {

  # Validate Inputs
  if (missing(data)) {stop("`data` is missing in call to `upload_tmp_tbl`")}

  # Validate Input Expectations

  # * `data`
  if (!isTRUE(is.data.frame(data))) {
    stop("`data` must be data.frame in call to `upload_tmp_tbl`")
  }

  # Generate Random Table Name
  tbl_name <- gen_unq_name()

  # Initialize File Upload Table ID
  tbl_id <- DBI::Id(schema = 'public', table = tbl_name)

  # Generate Table Hash
  tbl_hash <- digest::digest(object = tbl_id, algo = 'sha256', serialize = TRUE)

  tryCatch({

    # Setup DB Connection
    psql_conn <- psql_db_connect('comp_map_lib')

    # Create Empty Table
    DBI::dbCreateTable(
      conn = psql_conn,
      name = tbl_id,
      fields = data
    )

    # Upload Data
    dbx::dbxInsert(
      conn = psql_conn,
      table = tbl_id,
      records = data
    )

    # Close DB Connection
    DBI::dbDisconnect(psql_conn)
    rm(psql_conn)

    # Return `tbl_name`
    return(tbl_name)

  }, error = function(e) {

    # Close DB Connection
    DBI::dbDisconnect(psql_conn)
    rm(psql_conn)

    # Stop with Error
    stop(sprintf("Error in %s: %s", deparse(e[["call"]]), e[["message"]]))

  })

}

#' Upload R Data.Frame to PSQL Table in 'public' schema
#'
#' @param name character
#'
#' @return TRUE
#' @export
#'
#' @examples
#' \dontrun{
#' drop_tmp_tbl('testfile')
#' }
drop_tmp_tbl <- function(name) {

  # Validate Inputs
  if (missing(name)) {stop("`name` is missing in call to `drop_tmp_tbl`")}

  # Validate Input Expectations

  # * `name`
  if (!isTRUE(is.character(name)) || !isTRUE(length(name) == 1) || !isFALSE(is.na(name))) {
    stop("`name` must be Non-NA length 1 character vector in call to `drop_tmp_tbl`")
  }

  # Initialize Query Template
  qry <- "DROP TABLE IF EXISTS public.{`name`}"

  tryCatch({

    # Setup DB Connection
    psql_conn <- psql_db_connect('comp_map_lib')

    # Bind Parameter Values to Query
    qry <- glue::glue_sql(qry, .con = psql_conn)

    # Execute SQL Query
    DBI::dbExecute(psql_conn, qry)

    # Close DB Connection
    DBI::dbDisconnect(psql_conn)
    rm(psql_conn)

    # Return Success
    invisible(TRUE)

  }, error = function(e) {

    # Close DB Connection
    DBI::dbDisconnect(psql_conn)
    rm(psql_conn)

    # Stop with Error
    stop(sprintf("Error in %s: %s", deparse(e[["call"]]), e[["message"]]))

  })

}


#' Retrieve All Current Mappings from Mapping Library
#'
#' @param conn DBIConnection
#' @param use_dev logical
#'
#' @return data.frame
#' @export
#'
#' @examples
#' \dontrun{
#' results <- current_mappings(conn = psql_conn)
#' }
current_mappings <- function(conn, use_dev = FALSE) {

  # Validate Inputs
  if (missing(conn)) {stop("`conn` is missing in call to `current_mappings`")}
  if (missing(use_dev)) {use_dev <- FALSE}

  # Validate Input Expectations

  # * `conn`
  if (!isTRUE(inherits(conn, 'DBIConnection'))) {
    stop("`conn` must inherit from 'DBIConnection' in call to `current_mappings`")
  }

  # * `use_dev`
  if (!isTRUE(identical(use_dev, TRUE)) && !isTRUE(identical(use_dev, FALSE))) {
    stop("`use_dev` must be identical to TRUE/FALSE in call to `current_mappings`")
  }

  # Iterate over `names(valid_mapping_schemas)`
  results <- purrr::map(names(cdmpLibrary::valid_mapping_schemas), function(schema) {

    # Get Schema Tables
    tables <- cdmpLibrary::valid_mapping_schemas[[schema]]

    # Iterate Over `tables`
    table_results <- purrr::map(tables, function(table) {

      # Fetch Mappings Specified by 'schema.table'
      cat(paste0("Querying Mappings for '", schema, '.', table, "'... "))
      tictoc::tic()

      res <- vw_map_key(schema = schema, table = table, use_dev = use_dev)

      res <- res %>%
        dplyr::select(.data$key_hash) %>%
        dplyr::mutate(schema = schema, table = table)

      tictoc::toc()
      return(res)

    })
    names(table_results) <- tables

    # Coalesce `table_results` into single data.frame
    table_results <- purrr::reduce(table_results, `rbind`)

    # Return Table Results
    return(table_results)

  })
  names(results) <- names(cdmpLibrary::valid_mapping_schemas)

  # Coalesce `results` into single data.frame
  results <- purrr::reduce(results, `rbind`) %>% dplyr::distinct()

  # Return Results
  return(results)

}


#' Generate Random Table Name
#'
#' @param use_date logical
#'
#' @return character
#' @export
#'
#' @examples
#' \dontrun{
#' output <- gen_unq_name(use_date = TRUE)
#' }
gen_unq_name <- function(use_date = TRUE) {

  # Validate Inputs
  if (missing(use_date)) {use_date <- TRUE}

  # Validate Input Expectations
  if (!isTRUE(identical(use_date, TRUE)) && !isTRUE(identical(use_date, FALSE))) {
    stop("`use_date` must be identical to TRUE/FALSE in call to `gen_unq_name`")
  }

  # Conditionally Generate Formatted TimeStamp String
  if (isTRUE(use_date)) {
    time_str <- as.POSIXct(Sys.time())
    time_str <- gsub(' ', '_', time_str, fixed = TRUE)
    time_str <- gsub(':', '_', time_str, fixed = TRUE)
    time_str <- gsub('-', '_', time_str, fixed = TRUE)
  }

  # Generate Random String of Length 5
  letter_str <- paste(
    sample(c(0:9, letters, LETTERS), 5, replace = TRUE)
    , collapse = ""
  )

  # Generate Final String
  if (isTRUE(use_date)) {
    final_str <- paste('tbl', letter_str, time_str, sep = '_')
  } else {
    final_str <- paste('tbl', letter_str, sep = '_')
  }

  # Return Final String
  return(final_str)

}

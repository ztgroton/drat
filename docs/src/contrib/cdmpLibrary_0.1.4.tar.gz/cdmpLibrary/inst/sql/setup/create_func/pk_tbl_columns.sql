
CREATE OR REPLACE FUNCTION public.pk_tbl_columns(sch TEXT, tbl TEXT)
  RETURNS TEXT[]
  LANGUAGE PLPGSQL
AS $$
DECLARE

  result TEXT[];

BEGIN

  -- Insert Primary Key Columns into Text Array
  EXECUTE format(
    'SELECT ARRAY( '
    '  SELECT c.column_name::TEXT '
    '  '
    '  FROM information_schema.columns c '
    '  '
    '  INNER JOIN information_schema.tables t '
    '  ON t.table_name = c.table_name '
    '  AND t.table_schema = c.table_schema '
    '  AND t.table_catalog = c.table_catalog '
    '  '
    '  INNER JOIN  ' -- primary keys
    '  ( '
    '    SELECT DISTINCT '
    '    tc.constraint_name, tc.table_name, tc.table_schema, tc.table_catalog, kcu.column_name '
    '    FROM information_schema.table_constraints AS tc '
    '    JOIN information_schema.key_column_usage AS kcu '
    '    ON tc.constraint_name = kcu.constraint_name '
    '    WHERE constraint_type = ''PRIMARY KEY'' '
    '  ) pk '
    '  ON pk.table_name = c.table_name '
    '  AND pk.column_name = c.column_name '
    '  AND pk.table_schema = c.table_schema '
    '  AND pk.table_catalog = c.table_catalog '
    ' '
    '  WHERE c.table_schema = %L '
    '  AND c.table_name = %L '
    '  AND t.table_type = ''BASE TABLE'''
    '  '
    '  ORDER BY t.table_schema, t.table_name, c.ordinal_position '
    ') '
    , sch::TEXT, tbl::TEXT
  ) INTO result;

  -- Return Result
  RETURN result;

END;
$$

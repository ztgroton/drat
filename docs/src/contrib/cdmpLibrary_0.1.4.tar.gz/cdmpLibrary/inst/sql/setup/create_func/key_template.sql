
CREATE OR REPLACE FUNCTION public.key_template(sch TEXT, tbl TEXT)
  RETURNS TEXT
  LANGUAGE PLPGSQL
AS $$
DECLARE

  result TEXT;

BEGIN

  -- Build SELECT statement to generate key values
  SELECT format(
    CONCAT(
      'select '::TEXT, -- 'create temp table {schema}_{table}_key_template_data as select '
      public.pk_tcol_template(sch::TEXT, tbl::TEXT)::TEXT, ' '::TEXT,
      public.pk_col_jsonb(sch::TEXT, tbl::TEXT)::TEXT, ' '::TEXT,
      public.pk_col_hash(sch::TEXT, tbl::TEXT)::TEXT, ' '::TEXT,
      CONCAT('from '::TEXT, sch::TEXT, '.'::TEXT, tbl::TEXT, ' t'::TEXT)::TEXT
    )::TEXT
  ) INTO result;

  -- Return Result
  RETURN result;

END;
$$


CREATE OR REPLACE PROCEDURE public.file_log_insert(file_hash TEXT, name TEXT, shop_party TEXT)
LANGUAGE plpgsql SECURITY DEFINER
AS $$
DECLARE

  template_txt TEXT;

BEGIN

  -- Initialize 'template_text'
  select public.file_log_insert_template(file_hash::TEXT, name::TEXT, shop_party::TEXT) into template_txt;

  -- Execute SQL Commands in 'template_txt'
  EXECUTE template_txt;

END
$$

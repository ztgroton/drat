
CREATE OR REPLACE FUNCTION public.map_table_rebuild_template(
  map_schema TEXT, map_table TEXT
)
  RETURNS TEXT
  LANGUAGE PLPGSQL
AS $$
DECLARE

  result TEXT;

BEGIN

  -- Build SELECT statement to generate key values
  result := CONCAT(
    format('create table public.new_%I_%I as ', map_schema::TEXT, map_table::TEXT),
    'select '::TEXT,
    public.pk_col_hash(map_schema::TEXT, map_table::TEXT, TRUE)::TEXT, ' as key_hash, ',
    't.* ',
    format('from %I.%I as t ', map_schema::TEXT, map_table::TEXT)
  );

  -- Return Result
  RETURN result;

END;
$$


record_w_matches <- record_log %>%
  dplyr::left_join(record_match_log, by = c('file_hash', 'orig_row_num')) %>%
  dplyr::select(
    file_hash,
    orig_row_num,
    record_jsonb,
    record_hash,
    match_type,
    key_hash,
    map_hash
  )

record_w_matches_item <- record_w_matches %>%
  dplyr::left_join(twm_map, by = 'map_hash') %>%
  dplyr::select(
    file_hash,
    orig_row_num,
    record_jsonb,
    match_type,
    key_hash,
    twm_item_code,
    twm_position_key
  ) %>%
  dplyr::arrange(file_hash, orig_row_num, match_type)


SELECT DISTINCT

CASE
  WHEN tc.constraint_name IS NOT NULL THEN tc.constraint_name
  ELSE CONCAT('PK_', tc.table_name)
END as constraint_name,

tc.table_schema as schema_name,
tc.table_name as table_name,
kcu.column_name

FROM information_schema.table_constraints AS tc

INNER JOIN information_schema.key_column_usage AS kcu
ON tc.constraint_name = kcu.constraint_name

WHERE constraint_type = 'PRIMARY KEY'
AND tc.table_catalog = {db}

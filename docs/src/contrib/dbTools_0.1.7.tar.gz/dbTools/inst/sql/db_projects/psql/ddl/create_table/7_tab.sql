
CREATE TABLE IF NOT EXISTS common.tab
(
  id SERIAL,
  sch_id INTEGER NOT NULL,
  name TEXT NOT NULL,
  is_qry BOOLEAN NOT NULL,
  def TEXT NOT NULL,
  pk_name TEXT NOT NULL,

  CONSTRAINT common_tab_pkey PRIMARY KEY (id),
  CONSTRAINT common_tab_fkey1 FOREIGN KEY (sch_id) REFERENCES common.sch (id) ON UPDATE CASCADE ON DELETE RESTRICT
)

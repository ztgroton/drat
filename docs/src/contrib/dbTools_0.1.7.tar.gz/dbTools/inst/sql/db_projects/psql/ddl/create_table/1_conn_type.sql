
CREATE TABLE IF NOT EXISTS common.conn_type
(
  id SERIAL,
  name TEXT NOT NULL,

  CONSTRAINT common_conn_type_pkey PRIMARY KEY (id),
  CONSTRAINT common_conn_type_unq1 UNIQUE (name)
)

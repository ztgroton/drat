test_that("`is_psql` works", {
  expect_true(is_psql(psql_db_connect('comp_map_lib')))
})

test_that("`is_mssql` works", {
  expect_true(is_mssql(mssql_db_connect('Apex')))
})

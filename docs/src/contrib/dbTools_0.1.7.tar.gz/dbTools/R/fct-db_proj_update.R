
#' S3 Method - Update Existing Entry in 'db_projects'
#'
#' @param obj S3 Class
#' @param ... ellipsis
#'
#' @return TRUE
#' @export
#'
db_proj_update.db_proj_field_type <- function(obj, ...) {

  # Validate Input
  if (missing(obj)) {
    stop("`obj` is missing in call to `db_proj_update.db_proj_field_type`", call. = FALSE)
  }

  # Gather `dot_arg`
  dot_arg <- dots_to_list(...)

}

#' S3 Method - Update Existing Entry in 'db_projects'
#'
#' @param obj S3 Class
#' @param ... ellipsis
#'
#' @return TRUE
#' @export
#'
db_proj_update.db_proj_conn_type <- function(obj, ...) {

  # Validate Input
  if (missing(obj)) {
    stop("`obj` is missing in call to `db_proj_update.db_proj_conn_type`", call. = FALSE)
  }

  # Gather `dot_arg`
  dot_arg <- dots_to_list(...)

}

#' S3 Method - Update Existing Entry in 'db_projects'
#'
#' @param obj S3 Class
#' @param ... ellipsis
#'
#' @return TRUE
#' @export
#'
db_proj_update.db_proj_default_type_map <- function(obj, ...) {

  # Validate Input
  if (missing(obj)) {
    stop("`obj` is missing in call to `db_proj_update.db_proj_default_type_map`", call. = FALSE)
  }

  # Gather `dot_arg`
  dot_arg <- dots_to_list(...)

}

#' S3 Method - Update Existing Entry in 'db_projects'
#'
#' @param obj S3 Class
#' @param ... ellipsis
#'
#' @return TRUE
#' @export
#'
db_proj_update.db_proj_conn <- function(obj, ...) {

  # Validate Input
  if (missing(obj)) {
    stop("`obj` is missing in call to `db_proj_update.db_proj_conn`", call. = FALSE)
  }

  # Gather `dot_arg`
  dot_arg <- dots_to_list(...)

}

#' S3 Method - Update Existing Entry in 'db_projects'
#'
#' @param obj S3 Class
#' @param ... ellipsis
#'
#' @return TRUE
#' @export
#'
db_proj_update.db_proj_conn_param <- function(obj, ...) {

  # Validate Input
  if (missing(obj)) {
    stop("`obj` is missing in call to `db_proj_update.db_proj_conn_param`", call. = FALSE)
  }

  # Gather `dot_arg`
  dot_arg <- dots_to_list(...)

}

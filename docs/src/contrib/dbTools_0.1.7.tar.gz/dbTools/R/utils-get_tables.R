
#' List Existing EDAP PSQL Tables
#'
#' @param conn DBI Connection
#' @param schema character - optional list of schemas
#'
#' @importFrom rlang .data
#' @return data.frame
#' @export
#'
get_psql_table <- function(conn, schema) {

  # Validate Inputs

  # * `conn`
  if (missing(conn)) {stop("`conn` is missing in call to `get_psql_table`", call. = FALSE)}
  expect_dbi(conn)

  if (!isTRUE(is_psql(conn))) {stop("`conn` must be PSQL Connection in call to `get_psql_table`", call. = FALSE)}

  # * `schema`
  if (missing(schema) || isTRUE(is.null(schema))) {

    schema <- NULL
    schema_list <- get_psql_schema(conn = conn) %>%
      dplyr::distinct(.data$schema) %>%
      dplyr::pull(.data$schema)

  } else {

    expect_data_type(obj = schema, type = 'character', nz_len = TRUE)
    schema_psql <- get_psql_schema(conn = conn) %>%
      dplyr::distinct(.data$schema) %>%
      dplyr::pull(.data$schema)

    if (!isTRUE(all(schema %in% schema_psql))) {
      stop("`schema` must be element of PSQL DB names in call to `get_psql_table`", call. = FALSE)
    }

    schema_list <- schema

  }

  # MAIN LOGIC

  # Initialize Table Query
  table_qry <- readr::read_file(system.file('sql/metadata/get_tables/psql_list_tables.sql', package = 'dbTools'))

  # Setup Schemas for 'db'
  db_schema_list <- get_psql_schema(conn) %>%
    dplyr::distinct(.data$schema) %>%
    dplyr::pull(.data$schema)

  db_schema_list <- unique(intersect(db_schema_list, schema_list))

  # Execute and Return
  db_schema_tables <- lapply(db_schema_list, function(sch) {

    rs <- DBI::dbGetQuery(
      conn,
      glue::glue_sql(
        table_qry,
        schema_val = sch,
        .con = conn
      )
    ) %>% as.data.frame()

    rs

  })

  dplyr::bind_rows(db_schema_tables)

}

#' List Existing MSSQL Tables
#'
#' @param conn DBI Connection
#' @param schema character - optional list of schemas
#'
#' @importFrom rlang .data
#' @return data.frame
#' @export
#'
get_mssql_table <- function(conn, schema) {

  # Validate Inputs

  # * `conn`
  if (missing(conn)) {stop("`conn` is missing in call to `get_mssql_table`", call. = FALSE)}
  expect_dbi(conn)

  if (!isTRUE(is_mssql(conn))) {stop("`conn` must be MSSQL Connection in call to `get_mssql_table`", call. = FALSE)}

  # * `schema`
  if (missing(schema) || isTRUE(is.null(schema))) {

    schema <- NULL
    schema_list <- get_mssql_schema(conn = conn) %>%
      dplyr::distinct(.data$schema) %>%
      dplyr::pull(.data$schema)

  } else {

    expect_data_type(obj = schema, type = 'character', nz_len = TRUE)
    schema_mssql <- get_mssql_schema(conn = conn) %>%
      dplyr::distinct(.data$schema) %>%
      dplyr::pull(.data$schema)

    if (!isTRUE(all(schema %in% schema_mssql))) {
      stop("`schema` must be element of MSSQL DB names in call to `get_mssql_table`", call. = FALSE)
    }

    schema_list <- schema

  }

  # MAIN LOGIC

  # Initialize Table Query
  table_qry <- readr::read_file(system.file('sql/metadata/get_tables/mssql_list_tables.sql', package = 'dbTools'))

  # Setup Schemas for 'db'
  db_schema_list <- get_mssql_schema(conn = conn) %>%
    dplyr::distinct(.data$schema) %>%
    dplyr::pull(.data$schema)

  db_schema_list <- intersect(db_schema_list, schema_list)

  # Execute and Return
  db_schema_tables <- lapply(db_schema_list, function(sch) {

    rs <- DBI::dbGetQuery(
      conn,
      glue::glue_sql(
        table_qry,
        schema_val = sch,
        .con = conn
      )
    ) %>% as.data.frame()

    rs

  })

  dplyr::bind_rows(db_schema_tables)

}


#' List All Existing Tables in R DBI Connection
#'
#' @param conn DBI Connection
#' @param schema character - optional list of specific schema
#'
#' @return data.frame
#' @export
#'
get_tables <- function(conn, schema) {

  # Validate Inputs
  if (missing(conn)) {stop("`conn` is missing in call to `get_tables`", call. = FALSE)}
  expect_dbi(conn)

  if (missing(schema)) {schema <- NULL}

  # MAIN LOGIC

  if (isTRUE(is_psql(conn))) { # PSQL
    return(get_psql_table(conn, schema))
  } else if (isTRUE(is_mssql(conn))) { # MSSQL
    return(get_mssql_table(conn, schema))
  } else {
    stop("`get_tables` must be called on PSQL or MSSQL connection", call. = FALSE)
  }

}

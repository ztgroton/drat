
#' Archive BigQuery Tables and Save as RDS files to Local Directory
#'
#' @param x R Object - 'bq_table' object or list of 'bq_table' objects
#' @param arch_dir character - top-level folder path in which to save archived data
#'
#' @return TRUE
#' @export
#'
archive_bq_tbl <- function(x, arch_dir) {

  # Validate Inputs
  if (missing(x)) {stop("`x` is missing in call to `archive_bq_tbl`", call. = FALSE)}
  if (missing(arch_dir)) {stop("`arch_dir` is missing in call to `archive_bq_tbl`", call. = FALSE)}

  # Validate Expectations

  # * `x`
  is_bq_tbl <- is_valid_bq_tbl(x)
  is_bq_tbl_list <- is_valid_bq_tbl_list(x)
  if (!isTRUE(is_bq_tbl) && !isTRUE(is_bq_tbl_list)) {
    stop("`x` must be 'bq_table' or list containing only 'bq_table' elements in call to `archive_bq_tbl`")
  }

  # * `arch_dir`
  dbTools::expect_scalar_char(arch_dir)

  # Prepare Iteration List
  if (isTRUE(is_bq_tbl)) {x <- list(x)}

  # Iterate over `x` / Query Table Contents and archive
  purrr::walk(x, function(t) {

    # Table Dataset
    dataset <- t$dataset

    # Table Name
    tbl_name <- t$table

    # Create 'dataset' subfolder (no effect if already exists)
    dataset_dir <- file.path(arch_dir, dataset)
    dir.create(dataset_dir, showWarnings = FALSE)

    # Query Table Contents
    cat("\nQuerying Table '", glue::glue("{dataset}.{tbl_name}"), "'...")
    tictoc::tic()
    tbl_contents <- bq_tbl_select(t)
    tictoc::toc()

    # Archive Table Contents
    cat("Archiving Table '", glue::glue("{dataset}.{tbl_name}"), "'...")
    tictoc::tic()
    contents_path <- file.path(dataset_dir, tbl_name)
    saveRDS(tbl_contents, paste0(contents_path, '.rds'))
    tictoc::toc()

    # Collect Garbage
    cat("Collecting Garbage...")
    tictoc::tic()
    rm(dataset, tbl_name, dataset_dir, tbl_contents, contents_path)
    gc()
    tictoc::toc()
    cat("\n")

  })

  # Return Success
  invisible(TRUE)

}

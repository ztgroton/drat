
#' List All Existing EDAP PSQL Databases
#'
#' @return character vector
#'
get_psql_db <- function() {

  conn <- psql_db_connect('postgres')
  res <- DBI::dbGetQuery(conn, readr::read_file(system.file('sql/metadata/get_db/psql_list_databases.sql', package = 'dbTools')))
  DBI::dbDisconnect(conn)
  rm(conn)

  return(res$db_name)

}

#' List All Existing TWM MSSQL Databases
#'
#' @return character vector
#'
get_mssql_db <- function() {

  valid_mssql_db <- c('Apex', 'Apex_MerchSolutions', 'Store', 'StoreLayout')
  return(valid_mssql_db)

}


#' List All Existing EDAP PSQL Databases
#'
#' @param conn character - 'psql' or 'mssql'
#'
#' @return character vector
#' @export
#'
get_db <- function(conn) {

  # Validate Inputs
  if (missing(conn)) {stop("`conn` is missing in call to `get_db`", call. = FALSE)}
  expect_scalar_char(conn)

  if (!isTRUE(conn %in% c('psql', 'mssql'))) {
    stop("`conn` must equal 'psql' or 'mssql' in call to `get_db`", call. = FALSE)
  }

  if (isTRUE(conn == 'psql')) {
    return(get_psql_db())
  } else if (isTRUE(conn == 'mssql')) {
    return(get_mssql_db())
  }

}


#' Validate if a set of columns 'fk' is a Foreign Key on data frames 'x' and 'y'
#'
#' @param conn DBI Connection
#' @param tables list - Named list of length 2. Elements specify 'parent_tbl' and 'child_tbl' tables
#' @param columns list - Named list of length 2. Elements specify ordered columns from tables to be used for Foreign Key.
#'
#' @return R Object
#' @export
#'
sql_nest_fk <- function(conn, tables, columns) {

  # Validate Inputs
  if (missing(conn)) {stop("`conn` is missing in call to `sql_col_nest`", call. = FALSE)}
  if (missing(tables)) {stop("`tables` is missing in call to `sql_col_nest`", call. = FALSE)}
  if (missing(columns)) {stop("`columns` is missing in call to `sql_col_nest`", call. = FALSE)}

  # Validate Expectations
  expect_dbi(conn)
  #expect_list(obj = tables, names = c('child_tbl', 'parent_tbl'))
  #expect_list(obj = columns, names = c('child_tbl', 'parent_tbl'))

  # * `tables`
  tables_ind1 <- purrr::map_lgl(tables, function(x){expect_list(x, names = c('schema', 'table'), type = 'character')})
  if (!isTRUE(all(tables_ind1))) {
    stop("`tables` elements invalidly formatted in call to `sql_col_nest`", call. = FALSE)
  }

  # * `columns`
  columns_ind1 <- purrr::map_lgl(columns, function(x){expect_data_type(obj = x, type = 'character', nz_len = TRUE)})
  if (!isTRUE(all(columns_ind1))) {
    stop("`columns` elements invalidly formatted in call to `sql_col_nest`", call. = FALSE)
  }

  columns_length <- purrr::map_dbl(columns, function(x){length(x)})
  if (!isTRUE(length(columns_length) == 2)){stop("`columns` must have length 2 in call to `sql_col_nest`", call. = FALSE)}
  if (!isTRUE(length(unique(columns_length)) == 1)) {stop("`columns` elements must have equal lengths in call to `sql_col_nest`", call. = FALSE)}

  # Compute `child_nest`
  child_nest <- sql_col_nest(
    conn = conn,
    schema = tables$child_tbl$schema,
    table = tables$child_tbl$table,
    columns = columns$child_tbl
  )

  child_nest <- child_nest %>% dplyr::select(-.data$nest_row_cnt)

  # Compute `parent_nest`
  parent_nest <- sql_col_nest(
    conn = conn,
    schema = tables$parent_tbl$schema,
    table = tables$parent_tbl$table,
    columns = columns$parent_tbl
  )

  parent_nest <- parent_nest %>% dplyr::select(-.data$nest_row_cnt)

  # Full Join `child_nest` and `parent_nest`
  fk <- columns$parent_tbl
  names(fk) <- columns$child_tbl

  full_nest <- child_nest %>%
    dplyr::full_join(parent_nest, by = fk, suffix = c('_x', '_y'), na_matches = "never")

  # Compute Lengths
  full_nest <- full_nest %>%
    dplyr::mutate(row_num_cnt_child = purrr::map_dbl(.data$nest_row_num_x, ~ ifelse(is.null(.x), 0, nrow(.x)))) %>%
    dplyr::mutate(row_num_cnt_parent = purrr::map_dbl(.data$nest_row_num_y, ~ ifelse(is.null(.x), 0, nrow(.x))))

  # Return
  class(full_nest) <- c(setdiff('sql_nest_fk', class(full_nest)), class(full_nest))
  return(full_nest)

}


#' Convert Ellipsis into Named List of Variables
#'
#' @param ... R Ellipsis
#'
#' @return list
#' @export
#'
dots_to_list <- function(...) {

  result <- list(...)

  if (isTRUE(length(result) == 0)) {return(result)}

  result_names <- attr(result, 'names')
  result_is_named <- !isTRUE(is.null(result_names))

  if (!isTRUE(result_is_named)) {

    stop("`result` must have `names(result)` defined in call to `dots_to_list`", call. = FALSE)

  } else {

    if (!isTRUE(is.character(result_names))) {
      stop("`names(result)` must be `character` in call to `dots_to_list`", call. = FALSE)
    }

    any_na <- isTRUE(any(purrr::map_lgl(result_names, ~ isTRUE(is.na(.)))))
    if (isTRUE(any_na)) {
      stop("`names(result)` cannot contain NA values in call to `dots_to_list`", call. = FALSE)
    }

    any_null <- isTRUE(any(purrr::map_lgl(result_names, ~ isTRUE(is.null(.)))))
    if (isTRUE(any_null)) {
      stop("`names(result)` cannot contain NULL values in call to `dots_to_list`", call. = FALSE)
    }

    any_empty <- isTRUE(any(purrr::map_lgl(result_names, ~ isTRUE(nchar(.) == 0))))
    if (isTRUE(any_empty)) {
      stop("`names(result)` cannot contain empty '' values in call to `dots_to_list`", call. = FALSE)
    }

  }

  return(result)

}

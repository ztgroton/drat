
#' Connect to Microsoft MSSQL Database
#'
#' @param db character - Name of an existing database
#'
#' @return DBIConnection - R Object handle for the newly opened connection
#' @export
#'
mssql_db_connect <- function(db) {

  if (missing(db)) {stop("`db` is missing in call to `mssql_db_connect`", call. = FALSE)}
  if (!isTRUE(db %in% c('Apex', 'Apex_MerchSolutions', 'Store', 'StoreLayout'))) {
    stop("`db` must equal c('Apex', 'Apex_MerchSolutions', 'Store', 'StoreLayout') in call to `mssql_db_connect`")
  }

  if (isTRUE(db == 'Apex')) {
    db_driver <- "SQL Server"
    db_server <- "CS-PDB-MIRROR\\TWSQL"
    db_name <- "Apex"
  } else if (isTRUE(db == 'Apex_MerchSolutions')) {
    db_driver <- "ODBC Driver 13 for SQL Server"
    db_server <- "CS-PDB-PARTNER"
    db_name <- "Apex_MerchSolutions"
  } else if (isTRUE(db == 'StoreLayout')) {
    db_driver <- "ODBC Driver 13 for SQL Server"
    db_server <- "CS-PDB-MIRROR\\TWSQL"
    db_name <- "StoreLayout"
  } else if (isTRUE(db == 'Store')) {
    db_driver <- "ODBC Driver 13 for SQL Server"
    db_server <- "CS-PDB-MIRROR\\TWSQL"
    db_name <- "Store"
  } else {
    stop("`db` must equal c('Apex', 'Apex_MerchSolutions', 'Store', 'StoreLayout') in call to `mssql_db_connect`")
  }

  res <- DBI::dbConnect(
    odbc::odbc(),
    Driver = db_driver,
    Server = db_server,
    Database = db_name,
    trusted_connection = 'yes',
    encoding = "latin1"
  )

  return(res)

}


#' Returns Primary Key Constraints for PSQL DB
#'
#' @param db character vector
#' @param schema character vector
#' @param tables character vector
#'
#' @return data.frame
#'
pk_psql <- function(db, schema, tables) {

  if (missing(db)) {stop("`db` is missing in call to `pk_psql`", call. = FALSE)}
  if (missing(schema)) {schema <- NULL}
  if (missing(tables)) {tables <- NULL}

  expect_scalar_char(obj = db)
  conn <- psql_db_connect(db)

  qry <- readr::read_file(system.file('sql/primary_key/pk_psql.sql', package='dbTools'))
  qry <- glue::glue_sql(qry, .con = conn)

  if (!isTRUE(is.null(schema))) {
    expect_data_type(obj = schema, type = 'character', nz_len = TRUE)
    qry <- paste(qry, glue::glue_sql("AND tc.table_schema IN ({schema*})", .con = conn), sep = '\n')
  }

  if (!isTRUE(is.null(tables))) {
    expect_data_type(obj = tables, type = 'character', nz_len = TRUE)
    qry <- paste(qry, glue::glue_sql("AND tc.table_name IN ({tables*})", .con = conn), sep = '\n')
  }

  qry <- glue::glue_sql(qry, .con = conn)
  res <- DBI::dbGetQuery(conn, qry)

  DBI::dbDisconnect(conn)
  rm(conn)

  return(res)

}

#' Returns Primary Key Constraints for MSSQL DB
#'
#' @param db character vector
#' @param schema character vector
#'
#' @return data.frame
#'
pk_mssql <- function(db, schema) {

  if (missing(db)) {stop("`db` is missing in call to `pk_mssql`", call. = FALSE)}
  if (missing(schema)) {schema <- 'dbo'}

  expect_scalar_char(db)
  expect_scalar_char(schema)
  conn <- mssql_db_connect(db)

  qry <- readr::read_file(system.file('sql/primary_key/pk_mssql.sql', package='dbTools'))
  db_sql <- DBI::dbQuoteIdentifier(conn, db)
  qry <- glue::glue_sql(qry, .con = conn)

  qry <- glue::glue_sql(qry, .con = conn)
  res <- DBI::dbGetQuery(conn, qry)

  DBI::dbDisconnect(conn)
  rm(conn)

  return(res)

}

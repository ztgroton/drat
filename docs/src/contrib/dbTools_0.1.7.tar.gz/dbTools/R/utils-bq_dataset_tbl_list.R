
#' List tables contained in a BigQuery dataset
#'
#' @param dataset character - Name of BigQuery dataset
#'
#' @return character - vector of table names
#' @export
#'
bq_dataset_tbl_list <- function(dataset) {

  # Validate Inputs
  if (missing(dataset)) {stop("`dataset` is missing in call to `bq_dataset_tbl_list`")}

  # Validate Input Expectations
  dbTools::expect_scalar_char(dataset)

  # List Tables
  tbl_list <- bigrquery::bq_dataset_tables(
    bigrquery::bq_dataset(
      project = "twm-edap-prod-1802",
      dataset = dataset
    )
  )

  # Return Table List
  return(tbl_list)

}

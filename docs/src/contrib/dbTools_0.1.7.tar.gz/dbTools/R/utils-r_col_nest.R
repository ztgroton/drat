
#' Group Row Numbers of a Data Frame by Columns
#'
#' @param x data.frame - The data.frame containing data to be nested.
#' @param group character - Vector of column names to 'group by'. If vector has names, grouping columns will be renamed accordingly.
#'
#' @return data.frame
#' @export
#'
r_col_nest <- function(x, group) {

  # Validate Inputs
  if (missing(x)) {stop("`x` is missing in call to `r_col_nest`", call. = FALSE)}
  if (!isTRUE(is.data.frame(x))) {stop("`x` must be `data.frame` in call to `r_col_nest`", call. = FALSE)}

  if (missing(group)) {stop("`group` is missing in call to `r_col_nest`", call. = FALSE)}
  if (!isTRUE(all(group %in% colnames(x)))) {
    stop("`group` must be subset of `colnames(x)` in call to `r_col_nest`", call. = FALSE)
  }

  # # Get `names(group)`
  # group_names <- attr(group, 'names')
  # group_is_named <- !isTRUE(is.null(group_names))
  #
  # # Conditionally check `names(group)`
  # if (isTRUE(group_is_named)) {
  #
  #   if (!isTRUE(is.character(group_names))) {
  #     stop("`group_names` must be `character` in call to `r_col_nest`", call. = FALSE)
  #   }
  #
  #   any_na <- isTRUE(any(purrr::map_lgl(group_names, ~ isTRUE(is.na(.)))))
  #   if (isTRUE(any_na)) {
  #     stop("`group_names` cannot contain NA values in call to `r_col_nest`", call. = FALSE)
  #   }
  #
  #   any_null <- isTRUE(any(purrr::map_lgl(group_names, ~ isTRUE(is.null(.)))))
  #   if (isTRUE(any_null)) {
  #     stop("`group_names` cannot contain NULL values in call to `r_col_nest`", call. = FALSE)
  #   }
  #
  #   any_empty <- isTRUE(any(purrr::map_lgl(group_names, ~ isTRUE(nchar(.) == 0))))
  #   if (isTRUE(any_empty)) {
  #     stop("`group_names` cannot contain empty '' values in call to `r_col_nest`", call. = FALSE)
  #   }
  #
  # }

  # Select columns using `group`
  x <- x [, c(group), drop = F]

  # # Conditionally rename `group` columns using `names(group)`
  # if (isTRUE(group_is_named)) {
  #   for (i in 1:length(group)) {
  #     names(x)[names(x) == group[i]] <- names(group)[i]
  #   }
  # }

  # Save `colnames(x)` as `group_by_cols` for later use
  group_by_cols <- colnames(x)

  # Generate Row Numbers
  unq_rownum_name <- unq_colname(x, 'row_num')
  x[, c(unq_rownum_name)] <- 1:nrow(x)

  # Nest Row Numbers
  x <- x %>%
    dplyr::group_by_at(group_by_cols) %>%
    dplyr::group_nest(.key = 'nest_row_num') %>%
    dplyr::ungroup() %>%
    dplyr::mutate(nest_row_cnt = purrr::map_dbl(.data$nest_row_num, function(x){ifelse(is.null(x), 0, nrow(x))}))

  # Return
  return(x)

}

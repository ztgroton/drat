
#' Clear all existing schema from 'db_projects' Database
#'
#' @export
#'
clear_db_projects <- function() {

  # Open PSQL Connection
  psql_conn <- psql_db_connect('db_projects')

  # Get List of Existing Schema
  psql_schema <- get_schema(psql_conn) %>%
    dplyr::pull(.data$schema) %>%
    setdiff(c('public'))

  # Drop Existing Schema
  purrr::walk(psql_schema, function(x) {
    qry <- glue::glue_sql("DROP SCHEMA {`x`} CASCADE", .con = psql_conn)
    DBI::dbExecute(psql_conn, qry)
  })

  # Close PSQL Connection
  DBI::dbDisconnect(psql_conn)
  rm(psql_conn)

  # Return Success
  invisible(TRUE)

}

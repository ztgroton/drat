
#' Connect to Microsoft MSSQL Database
#'
#' @param db character - Name of an existing database
#'
#' @return DBIConnection - R Object handle for the newly opened connection
#' @export
#'
bqsql_db_connect <- function(db) {

  if (missing(db)) {stop("`db` is missing in call to `bqsql_db_connect`", call. = FALSE)}

  res <- DBI::dbConnect(
    bigrquery::bigquery(),
    dataset = db,
    project = 'twm-edap-prod-1802',
    billing = 'twm-edap-prod-1802'
  )

  return(res)

}

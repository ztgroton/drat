
#' Build Integer Partitions
#'
#' @param n numeric
#'
#' @return list
#' @export
#'
#' @examples
#' \dontrun{
#' output <- build_integer2_part(3)
#' }
build_integer2_part <- function(n) {

  stopifnot(is.numeric(n) && (n %% 1) == 0 && n > 0)

  # 1) Calculate Integer Partitions for 'n'
  part_list <- as.list(as.data.frame(as.matrix(partitions::parts(n))))

  # 1) Remove Zeros from partitions
  # 2) Append one zero to result of 'Step 1' if length == 1
  # All Non-Null elements will be vectors of length 2
  part_list2 <- purrr::map(
    part_list,
    function(x) {
      x <- x[x != 0]
      if (length(x) == 1) {x <- c(x,0)}
      if (length(x) == 2) {return(x)}
    }
  )

  # 1) Discard NULL elements from 'part_list2'
  # 2) Discard 'names' from 'part_list2'
  part_list2 <- purrr::discard(part_list2, is.null)
  names(part_list2) <- NULL

  # 1) Create copy of 'part_list2' with all elements reversed
  part_list3 <- purrr::map(part_list2, function(x) {x <- rev(x)})

  # 1) Discard NULL elements from 'part_list3'
  # 2) Discard 'names' from 'part_list3'
  part_list3 <- purrr::discard(part_list3, is.null)
  names(part_list3) <- NULL

  # 1) Combine Unique Values of 'part_list2' and 'part_list3'
  part_list23 <- unique(c(part_list2, part_list3))

  return(purrr::discard(part_list23, is.null))

}


#' Build Digit Padding
#'
#' @param n numeric
#'
#' @return data.frame
#' @export
#'
#' @examples
#' \dontrun{
#' output <- build_digit_padding(3)
#' }
build_digit_padding <- function(n) {

  stopifnot(is.numeric(n) && (n %% 1) == 0 && n >= 0)

  # If 'n == 0', only possible padding is empty string
  if (n == 0) {return("")}

  # 1) Build character vector of raw numbers to use as padding
  # 2) Calculate string length of each character number
  raw_digits <- as.character(c(0:(10^n - 1)))
  digit_len <- stringr::str_length(raw_digits)

  # Combine 'raw_digits' and 'digit_len' into single data.frame
  padded_result <- data.frame(
    raw_digits = raw_digits,
    digit_len = digit_len,
    stringsAsFactors = FALSE
  )

  # Pad 'raw_digits' on the left with string of zeros to make all 'padded_string' have string length 'n'
  padded_result <- padded_result %>%
    dplyr::mutate(
      padded_string = purrr::map2_chr(
        raw_digits, digit_len,

        function(raw_digits, digit_len) {
          if (stringr::str_length(raw_digits) < n) {
            paste0(paste0(rep('0', n - stringr::str_length(raw_digits)), collapse = ''), raw_digits)
          }
          else {raw_digits}
        }

      )
    )

  return(padded_result$padded_string)

}


#' Export UPC Matches to XLSX
#'
#' @param x list
#' @param export_path character
#'
#' @return list
#' @export
#'
#' @examples
#' \dontrun{
#' output_x <- export_upc_matches(input_x, './EXPORT/FOLDER/PATH/HERE')
#' }
export_upc_matches <- function(x, export_path) {

  # Validate Input
  if (missing(x)) {stop("`x` is missing in call to `export_upc_matches`")}
  if (missing(export_path)) {export_path <- NULL}

  if (!isTRUE(is.list(x))) {stop("`x` must be a list in call to `export_upc_matches`")}

  if (!isTRUE(is.null(export_path))) {
    # Export to Excel
    timestamp <- gsub(' ', '_', Sys.time())
    timestamp <- gsub(':', '_', timestamp)
    timestamp <- gsub('-', '_', timestamp)

    file_name <- gsub(' ', '_', paste0("UPC_MATCHES_", timestamp, ".xlsx"))
    file_path <- file.path(export_path, file_name)

    sheets <- x
    writexl::write_xlsx(sheets, file_path)
  }

  # Return Input
  invisible(x)

}

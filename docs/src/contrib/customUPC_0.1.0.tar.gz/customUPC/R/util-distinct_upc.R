
#' Remove Duplicate UPC Values
#'
#' @importFrom rlang .data
#'
#' @param split_upc S3 Object - 'splitUpc'
#'
#' @return data.frame
#' @export
#'
#' @examples
#' \dontrun{
#' output <- distinct_upc(split_upc = df)
#' }
distinct_upc <- function(split_upc) {

  if (missing(split_upc)) {
    stop("`split_upc` is missing in call to `distinct_upc`", call. = FALSE)
  }

  if (!isTRUE(inherits(split_upc, 'splitUpc'))) {
    stop("`split_upc` DOES NOT inherit from 'splitUpc' in call to `distinct_upc`")
  }

  results <- split_upc$split_df %>%
    dplyr::rename(upc = .data$split_upc) %>%
    dplyr::distinct(.data$upc)

  return(results)

}

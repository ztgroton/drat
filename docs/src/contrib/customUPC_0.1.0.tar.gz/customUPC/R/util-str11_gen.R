
#' Generate Strings of Length 11
#'
#' @importFrom rlang .data
#'
#' @param df data.frame
#'
#' @return data.frame
#' @export
#'
#' @examples
#' \dontrun{
#' output <- str11_gen(data)
#' }
str11_gen <- function(df) {

  # Validate Inputs
  stopifnot(is.data.frame(df))
  stopifnot(c('upc') %in% colnames(df))

  df <- df %>%
    dplyr::mutate(upc_str_length = stringr::str_length(.data$upc))

  # Distinct String Lengths >= 11
  upc_str_lengths <- df %>%
    dplyr::pull(.data$upc_str_length) %>% unique()

  upc_str_lengths <- sort(upc_str_lengths[upc_str_lengths >= 11])

  # Generate list of data frames for each length
  res <- lapply(upc_str_lengths, function(l){

    # Compute str_length - 11
    offset <- l - 11

    # Initialize temp result frame
    tmp <- df %>%
      dplyr::filter(.data$upc_str_length == l) %>%
      dplyr::select(.data$upc, .data$upc_str_length) %>%
      dplyr::distinct()

    i <- 0
    while (i <= offset) {

      tmp[[paste0('upc_offset', i)]] <- tmp[[c('upc')]] %>%
        as.character() %>% stringr::str_sub(1 + i, 11 + i)

      i <- i + 1

    }

    tmp %>% tidyr::gather("offset", "upc_value", -.data$upc, -.data$upc_str_length)

  })

  # Bind result data frames into single data frame
  res <- res %>% data.table::rbindlist()

}

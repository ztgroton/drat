
#' Execute Custom UPC Mapping Logic on DataFrame
#'
#' @importFrom rlang .data
#'
#' @param df data.frame - Raw Data
#' @param upc_col character - Name of column containing UPCs
#' @param upc_lib data.frame - EDAP UPC Mappings
#' @param all_rank logical - Optionally specify whether ALL matches are returned or ONLY BEST matches
#'
#' @return data.frame
#' @export
#'
#' @examples
#' \dontrun{
#' best_upc_matches <- custom_upc_map(df = RDS_DATA, upc_col = 'UPC_COLUMN', upc_lib = edap_upc)
#' best_upc_matches <- custom_upc_map(df = RDS_DATA, upc_col = 'UPC_COLUMN', upc_lib = edap_upc, all_rank = FALSE)
#' all_upc_matches <- custom_upc_map(df = RDS_DATA, upc_col = 'UPC_COLUMN', upc_lib = edap_upc, all_rank = TRUE)
#' }
custom_upc_map <- function(df, upc_col, upc_lib = 'split_upc', all_rank = FALSE) {

  stopifnot(isTRUE(upc_col %in% colnames(df)))

  #Pull Required Fields from 'upc_lib'
  upc_lib <- upc_lib %>%
    dplyr::select(
      .data$upc, .data$item_code, .data$position_key,
      .data$item_name, .data$brand_name, .data$package_type
    ) %>%
    dplyr::distinct()

  upc_lib_trim <- upc_lib %>%
    dplyr::select(.data$upc, .data$item_code, .data$position_key) %>%
    dplyr::distinct()

  #Compute 'upc_record_id' column for tracking individual records
  #df <- df %>% mutate(comp_upc_record_id = record_id)
  df <- df[, c(upc_col), drop = FALSE] %>%
    dplyr::distinct() %>%
    dplyr::rename(upc = !!upc_col) %>%
    dplyr::mutate(comp_upc_record_id = dplyr::row_number())

  #1) Try Exact Matches (Exact UPC) ----
  exact_upc <- df %>%
    dplyr::inner_join(upc_lib_trim, by = 'upc') %>%
    dplyr::mutate(upc_match_type = 'Exact (1)') %>%
    dplyr::mutate(upc_match_rank = 1) %>%
    dplyr::distinct()

  print(paste0("exact_upc - ", nrow(exact_upc)))
  #View(exact_upc)

  #Initialize Unmapped Records
  unmapped_comp_upc_record_id <- df %>%
    dplyr::anti_join(upc_lib_trim, by = 'upc') %>%
    dplyr::pull(.data$comp_upc_record_id) %>% unique()

  #2) Try Removing the Last Digit from Comp UPC (UPC Trailing Digit) ----
  upc_trailing <- df %>%
    dplyr::filter(.data$comp_upc_record_id %in% unmapped_comp_upc_record_id) %>%
    dplyr::mutate(upc_trailing = purrr::map_chr(.data$upc, stringr::str_sub, start = 1, end = -2)) %>%
    dplyr::inner_join(upc_lib_trim, by = c('upc_trailing' = 'upc')) %>%
    dplyr::mutate(upc_match_type = 'Remove Trailing Digit (2)') %>%
    dplyr::mutate(upc_match_rank = 2) %>%
    dplyr::distinct()

  print(paste0("upc_trailing - ", nrow(upc_trailing)))
  #View(upc_trailing)

  #Update Unmapped Records
  unmapped_comp_upc_record_id <- c(
    unmapped_comp_upc_record_id
    , upc_trailing %>%
      dplyr::anti_join(upc_lib_trim, by = c('upc_trailing' = 'upc')) %>%
      dplyr::pull(.data$comp_upc_record_id) %>% unique()
  ) %>% unique()

  #3) Try Removing the Last Digit and Leading Zeros from Comp UPC (UPC Leading Zeros & Trailing Digit) ----
  upc_lead0_trailing <- df %>%
    dplyr::filter(.data$comp_upc_record_id %in% unmapped_comp_upc_record_id) %>%
    dplyr::mutate(upc_lead0_trailing = purrr::map_chr(sub("^0+", "", .data$upc), stringr::str_sub, start = 1, end = -2)) %>%
    dplyr::inner_join(upc_lib_trim, by = c('upc_lead0_trailing' = 'upc')) %>%
    dplyr::mutate(upc_match_type = 'Remove Leading Zeros and Trailing Digit (3)') %>%
    dplyr::mutate(upc_match_rank = 3) %>%
    dplyr::distinct()

  print(paste0("upc_lead0_trailing - ", nrow(upc_lead0_trailing)))
  #View(upc_lead0_trailing)

  #Update Unmapped Records
  unmapped_comp_upc_record_id <- c(
    unmapped_comp_upc_record_id
    , upc_lead0_trailing %>%
      dplyr::anti_join(upc_lib_trim, by = c('upc_lead0_trailing' = 'upc')) %>%
      dplyr::pull(.data$comp_upc_record_id) %>% unique()
  ) %>% unique()

  #4) Try Removing Leading Zeros from Comp UPC (UPC Leading Zero) ----
  upc_lead0 <- df %>%
    dplyr::filter(.data$comp_upc_record_id %in% unmapped_comp_upc_record_id) %>%
    dplyr::mutate(upc_lead0 = sub("^0+", "", .data$upc)) %>%
    dplyr::inner_join(upc_lib_trim, by = c('upc_lead0' = 'upc')) %>%
    dplyr::mutate(upc_match_type = 'Remove Leading Zeros Only (4)') %>%
    dplyr::mutate(upc_match_rank = 4) %>%
    dplyr::distinct()

  print(paste0("upc_lead0 - ", nrow(upc_lead0)))
  #View(upc_lead0)

  #Update Unmapped Records
  unmapped_comp_upc_record_id <- c(
    unmapped_comp_upc_record_id
    , upc_lead0 %>%
      dplyr::anti_join(upc_lib_trim, by = c('upc_lead0' = 'upc')) %>%
      dplyr::pull(.data$comp_upc_record_id) %>% unique()
  ) %>% unique()

  #5) Try Removing Leading Zeros and First Non-Zero Digit from Comp UPC (UPC Leading Zeros and First Digit) ----
  upc_lead0_first <- df %>%
    dplyr::filter(.data$comp_upc_record_id %in% unmapped_comp_upc_record_id) %>%
    dplyr::mutate(upc_lead0_first = purrr::map_chr(sub("^0+", "", .data$upc), stringr::str_sub, start = 2)) %>%
    dplyr::inner_join(upc_lib_trim, by = c('upc_lead0_first' = 'upc')) %>%
    dplyr::mutate(upc_match_type = 'Remove Leading Zeros and First Digit (5)') %>%
    dplyr::mutate(upc_match_rank = 5) %>%
    dplyr::distinct()

  print(paste0("upc_lead0_first - ", nrow(upc_lead0_first)))
  #View(upc_lead0_first)

  #Update Unmapped Records
  unmapped_comp_upc_record_id <- c(
    unmapped_comp_upc_record_id
    , upc_lead0_first %>%
      dplyr::anti_join(upc_lib_trim, by = c('upc_lead0_first' = 'upc')) %>%
      dplyr::pull(.data$comp_upc_record_id) %>% unique()
  ) %>% unique()

  #6) Search for Common Substrings of Length 11

  #6.1)
  df_unmapped <- df %>%
    dplyr::filter(.data$comp_upc_record_id %in% unmapped_comp_upc_record_id) %>%
    dplyr::select(.data$comp_upc_record_id, .data$upc)

  #6.2)
  df_unmapped_str11 <- df_unmapped %>%
    str11_gen() %>% dplyr::select(-.data$upc_str_length) %>%
    dplyr::rename(unmapped_upc = .data$upc) %>%
    dplyr::rename(unmapped_offset = .data$offset)

  #6.3)
  edap_upc_str11 <- upc_lib %>%
    str11_gen() %>% dplyr::select(-.data$upc_str_length) %>%
    dplyr::rename(edap_upc = .data$upc) %>%
    dplyr::rename(edap_offset = .data$offset)

  #6.4)
  str11_matches <- df_unmapped_str11 %>%
    dplyr::inner_join(edap_upc_str11 , by = 'upc_value')

  #6.5)
  upc_str11 <- df_unmapped %>%
    dplyr::inner_join(
      str11_matches %>%
        dplyr::select(.data$unmapped_upc, .data$edap_upc) %>%
        dplyr::distinct()
      , by = c('upc' = 'unmapped_upc')
    ) %>%
    dplyr::inner_join(
      upc_lib %>%
        dplyr::select(.data$upc, .data$item_code, .data$position_key) %>%
        dplyr::distinct()
      , by = c('edap_upc' = 'upc')
    ) %>%
    dplyr::mutate(
      upc_match_type = 'Length 11 Substring',
      upc_match_rank = 6
    ) %>%
    dplyr::distinct()

  #Update Unmapped Records
  unmapped_comp_upc_record_id <- c(
    unmapped_comp_upc_record_id
    , upc_str11 %>%
      dplyr::anti_join(upc_lib_trim, by = c('edap_upc' = 'upc')) %>%
      dplyr::pull(.data$comp_upc_record_id) %>% unique()
  ) %>% unique()

  print(paste0("upc_str11 - ", nrow(upc_str11)))

  #7) Search for Common Substrings of Length 10

  #7.1)
  df_unmapped <- df %>%
    dplyr::filter(.data$comp_upc_record_id %in% unmapped_comp_upc_record_id) %>%
    dplyr::select(.data$comp_upc_record_id, .data$upc)

  #7.2)
  df_unmapped_str10 <- df_unmapped %>%
    str10_gen() %>% dplyr::select(-.data$upc_str_length) %>%
    dplyr::rename(unmapped_upc = .data$upc) %>%
    dplyr::rename(unmapped_offset = .data$offset)

  #7.3)
  edap_upc_str10 <- upc_lib %>%
    str10_gen() %>% dplyr::select(-.data$upc_str_length) %>%
    dplyr::rename(edap_upc = .data$upc) %>%
    dplyr::rename(edap_offset = .data$offset)

  #7.4)
  str10_matches <- df_unmapped_str10 %>%
    dplyr::inner_join(edap_upc_str10 , by = 'upc_value')

  #7.5)
  upc_str10 <- df_unmapped %>%
    dplyr::inner_join(
      str10_matches %>%
        dplyr::select(.data$unmapped_upc, .data$edap_upc) %>%
        dplyr::distinct()
      , by = c('upc' = 'unmapped_upc')
    ) %>%
    dplyr::inner_join(
      upc_lib %>%
        dplyr::select(.data$upc, .data$item_code, .data$position_key) %>%
        dplyr::distinct()
      , by = c('edap_upc' = 'upc')
    ) %>%
    dplyr::mutate(
      upc_match_type = 'Length 10 Substring',
      upc_match_rank = 7
    ) %>%
    dplyr::distinct()

  #Update Unmapped Records
  unmapped_comp_upc_record_id <- c(
    unmapped_comp_upc_record_id
    , upc_str10 %>%
      dplyr::anti_join(upc_lib_trim, by = c('edap_upc' = 'upc')) %>%
      dplyr::pull(.data$comp_upc_record_id) %>% unique()
  ) %>% unique()

  print(paste0("upc_str10 - ", nrow(upc_str10)))

  #Combine All UPC Matches
  upc_matches_final <- dplyr::bind_rows(
    exact_upc %>%
      dplyr::select(.data$comp_upc_record_id, .data$upc_match_type, .data$upc_match_rank, .data$item_code, .data$position_key),
    upc_trailing %>%
      dplyr::select(.data$comp_upc_record_id, .data$upc_match_type, .data$upc_match_rank, .data$item_code, .data$position_key),
    upc_lead0_trailing %>%
      dplyr::select(.data$comp_upc_record_id, .data$upc_match_type, .data$upc_match_rank, .data$item_code, .data$position_key),
    upc_lead0 %>%
      dplyr::select(.data$comp_upc_record_id, .data$upc_match_type, .data$upc_match_rank, .data$item_code, .data$position_key),
    upc_lead0_first %>%
      dplyr::select(.data$comp_upc_record_id, .data$upc_match_type, .data$upc_match_rank, .data$item_code, .data$position_key),
    upc_str11 %>%
      dplyr::select(.data$comp_upc_record_id, .data$upc_match_type, .data$upc_match_rank, .data$item_code, .data$position_key)#,
    #upc_str10 %>% select(comp_upc_record_id, upc_match_type, upc_match_rank, item_code, position_key)
    #upc_pad1 %>% select(comp_upc_record_id, upc_match_type, upc_match_rank, item_code, position_key)
  )

  upc_matches_final <- upc_matches_final %>%
    dplyr::distinct() %>%
    dplyr::arrange(.data$comp_upc_record_id, .data$upc_match_rank) %>%
    dplyr::group_by(.data$comp_upc_record_id) %>%
    dplyr::mutate(comp_upc_match_rank = dplyr::row_number()) %>%
    dplyr::ungroup()

  if (isFALSE(all_rank)) {
    upc_matches_final <- upc_matches_final %>%
      dplyr::filter(.data$comp_upc_match_rank == 1)
  }

  #Recombine 'upc' to final output
  upc_matches_final <- upc_matches_final %>%
    dplyr::left_join(
      df %>% dplyr::select(.data$comp_upc_record_id, .data$upc)
      , by = c('comp_upc_record_id')
    )

  return(upc_matches_final)

}

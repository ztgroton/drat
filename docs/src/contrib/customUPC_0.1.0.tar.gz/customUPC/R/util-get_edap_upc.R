
#' Query UPC-to-Item Mappings from Google BigQuery 'EDAP - edw'
#'
#' @return data.frame
#' @export
#'
#' @examples
#' \dontrun{
#' output <- get_edap_upc()
#' }
get_edap_upc <- function() {

  # Setup DB Connection
  conn_edw <- dbTools::gsql_db_connect('edw')

  # Fetch SQL Query
  qry <- readr::read_file(system.file('sql/edw/dql/edap_upc.sql', package = 'customUPC'))

  # Execute Query / Fetch Results
  results <- DBI::dbGetQuery(conn_edw, qry)

  # Close DB Connection
  DBI::dbDisconnect(conn_edw)
  rm(conn_edw)

  # Return Results
  return(results)

}


#' Split Strings of UPCs separated by delimiter
#'
#' @importFrom rlang .data
#'
#' @param df data.frame - Raw Data
#' @param upc_col character - Name of column containing UPCs
#' @param split character - delimiter value used to split values in 'upc_col'
#'
#' @return R Object
#' @export
#'
#' @examples
#' \dontrun{
#' output <- split_upc(df = data, upc_col = 'UPC', split = ',')
#' }
split_upc <- function(df, upc_col, split = ',') {

  stopifnot(isTRUE(is.data.frame(df)))
  stopifnot(isTRUE(upc_col %in% colnames(df)))
  stopifnot(is.character(split))

  df <- df %>%
    dplyr::mutate(raw_row_number = dplyr::row_number())

  split_df <- df %>%
    dplyr::select(dplyr::all_of(c('raw_row_number', upc_col))) %>%
    dplyr::rename(raw_upc = !!upc_col) %>%
    dplyr::mutate(split_upc = stringr::str_split_fixed(trimws(.data$raw_upc), split, Inf)) %>%
    dplyr::select(.data$raw_row_number, .data$raw_upc, .data$split_upc)

  result <- list(raw_df = df, split_df = split_df)
  class(result) <- append('splitUpc', class(result))

  return(result)

}

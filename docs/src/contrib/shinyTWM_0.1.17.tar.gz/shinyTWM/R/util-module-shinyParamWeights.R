#' Validate Input Format to R Shiny Module 'shinyParamWeights'
#'
#' @param x list
#'
#' @return list
#' @export
#'
#' @examples
#' \dontrun{
#' output <- validate_param_weight_choices(x)
#' }
validate_param_weight_choices <- function(x) {

  # Validate Inputs
  if (missing(x)) {stop("`x` is missing in call to `validate_param_weight_choices`")}

  # Validate Input Expectations

  # * `x` ----
  if (!isTRUE(is.list(x)) || !isTRUE(length(x) > 0)) {
    message("`x` must be non-empty list in call to `validate_param_weight_choices`")
    return(FALSE)
  }

  # * length(x) ----
  if (!isTRUE(length(x) %in% c(1,2,3,4))) {
    message("`length(x)` must be between 1 and 4 in call to `validate_param_weight_choices`")
    return(FALSE)
  }

  # ** x_elem ----
  x_elem_invalid <- purrr::map_lgl(x, function(t) {!isTRUE(is.list(t)) || !isTRUE(length(t) > 0)})
  if (isTRUE(any(x_elem_invalid))) {
    message("`x` must only contain elements that are non-empty lists in call to `validate_param_weight_choices`")
    return(FALSE)
  }

  # ** x_elem_names ----
  x_elem_names <- purrr::map(x, function(t){names(t)})

  x_elem_names_invalid <- purrr::map_lgl(x_elem_names, function(t){
    !isTRUE(is.character(t)) || !isTRUE(length(t) > 0) || isTRUE(any(is.na(t))) ||
      isTRUE(any(is.null(t))) || isTRUE(any(gsub(" ", "", t, fixed = TRUE) == ""))
  })

  if (isTRUE(any(x_elem_names_invalid))) {
    message("`x` must only contain lists with valid `names` in call to `validate_param_weight_choices`")
    return(FALSE)
  }

  # ** x_elem_values ----
  x_elem_values <- purrr::map_lgl(x, function(t) {

    purrr::map_lgl(t, function(z) {

      z_is_list <- isTRUE(is.list(z))
      z_names_valid <- isTRUE(identical(sort(c('multiple', 'choices', 'label')), sort(names(z))))
      z_multiple_valid <- isTRUE(identical(z[['multiple']], TRUE)) || isTRUE(identical(z[['multiple']], FALSE))
      z_choices_valid <- isTRUE(is.character(z[['choices']]))
      z_label_valid <- isTRUE(is.character(z[['label']])) && isTRUE(length(z[['label']]) > 0) && !isTRUE(is.na(z[['label']]))

      if (!isTRUE(all(z_is_list, z_names_valid, z_multiple_valid, z_choices_valid, z_label_valid))) {
        message("`x` must only contain lists with valid values in call to `validate_param_weight_choices`")
        return(FALSE)
      } else {
        return(TRUE)
      }

    }) %>% all()

  })

  if (!isTRUE(all(x_elem_values))) {
    message("`x` must only contain lists whose elements are character vectors in call to `validate_param_weight_choices`")
    invisible(FALSE)
  }

  # Return Input
  invisible(x)

}

#' Generate UI Outputs for R Shiny Module 'shinyParamWeights'
#'
#' @param x list
#' @param validate TRUE/FALSE
#'
#' @return R Shiny Tags
#' @export
#'
#' @examples
#' \dontrun{
#' output <- validate_param_weight_choices(x)
#' }
generate_param_weight <- function(x, validate = FALSE) {

  # Validate Inputs
  if (missing(x)) {stop("`x` is missing in call to `validate_param_weight_choices`")}
  if (missing(validate)) {validate <- FALSE}

  # Validate Input Expectations

  # * `validate` ----
  if (!isTRUE(identical(validate, TRUE)) && !isTRUE(identical(validate, FALSE))) {
    stop("`validate` must be TRUE/FALSE in call to `validate_param_weight_choices`")
  }

  # * `x` ----
  if (isTRUE(validate)) {x <- validate_param_weight_choices(x)}

  # MAIN LOGIC ----

  tag_list_input <- purrr::map(x, function(choiceColumn) {

    shiny::column(
      width = 12/length(x),
      do.call(
        what = shiny::verticalLayout,
        args = purrr::map(names(choiceColumn), function(choice_name) {

          elem <- choiceColumn[[choice_name]]

          shiny::numericInput(
            inputId = choice_name,
            label = elem[['label']],
            value = elem[['value']],
            width = '100%'
          )

        })
      )
    )

  })

  return(do.call(tagList, tag_list_input))

}

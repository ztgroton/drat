
#' shinyTableFilter_ui
#'
#' @param id character - A non-na, length 1 character vector
#'
#' @importFrom shiny tags
#'
#' @return fluidPage - UI for Shiny Module 'shinyTableFilter'
#' @export
shinyTableFilter_ui <- function(id) {

  ns <- NS(id)
  tagList(shiny::uiOutput(ns('shiny_table_ui')))

}

#' shinyTableFilter_server
#'
#' @param id character - A non-na, length 1 character vector
#' @param data data.frame - A valid data.frame object to display as table.
#'
#' @importFrom rlang .data
#' @importFrom utils write.csv
#'
#' @return moduleServer - SERVER for Shiny Module 'shinyTableFilter'
#' @export
shinyTableFilter_server <- function(id, data) {

  moduleServer(id, function(input, output, session){

    # Session Namespace ----
    ns <- session$ns

    # _____________________________ ----
    # INPUT REACTIVE EXPRESSIONS ----

    # * input_data() ----
    input_data <- shiny::reactive({

      shiny::req(data())

      if (!isTRUE(is.data.frame(data()))) {
        shinyWidgets::show_toast(
          title = "Invalid Data Frame!!!",
          type = "error",
          position = "bottom"
        )
      }
      else {
        return(data())
      }

    })

    # _______________________________ ----
    # MODULE REACTIVE EXPRESSIONS ----

    # * input_columns() ----
    input_columns <- shiny::reactive({

      shiny::req(input_data())

      # Return `colnames(input_data())`
      return(colnames(input_data()))

    })

    # * input_column_types() ----
    input_column_types <- shiny::reactive({

      shiny::req(input_data())
      shiny::req(input_columns())

      # Get Data Types for each Column
      types <- purrr::map_chr(input_data(), function(t){class(t)[1]})
      names(types) <- colnames(input_data())

      # Return Data Types
      return(types)

    })

    # ___________________ ----
    # OBSERVER EVENTS ----

    # ________ ----
    # OUTPUTS ----

    # * output$shiny_table_ui ----
    output$shiny_table_ui <- shiny::renderUI({

      shiny::tagList(

        # Summarise Applied Filters
        shiny::actionButton(
          inputId = ns('clause_summary_btn'),
          label = 'clause_summary_label()',
          width = '100%'
        ),

        # Select Columns to Filter By
        shinyWidgets::pickerInput(
          inputId = ns('clause_column_selection'),
          label = "Filter by:",
          multiple = FALSE,
          choices = input_columns(),
          selected = input_columns()
        )

      )

    })

    # ______________________ ----
    # MODULE RETURN VALUE ----
    result <- shiny::reactive({

      TRUE

    })

    return(result)

    # _______________________ ----
    # END OF MODULE SERVER ----

  })

}


#' Display R DataFrame in R Shiny Table Filter
#'
#' @importFrom utils read.csv
#'
#' @param data data.frame
#' @param ... ellipsis
#'
#' @export
#'
#' @examples
#' \dontrun{
#' shinyTableFilter(raw_data)
#' }
shinyTableFilter <- function(data, ...) {

  # Validate Input
  if (missing(data)) {data <- read.csv(system.file("sample_data/RDS_Sample.csv", package = 'shinyTWM'))}

  # Validate Input Expectations
  if (!isTRUE(is.data.frame(data))) {
    stop("`data` must be 'data.frame' in call to `shinyTableFilter`")
  }

  # * `ui`
  ui <- shiny::tagList(
    shiny::column(
      width = 12,
      shinyTableFilter_ui('shinytablefilter1')
    )
  )

  # * `server`
  server <- function(input, output, session) {

    raw_data <- shiny::reactive({data})
    raw_colnames <- shiny::reactive({colnames(data)})

    selected_rows <- shinyTableFilter_server(
      id = 'shinytablefilter1',
      data = raw_data
    )

    #shiny::observe({print(selected_rows())})

  }

  shiny::shinyApp(ui, server, ...)

}


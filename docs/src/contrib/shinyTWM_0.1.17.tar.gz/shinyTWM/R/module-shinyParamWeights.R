
#' shinyParamWeights_ui
#'
#' @param id character - A non-na, length 1 character vector
#'
#' @return R Shiny Tags
#' @export
#'
#' @examples
#' \dontrun{
#' shinyParamWeights(id = 'param_store1')
#' }
shinyParamWeights_ui <- function(id) {

  ns <- NS(id)

  div(
    id = id,
    tagList(

    )
  )

}

#' shinyParamWeights_server
#'
#' @param id character - A non-na, length 1 character vector
#' @param choices list
#'
#' @return Reactive Expression
#' @export
#'
#' @examples
#' \dontrun{
#' output_values <- shinyParamWeights(id = 'param_store1')
#' }
shinyParamWeights_server <- function(id, choices) {

  moduleServer(id, function(input, output, session){

    ns <- session$ns

  })

}

#' Test and Debug R shiny Module 'shinyParamWeights'
#'
#' @importFrom utils read.csv
#'
#' @param choices list
#' @param ... ellipsis
#'
#' @export
#'
#' @examples
#' \dontrun{
#' shinyParamWeights(choices)
#' }
shinyParamWeights <- function(choices, ...) {

  # Validate Input
  if (missing(choices)) {

    choices <- list(
      list(

        test_picker1 = list(
          multiple = TRUE,
          choices = LETTERS,
          label = "TEST PICKER1"
        ),

        test_picker2 = list(
          multiple = FALSE,
          choices = LETTERS,
          label = "TEST PICKER2"
        )

      ),

      list(
        test_picker3 = list(
          multiple = TRUE,
          choices = LETTERS,
          label = "TEST PICKER3"
        )
      )

    )

  }

  # Validate Input Expectations
  if (isFALSE(validate_param_weight_choices(x = choices))) {
    stop("`choices` must be valid input in call to `shinyParamWeights`")
  }

  # * `ui`
  ui <- shiny::fluidPage(
    shiny::column(
      width = 12,
      shinyParamWeights_ui('param_weight1')
    )
  )

  # * `server`
  server <- function(input, output, session) {

    raw_choices <- shiny::reactive({choices})

    shinyParamWeights_server(
      id = 'param_weight1',
      choices = raw_choices
    )

  }

  shiny::shinyApp(ui, server, ...)

}

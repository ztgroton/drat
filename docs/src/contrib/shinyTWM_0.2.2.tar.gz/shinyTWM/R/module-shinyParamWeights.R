
#' shinyParamWeights_ui
#'
#' @param id character - A non-na, length 1 character vector
#'
#' @return R Shiny Tags
#' @export
#'
#' @examples
#' \dontrun{
#' shinyParamWeights(id = 'param_store1')
#' }
shinyParamWeights_ui <- function(id) {

  ns <- NS(id)

  div(
    id = id,
    tagList(
      shiny::uiOutput(ns('weight_ui'))
    )
  )

}

#' shinyParamWeights_server
#'
#' @param id character - A non-na, length 1 character vector
#' @param choices list
#'
#' @return Reactive Expression
#' @export
#'
#' @examples
#' \dontrun{
#' output_values <- shinyParamWeights(id = 'param_store1')
#' }
shinyParamWeights_server <- function(id, choices) {

  moduleServer(id, function(input, output, session){

    ns <- session$ns

    # _____________________________________ ----
    # MODULE INPUT REACTIVE EXPRESSIONS ----

    # * choiceData() ----
    choiceData <- shiny::reactive({

      shiny::req(choices())

      if (isFALSE(validate_param_weight_choices(choices()))) {
        shinyWidgets::show_toast(
          title = "Invalid Weight Choices!!!",
          type = "error",
          position = "bottom"
        )
      }
      else {
        return(choices())
      }

    })

    # _______________________________ ----
    # GLOBAL REACTIVE EXPRESSIONS ----

    # * choiceDataLength() ----
    choiceDataLength <- shiny::reactive({

      shiny::req(choiceData())

      if (isTRUE(length(choiceData()) > 0)) {
        return(length(choiceData()))
      } else {
        return(NULL)
      }

    })

    # ____________ ----
    # OUTPUTS ----

    # * `weight_ui` ----
    output$weight_ui <- shiny::renderUI({

      shiny::req(choiceData())
      shiny::req(choiceDataLength())

      generate_param_weight(x = choiceData(), validate = TRUE)

    })

    # __________________________________ ----
    # Reactive Expression - Weight Selections ----
    weight_selections <- shiny::reactive({

      shiny::req(choiceData())

      purrr::map(validate_param_weight_choices(choiceData()), function(choiceColumn) {

        rs <- purrr::map(names(choiceColumn), function(choice_name) {
          ifelse(is.null(input[[choice_name]]), NA, input[[choice_name]])
        })

        names(rs) <- names(choiceColumn)
        return(rs)

      })

    })

    # _____________________ ----
    # Return Weight Selections ----
    return(weight_selections)

  })

}

#' Test and Debug R shiny Module 'shinyParamWeights'
#'
#' @importFrom utils read.csv
#'
#' @param choices list
#' @param ... ellipsis
#'
#' @export
#'
#' @examples
#' \dontrun{
#' shinyParamWeights(choices)
#' }
shinyParamWeights <- function(choices, ...) {

  # Validate Input
  if (missing(choices)) {
    choices <- readRDS(system.file('sample_data/default_score_wgt.rds', package = 'shinyTWM'))
  }

  # Validate Input Expectations
  if (isFALSE(validate_param_weight_choices(x = choices))) {
    stop("`choices` must be valid input in call to `shinyParamWeights`")
  }

  # * `ui`
  ui <- shiny::fluidPage(
    shiny::column(
      width = 12,
      shinyParamWeights_ui('param_weight1')
    )
  )

  # * `server`
  server <- function(input, output, session) {

    raw_choices <- shiny::reactive({choices})

    weight_selections <- shinyParamWeights_server(
      id = 'param_weight1',
      choices = raw_choices
    )

    observe({

      shiny::req(weight_selections())
      print(weight_selections())

    })

  }

  shiny::shinyApp(ui, server, ...)

}

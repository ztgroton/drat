
-- Query Fiscal Week Key for Current Date
WITH current_week_fiscal AS
(

select distinct dd.FISCAL_WEEK_KEY

from edw.DIM_DATE dd

where dd.DATE = CURRENT_DATE()

),

-- Query all Calendar Dates in Last 52 Weeks (not including current week), using 'current_week_fiscal' WITH STATEMENT
last_52wk_fiscal AS
(

select distinct dd.DATE

from edw.DIM_DATE dd, current_week_fiscal cwf

where dd.FISCAL_WEEK_KEY BETWEEN cwf.FISCAL_WEEK_KEY - 52 AND cwf.FISCAL_WEEK_KEY - 1

),

-- Query Line-Item Transaction data from Last 52 Weeks, using 'last_52wk_fiscal' WITH STATEMENT
transaction_last_52wk AS
(

select distinct

t.BUSINESS_DATE,
t.TXN_ID,
t.TXN_LINE_ITEM,
di.ITEM_CODE,
t.CASE_SALES,
t.TOTAL_UNIT_SALES_QUANTITY as UNIT_SALES,
t.SALES_DOLLARS

from edw.FACT_TXN_LINEITEM t

inner join edw.DIM_ITEM di
on t.ITEM_SID = di.ITEM_SID

inner join last_52wk_fiscal l52w
on t.BUSINESS_DATE = l52w.DATE

),

-- Aggregate Results from 'transaction_last_52wk' WITH STATEMENT by ITEM_CODE.
item_code_r52w AS
(
select

tl52w.ITEM_CODE,
sum(tl52w.CASE_SALES) as CASE_SALES_R52WK,
sum(tl52w.SALES_DOLLARS) as UNIT_SALES_R52WK,
sum(tl52w.SALES_DOLLARS) as SALES_DOLLARS_R52WK

from transaction_last_52wk tl52w

group by tl52w.ITEM_CODE
)

select distinct

cast(u.UPC as string) as upc,
u.PRIMARY_UPC as is_primary,
cast(i.ITEM_CODE as numeric) as item_code,
cast(u.POSITION as numeric) as position_key,
cast(u.POSITION_NAME as string) as position_name,
i.BRAND_NAME as brand_name,
i.PRODUCT_NAME as item_name,
i.PACKAGE_TYPE as package_type,
cast(i.VINTAGE as string) as vintage,
cast(i.DEFINED_LABEL as string) as defined_label,
i.DEPT_NAME as department,
i.CATEGORY as category,
i.SUBCATEGORY as subcategory,
i.CLASS as class,
i.ASSORTMENT_TRAIT_NAME as assortment_trait_name,
i.ASSORTMENT_TRAIT_TYPE as assortment_trait_type,
IFNULL(r52w.CASE_SALES_R52WK, 0) as item_case_sales_r52w,
IFNULL(r52w.UNIT_SALES_R52WK, 0) as item_unit_sales_r52w,
IFNULL(r52w.SALES_DOLLARS_R52WK, 0) as item_sales_dollars_r52w

from edw.DIM_ITEM i

inner join edw.DIM_UPC u
on i.APEX_ITEM_ID = u.APEX_ITEM_ID

left join item_code_r52w r52w
on i.ITEM_CODE = r52w.ITEM_CODE

where i.current_flag = true and u.current_flag = true


CREATE OR REPLACE FUNCTION public.tcol_template(sch TEXT, tbl TEXT)
  RETURNS TEXT
  LANGUAGE PLPGSQL
AS $$
DECLARE

  col_txt TEXT[];
  result TEXT;

BEGIN

  -- Call 'public.tcol_columns'
  SELECT public.tcol_columns(sch, tbl) INTO col_txt;

  -- Convert Text Array into Comma-Separated String
  SELECT CONCAT(ARRAY_TO_STRING(col_txt, ', '), ', ') INTO result;

  -- Return Result
  RETURN result;

END;
$$

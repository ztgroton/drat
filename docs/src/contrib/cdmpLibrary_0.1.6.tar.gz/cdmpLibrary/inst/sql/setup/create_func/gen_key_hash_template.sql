
CREATE OR REPLACE FUNCTION public.gen_key_hash_template(data TEXT, sch TEXT DEFAULT NULL, tbl TEXT DEFAULT NULL, comp TEXT DEFAULT NULL)
  RETURNS TEXT
  LANGUAGE PLPGSQL
AS $$
DECLARE

  result TEXT;

BEGIN

  -- Build SELECT statement to generate key values
  result := CONCAT(
    'select '::TEXT,
    public.tmp_col_hash(data, sch, tbl, comp)::TEXT, ' as key_hash, ',
    't.* ',
    format('from public.%I as t ', data::TEXT)
  );

  -- Return Result
  RETURN result;

END;
$$

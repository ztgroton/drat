
CREATE TRIGGER map_lib_update_trigger_update AFTER UPDATE 
ON map_library.map_lib REFERENCING OLD TABLE AS old_table NEW TABLE AS new_table
FOR EACH STATEMENT EXECUTE PROCEDURE public.log_map_lib_update();

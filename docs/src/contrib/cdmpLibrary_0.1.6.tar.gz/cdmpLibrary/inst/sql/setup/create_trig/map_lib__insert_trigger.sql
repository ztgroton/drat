
CREATE TRIGGER map_lib_{schema_val}_{table_val}_insert_trig AFTER INSERT  
ON {schema_val}.{table_val} REFERENCING NEW TABLE AS new_table
FOR EACH STATEMENT EXECUTE PROCEDURE public.log_map_lib();

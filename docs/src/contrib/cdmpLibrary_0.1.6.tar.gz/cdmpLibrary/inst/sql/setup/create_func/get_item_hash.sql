
CREATE OR REPLACE FUNCTION public.get_item_hash(item_code NUMERIC, position_key INTEGER) 
  RETURNS TEXT
  LANGUAGE PLPGSQL
AS $$ 
DECLARE 
  
  item_code_hash TEXT;
  
BEGIN 
  
  SELECT t.map_hash INTO item_code_hash 
  FROM map_library.twm_map t 
  where t.twm_item_code = item_code 
  and t.twm_position_key = position_key;
  
  RETURN item_code_hash;
  
END;
$$;

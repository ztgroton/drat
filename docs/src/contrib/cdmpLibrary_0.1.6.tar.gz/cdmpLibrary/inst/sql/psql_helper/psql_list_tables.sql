
SELECT
t.table_catalog,
t.table_schema,
t.table_name,
t.table_type
FROM information_schema.tables t
WHERE t.table_schema = {schema_val}

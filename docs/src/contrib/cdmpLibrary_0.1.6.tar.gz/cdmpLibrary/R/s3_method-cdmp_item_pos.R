
#' S3 Method - Retrieve Internal Values from 'cdmp_item_pos' object
#'
#' @param obj S3 Object of class 'cdmp_item_pos'
#' @param name character
#'
#' @return NULL
#' @export
#'
get_elem.cdmp_item_pos <- function(obj, name) {

  # Validate Inputs
  if (missing(obj)) {stop("`obj` is missing in call to `get_elem.cdmp_item_pos`")}
  if (missing(name)) {stop("`name` is missing in call to `get_elem.cdmp_item_pos`")}

  # Validate Input Expectations

  # * `name`
  dbTools::expect_scalar_char(name)
  if (!isTRUE(name %in% c('item_code', 'position'))) {
    stop("`name` must refer to element name of `obj` in call to `get_elem.cdmp_item_pos`")
  }

  # Return Result
  return(obj[[name]])

}

#' S3 Method - Set Internal Values from 'cdmp_item_pos' object
#'
#' @param obj S3 Object of class 'cdmp_item_pos'
#' @param name character
#' @param value R Object
#'
#' @return NULL
#' @export
#'
set_elem.cdmp_item_pos <- function(obj, name, value) {

  # Validate Inputs
  if (missing(obj)) {stop("`obj` is missing in call to `set_elem.cdmp_item_pos`")}
  if (missing(name)) {stop("`name` is missing in call to `set_elem.cdmp_item_pos`")}
  if (missing(value)) {stop("`value` is missing in call to `set_elem.cdmp_item_pos`")}

  # Validate Input Expectations

  # * `name`
  dbTools::expect_scalar_char(name)
  if (!isTRUE(name %in% c('item_code', 'position'))) {
    stop("`name` must refer to non-key element name of `obj` in call to `set_elem.cdmp_item_pos`")
  }

  # Set Value
  obj[[name]] <- value

  # Return Success
  invisible(TRUE)

}

#' S3 Method - Upsert Values for 'cdmp_item_pos' object
#'
#' @param obj S3 Object of class 'cdmp_item_pos'
#'
#' @return character
#' @export
#'
upsert_item_pos.cdmp_item_pos <- function(obj) {

  # Validate Inputs
  if (missing(obj)) {stop("`obj` is missing in call to `upsert_item_pos.cdmp_item_pos`")}

  # Validate Input Expectations

  # * `obj`
  if (!isTRUE(inherits(obj, 'cdmp_item_pos'))) {
    stop("`obj` must inherit from 'cdmp_item_pos' in call to `upsert_item_pos.cdmp_item_pos`")
  }
  stopifnot(isTRUE(validate_cdmp_item_pos(obj, TRUE)))

  #encode(public.digest(CONCAT(twm_item_code::TEXT, '-'::TEXT, twm_position_key::TEXT), 'sha256'), 'hex')

  # Setup Connection to Competitor Mapping Library
  conn <- dbTools::psql_db_connect('comp_map_lib_prod')

  # Calculate `map_hash`
  map_hash <- digest::digest(paste(obj$item_code, obj$position, sep = '-'), algo = 'sha256', serialize = FALSE)

  # Prepare Upload Data
  table_id <- DBI::Id(schema = 'map_library', table = 'twm_map')
  upload_data <- data.frame(
    map_hash = map_hash,
    twm_item_code = obj$item_code,
    twm_position_key = obj$position,
    stringsAsFactors = FALSE
  )

  # Upsert Data using 'dbx' package
  dbx::dbxUpsert(
    conn = conn,
    table = table_id,
    records = upload_data,
    where_cols = 'map_hash'
  )

  # Close Connection to Competitor Mapping Library
  DBI::dbDisconnect(conn)
  rm(conn)

  # Return 'map_hash'
  return(map_hash)

}

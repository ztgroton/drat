
#' Does 'schema' exist in 'conn'?
#'
#' @importFrom rlang .data
#'
#' @param conn DBIConnection - R Database Connection Object
#' @param schema character - name of schema
#'
#' @return TRUE/FALSE
#'
schema_exists <- function(conn, schema) {

  # Validate Inputs
  if (missing(conn)) {stop("`conn` is missing in call to `schema_exists`", call. = FALSE)}

  # Validate Input Expectations
  expect_dbi(conn)
  expect_scalar_char(schema)

  # MAIN LOGIC

  # * Check if schema exists
  exist_qry <- glue::glue("select exists (select * from pg_catalog.pg_namespace where nspname = '{schema}');")
  does_exist <- DBI::dbGetQuery(conn, exist_qry) %>% dplyr::pull(.data$exists)

  # * Return Result
  return(isTRUE(does_exist))

}

#' Does 'table' exist in 'conn'.'schema'?
#'
#' @importFrom rlang .data
#'
#' @param conn DBIConnection - R Database Connection Object
#' @param schema character - name of schema
#' @param table character - name of table
#'
#' @return TRUE/FALSE
#'
table_exists <- function(conn, schema, table) {

  # Validate Inputs
  if (missing(conn)) {stop("`conn` is missing in call to `table_exists`", call. = FALSE)}
  if (missing(schema)) {stop("`schema` is missing in call to `table_exists`", call. = FALSE)}
  if (missing(table)) {stop("`table` is missing in call to `table_exists`", call. = FALSE)}

  # Validate Input Expectations
  expect_dbi(conn)
  expect_scalar_char(schema)
  expect_scalar_char(table)

  # MAIN LOGIC

  # * Check if schema exists
  does_schema_exist <- schema_exists(conn, schema)
  if (!isTRUE(does_schema_exist)) {
    message("`schema` DOES NOT EXIST in `conn` in call to `table_exists`")
    return(FALSE)
  }

  # * Check if table exists
  exist_qry <- glue::glue_sql("SELECT EXISTS (SELECT FROM information_schema.tables WHERE table_schema = {schema} AND table_name = {table})", .con = conn)
  does_exist <- DBI::dbGetQuery(conn, exist_qry) %>% dplyr::pull(.data$exists)

  # * Return Result
  return(isTRUE(does_exist))

}

#' Create New Schema in Database
#'
#' @param conn DBIConnection - R Database Connection Object
#' @param schema character - name of schema
#' @param preclean TRUE/FALSE - indicates whether to drop pre-existing schema
#'
#' @return NULL
#'
create_schema <- function(conn, schema, preclean = FALSE) {

  # Validate Inputs
  if (missing(conn)) {stop("`conn` is missing in call to `create_schema`", call. = FALSE)}
  if (missing(schema)) {stop("`schema` is missing in call to `create_schema`", call. = FALSE)}
  if (missing(preclean)) {preclean <- FALSE}

  if (!isTRUE(inherits(conn, 'DBIConnection'))) {
    stop("`conn` must inherit from 'DBIConnection' in call to `create_schema`", call. = FALSE)
  }

  if (!isTRUE(is.character(schema))) {
    stop("`schema` must be a character in call to `create_schema`", call. = FALSE)
  }

  if (!isTRUE(identical(preclean, TRUE)) && !isTRUE(identical(preclean, FALSE))) {
    stop("`preclean` must be TRUE/FALSE in call to `create_schema`", call. = FALSE)
  }

  # Conditionally Drop Pre-Existing Schema
  if (isTRUE(preclean)) {
    drop_schema(conn = conn, schema = schema)
  }

  # Execute 'Create'
  DBI::dbExecute(conn = conn, glue::glue("CREATE SCHEMA IF NOT EXISTS {schema}"))
  invisible(NULL)

}

#' Drop Existing Schema from Database
#'
#' @param conn DBIConnection - R Database Connection Object
#' @param schema character - name of schema
#'
#' @return NULL
#'
drop_schema <- function(conn, schema) {

  # Validate Inputs
  if (missing(conn)) {stop("`conn` is missing in call to `drop_schema`", call. = FALSE)}
  if (missing(schema)) {stop("`schema` is missing in call to `drop_schema`", call. = FALSE)}

  if (!isTRUE(inherits(conn, 'DBIConnection'))) {
    stop("`conn` must inherit from 'DBIConnection' in call to `drop_schema`", call. = FALSE)
  }

  if (!isTRUE(is.character(schema))) {
    stop("`schema` must be a character in call to `drop_schema`", call. = FALSE)
  }

  # Execute 'Drop'
  DBI::dbExecute(conn = conn, glue::glue("DROP SCHEMA IF EXISTS {schema} CASCADE"))
  invisible(NULL)

}

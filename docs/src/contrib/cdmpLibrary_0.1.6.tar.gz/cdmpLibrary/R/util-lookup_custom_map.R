
#' Returns Current Mappings for TWM Item/Position, based on 'schema' and 'table'
#'
#' @importFrom rlang .data
#'
#' @param schema character - name of schema containing desired table
#' @param table character - name of desired table
#' @param item_code numeric - Single TWM Item Code
#' @param position_key numeric - Single TWM Position Key
#' @param use_dev logical - optionally specify if development database should be used.
#'
#' @return data.frame
#' @export
#'
lookup_custom_map <- function(schema, table, item_code, position_key, use_dev = FALSE) {

  # Validate Inputs
  if (missing(schema)) {stop("`schema` is missing in call to `lookup_custom_map`", call. = FALSE)}
  if (missing(table)) {stop("`table` is missing in call to `lookup_custom_map`", call. = FALSE)}
  if (missing(item_code)) {stop("`item_code` is missing in call to `lookup_custom_map`", call. = FALSE)}
  if (missing(position_key)) {stop("`position_key` is missing in call to `lookup_custom_map`", call. = FALSE)}
  if (missing(use_dev)) {use_dev <- FALSE}

  # Validate Input Expectations

  # * `schema`
  expect_scalar_char(obj = schema)

  # * `table`
  expect_scalar_char(obj = table)

  # * `item_code`
  if (!isTRUE(is.numeric(item_code)) || !isTRUE(length(item_code) == 1) || isTRUE(is.na(item_code))) {
    stop("`item_code` must be scalar numeric in call to `lookup_custom_map`")
  }

  # * `position_key`
  if (!isTRUE(position_key %in% c(1,2,3)) || !isTRUE(length(position_key) == 1)) {
    stop("`position_key` must equal 1, 2 or 3 in call to `lookup_custom_map`")
  }

  # * `use_dev`
  if (!isTRUE(identical(use_dev, TRUE)) && !isTRUE(identical(use_dev, FALSE))) {
    stop("`use_dev` must be identical to TRUE/FALSE in call to `lookup_custom_map`")
  }

  # MAIN LOGIC

  # Setup DB Connection
  if (isTRUE(identical(use_dev, TRUE))) {
    conn <- psql_db_connect('comp_map_lib_dev')
  } else {
    conn <- psql_db_connect('comp_map_lib_prod')
  }

  # * Validate `schema` against expected Shop Parties
  expected_schemas <- c('nlsn', 'iri', 'bst', 'twm', 'tws')
  if (!isTRUE(all(schema %in% expected_schemas))) {
    stop("`schema` must be a valid shop party in call to `lookup_custom_map`", call. = FALSE)
  }

  # # * Validate `table` against expected Mapping Types
  # expected_types <- c('upc_text', 'upc_num', 'item_name', 'party_product_id')
  # if (!isTRUE(all(table %in% expected_types))) {
  #   stop("`table` must be a valid mapping type in call to `lookup_custom_map`", call. = FALSE)
  # }

  # Check if 'table' exists in 'schema'
  if (isTRUE(table_exists(conn, schema, table))) {

    # Lookup 'map_hash' for TWM Item
    map_hash <- lookup_map_hash(item_code, position_key)

    # Validate Map Hash
    if (!isTRUE(is.character(map_hash)) || !isTRUE(length(map_hash) == 1) || isTRUE(is.na(map_hash))) {
      stop("`map_hash` must be scalar character in call to `lookup_custom_map`")
    }

    # 'DBI' Table ID
    table_qry <- glue::glue_sql(
      "select t.*
      from {`schema`}.{`table`} t
      where t.map_hash = {map_hash} ",
      .con = conn
    )

    # Query Key Mappings
    tryCatch({

      res <- DBI::dbGetQuery(conn = conn, table_qry)
      DBI::dbDisconnect(conn)

      return(res)

    }, error = function(e) {
      DBI::dbDisconnect(conn)
      stop(sprintf("Error in %s: %s", deparse(e[["call"]]), e[["message"]]), call. = FALSE)
    })


  } else {
    DBI::dbDisconnect(conn)
    stop(paste0("table `", table, "` DOES NOT EXIST in schema `", schema, "` -  SKIPPING!!!"), call. = FALSE)
  }

}

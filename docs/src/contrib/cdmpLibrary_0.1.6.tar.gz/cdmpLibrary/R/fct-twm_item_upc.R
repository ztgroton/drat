
#' Fetch Item-UPC Lookup Table from PostgreSQL Database
#'
#' @param use_dev logical
#'
#' @return data.frame
#' @export
#'
#' @examples
#' \dontrun{
#' output <- twm_item_upc()
#' }
twm_item_upc <- function(use_dev) {

  # Validate Inputs ----
  if (missing(use_dev)) {use_dev <- FALSE}

  # Validate Input Expectations ----
  if (!isTRUE(identical(use_dev, TRUE)) && !isTRUE(identical(use_dev, FALSE))) {
    stop("`use_dev` must be TRUE/FALSE in call to `cdmp_upc_lookup`")
  }

  # Open Connection to 'PSQL - conn'
  if (isTRUE(use_dev)) {
    conn <- dbTools::psql_db_connect('comp_map_lib_dev')
  } else {
    conn <- dbTools::psql_db_connect('comp_map_lib_prod')
  }

  # Fetch SQL Query
  qry <- "select * from map_library.twm_item_upc"

  tryCatch({

    # Execute SQL Query / Fetch Results
    results <- DBI::dbGetQuery(conn, qry)

    # Close Connection to 'PSQL - conn'
    DBI::dbDisconnect(conn)
    rm(conn)

  }, error = function(e) {

    # Close Connection to 'PSQL - conn'
    DBI::dbDisconnect(conn)
    rm(conn)

    # Throw Error Message
    stop(sprintf("Error in %s: %s", deparse(e[["call"]]), e[["message"]]))

  })

  # Return Results
  return(results)

}

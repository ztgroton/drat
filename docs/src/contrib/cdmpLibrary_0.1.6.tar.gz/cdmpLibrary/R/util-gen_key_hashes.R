
#' Generate Key Hashes using Public Table Data
#'
#' @param conn DBIConnection
#' @param data data.frame
#' @param schema character
#' @param table character
#' @param competitor character
#'
#' @return data.frame
#' @export
#'
#' @examples
#' \dontrun{
#' output <- gen_key_hashes(conn = comp_map_lib, data = raw_data)
#' }
gen_key_hashes <- function(conn, data, schema, table, competitor) {

  # Validate Inputs ----
  if (missing(conn)) {stop("`conn` is missing in call to `gen_key_hashes`")}
  if (missing(data)) {stop("`data` is missing in call to `gen_key_hashes`")}
  if (missing(schema)) {schema <- NULL}
  if (missing(table)) {table <- NULL}
  if (missing(competitor)) {competitor <- NULL}

  # Validate Input Expectations ----

  # * conn ----
  if (!isTRUE(inherits(conn, 'DBIConnection'))) {
    stop("`conn` must inherit from 'DBIConnection' in call to `gen_key_hashes`")
  }

  # * data ----
  if (!isTRUE(is.data.frame(data))) {
    stop("`data` is missing in call to `gen_key_hashes`")
  }

  # * schema ----
  if (!isTRUE(identical(schema, NULL))) {

    if (!isTRUE(is.character(schema)) ||
        !isTRUE(length(schema) == 1) ||
        isTRUE(is.na(schema))
    ) {
      stop("`schema` must either be NULL or a scalar character in call to `gen_key_hashes`")
    }

  }

  # * table ----
  if (!isTRUE(identical(table, NULL))) {

    if (!isTRUE(is.character(table)) ||
        !isTRUE(length(table) == 1) ||
        isTRUE(is.na(table))
    ) {
      stop("`table` must either be NULL or a scalar character in call to `gen_key_hashes`")
    }

  }

  # * schema & table ----
  if (
    (isTRUE(is.null(schema)) && !isTRUE(is.null(table))) ||
    (!isTRUE(is.null(schema)) && isTRUE(is.null(table)))
  ) {
    stop("`schema` and `table` must both be NULL or non-NULL in call to `gen_key_hashes`")
  }

  # * competitor ----
  if (!isTRUE(identical(competitor, NULL))) {

    if (!isTRUE(is.character(competitor)) ||
        !isTRUE(length(competitor) == 1) ||
        isTRUE(is.na(competitor))
    ) {
      stop("`competitor` must either be NULL or a scalar character in call to `gen_key_hashes`")
    }

  }

  # MAIN LOGIC ----

  # Upload `data` to Public Table ----
  tmp_tbl <- upload_tmp_tbl(data = data)

  # Generate Dynamic SQL Select Statement
  qry_key_hash <- DBI::dbGetQuery(conn, glue::glue_sql(
    "select public.gen_key_hash_template({tmp_tbl}, {schema}, {table}, {competitor})",
    .con = conn
  )) %>%
    dplyr::pull(.data$gen_key_hash_template)

  # Execute Dynamic SQL / Fetch Results
  results <- DBI::dbGetQuery(conn, qry_key_hash)

  # Remove Public Table Data
  drop_tmp_tbl(tmp_tbl)

  # Return Results
  return(results)

}

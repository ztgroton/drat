
#' Archive Table Data for a Selected Database
#'
#' @importFrom rlang .data
#'
#' @param db character - name of database to archive
#'
archive_table_data <- function(db) {

  if (missing(db)) {stop("`db` is missing in call to `archive_table_data`", call. = FALSE)}

  # Query Table List
  cat("Querying Table List...")
  tictoc::tic()
  psql_tables <- list_psql_table() %>%
    dplyr::filter(
      .data$table_type == "BASE TABLE",
      .data$table_catalog == db
    ) %>%
    dplyr::select(-.data$table_type)
  tictoc::toc()

  # Get Root Directory
  rootDir <- system.file('/databases/', package = 'cdmpLibrary')

  # Create Database Folder
  cat("Database Folder Setup...")
  tictoc::tic()
  dbDir <- file.path(rootDir, db)
  dir.create(dbDir, showWarnings = FALSE)
  tictoc::toc()

  # Create Schema Folders
  cat("Schema Folder(s) Setup...")
  tictoc::tic()
  schema_list <- psql_tables %>%
    dplyr::distinct(.data$table_schema) %>%
    dplyr::pull(.data$table_schema)

  purrr::walk(schema_list, ~ dir.create(file.path(dbDir, .), showWarnings = FALSE))
  tictoc::toc()

  # Iterate over all Tables
  cat("\nArchiving Table Data...\n")

  walk_list <- list(psql_tables$table_catalog, psql_tables$table_schema, psql_tables$table_name)

  purrr::pwalk(walk_list, function(db, schema, table){

    tryCatch({

      cat(paste0(paste(db, schema, table, sep = '-'), '...'))
      tictoc::tic()

      data <- get_table_data(
        db = db,
        schema = schema,
        table = table
      )

      data_path <- file.path(rootDir, db, schema, table)
      saveRDS(data, paste0(data_path, '.rds'))

      tictoc::toc()

    }, error = function(e) {
      message(sprintf("Error in %s: %s", deparse(e[["call"]]), e[["message"]]))
    })

  })

}

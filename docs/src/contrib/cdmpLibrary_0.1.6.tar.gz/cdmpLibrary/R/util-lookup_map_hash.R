
#' Lookup 'map_hash' using TWM Item Code & Position Key
#'
#' @param item_code numeric - TWM Item Code
#' @param position_key numeric - TWM Position Key
#' @param use_dev logical - TRUE/FALSE
#'
#' @return character
#' @export
#'
#' @examples
#' \dontrun{
#' output <- lookup_map_hash(item_code = 29123, position_key = 3)
#' }
lookup_map_hash <- function(item_code, position_key, use_dev = FALSE) {

  # Validate Inputs
  if (missing(item_code)) {stop("`item_code` is missing in call to `lookup_map_hash`", call. = FALSE)}
  if (missing(position_key)) {stop("`position_key` is missing in call to `lookup_map_hash`", call. = FALSE)}
  if (missing(use_dev)) {use_dev <- FALSE}

  # Validate Input Expectations

  # * `item_code`
  if (!isTRUE(is.numeric(item_code)) || !isTRUE(length(item_code) == 1) || isTRUE(is.na(item_code))) {
    stop("`item_code` must be scalar numeric in call to `lookup_map_hash`")
  }

  # * `position_key`
  if (!isTRUE(position_key %in% c(1,2,3)) || !isTRUE(length(position_key) == 1)) {
    stop("`position_key` must equal 1, 2 or 3 in call to `lookup_map_hash`")
  }

  # * `use_dev`
  if (!isTRUE(identical(use_dev, TRUE)) && !isTRUE(identical(use_dev, FALSE))) {
    stop("`use_dev` must be identical to TRUE/FALSE in call to `lookup_map_hash`")
  }

  # MAIN LOGIC

  # Setup DB Connection
  if (isTRUE(identical(use_dev, TRUE))) {
    conn <- psql_db_connect('comp_map_lib_dev')
  } else {
    conn <- psql_db_connect('comp_map_lib_prod')
  }

  # Create Mapping Query
  map_qry <- glue::glue_sql(
    "select t.map_hash
    from map_library.twm_map t
    where t.twm_item_code = {item_code}
    and t.twm_position_key = {position_key}"
  )

  # Query Key Mappings
  tryCatch({

    res <- DBI::dbGetQuery(conn = conn, map_qry) %>% dplyr::pull(.data$map_hash)
    DBI::dbDisconnect(conn)

    return(res)

  }, error = function(e) {
    DBI::dbDisconnect(conn)
    stop(sprintf("Error in %s: %s", deparse(e[["call"]]), e[["message"]]), call. = FALSE)
  })

}

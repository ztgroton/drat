
#' Restore Archived Table Data
#'
#' @param conn DBIConnection
#' @param schema character
#' @param table character
#'
#' @return TRUE
#' @export
#'
#' @examples
#' \dontrun{
#' restore_mapping_table(conn = psql_conn, schema = 'nlsn', table = 'upc_num')
#' }
restore_mapping_table <- function(conn, schema, table) {

  # Validate Inputs
  if (missing(conn)) {stop("`conn` is missing in call to `restore_mapping_table`")}
  if (missing(schema)) {stop("`schema` is missing in call to `restore_mapping_table`")}
  if (missing(table)) {stop("`table` is missing in call to `restore_mapping_table`")}

  # Validate Input Expectations

  # * `conn`
  if (!isTRUE(inherits(conn, 'DBIConnection'))) {
    stop("`conn` must inherit from 'DBIConnection' in call to `restore_mapping_table`")
  }

  # * `schema`
  if (!isTRUE(is.character(schema)) || !isTRUE(length(schema) == 1) || !isFALSE(is.na(schema))) {
    stop("`schema` must be Non-NA length 1 character vector in call to `restore_mapping_table`")
  }

  # * `table`
  if (!isTRUE(is.character(table)) || !isTRUE(length(table) == 1) || !isFALSE(is.na(table))) {
    stop("`table` must be Non-NA length 1 character vector in call to `restore_mapping_table`")
  }

  # Generate Archived Data Path
  archive_path <- system.file('databases/comp_map_lib/public/', package = 'cdmpLibrary')
  archive_file_name <- paste0(paste('new', schema, table, sep = '_'), '.rds')
  archive_file_path <- file.path(archive_path, archive_file_name)

  # Fetch Archived RDS Data
  cat("Fetching Archive Data... ")
  tictoc::tic()
  archive_data <- readRDS(archive_file_path)
  tictoc::toc()

  # Initialize Destination Table Id
  dest_table <- DBI::Id(schema = schema, table = table)

  # Insert Archived Data into Destination Table
  cat("Inserting Archive Data... ")
  tictoc::tic()
  dbx::dbxInsert(
    conn = conn,
    table = dest_table,
    records = archive_data
  )
  tictoc::toc()

  # Return Success
  invisible(TRUE)

}


#' Query Record-Level Library Matches for a Selected File
#'
#' @param file_hash character
#' @param use_dev logical
#'
#' @return data.frame
#' @export
#'
#' @examples
#' \dontrun{
#' output <- vw_file_matches(file_hash, use_dev = TRUE)
#' }
vw_file_matches <- function(file_hash, use_dev = FALSE) {

  # Validate Inputs ----
  if (missing(file_hash)) {stop("`file_hash` is missing in call to `vw_file_matches`")}
  if (missing(use_dev)) {use_dev <- FALSE}

  # Validate Input Expectations ----

  # * file_hash ----
  if (
    !isTRUE(is.character(file_hash))
    || !isTRUE(length(file_hash) == 1)
    || isTRUE(is.na(file_hash))
  ) {
    stop("`file_hash` must be scalar character in call to `vw_file_matches`")
  }

  # * use_dev ----
  if (!isTRUE(identical(use_dev, TRUE)) && !isTRUE(identical(use_dev, FALSE))) {
    stop("`use_dev` must be TRUE/FALSE in call to `vw_file_matches`")
  }

  # MAIN LOGIC ----

  # Fetch Parametrized SQL Query
  qry <- readr::read_file(system.file('sql/psql_helper/glue_sql/file_hash_matches.sql', package = 'cdmpLibrary'))

  # Setup DB Connection
  if (isTRUE(identical(use_dev, TRUE))) {
    conn <- psql_db_connect('comp_map_lib_dev')
  } else {
    conn <- psql_db_connect('comp_map_lib_prod')
  }

  # Bind `file_hash` input value to `qry`
  qry <- glue::glue_sql(qry, .con = conn)

  # Execute `qry` / Fetch Results
  results <- DBI::dbGetQuery(conn, qry)

  # Close DB Connection
  DBI::dbDisconnect(conn)
  rm(conn)

  # Return Results
  return(results)

}


#' shinyParamPicker_ui
#'
#' @param id character - A non-na, length 1 character vector
#'
#' @return R Shiny Tags
#' @export
#'
#' @examples
#' \dontrun{
#' shinyParamPicker(id = 'param_picker1')
#' }
shinyParamPicker_ui <- function(id) {

  ns <- NS(id)

  div(
    id = id,
    tagList(
      #tags$div(id = ns('param_picker_ui_placeholder'), style = "width:100%")
      shiny::uiOutput(ns('picker_ui'))
    )
  )

}

#' shinyParamPicker_server
#'
#' @param id character - A non-na, length 1 character vector
#' @param choices list
#'
#' @return Reactive Expression
#' @export
#'
#' @examples
#' \dontrun{
#' output_values <- shinyParamPicker(id = 'param_picker1')
#' }
shinyParamPicker_server <- function(id, choices) {

  moduleServer(id, function(input, output, session){

    ns <- session$ns

    # _____________________________________ ----
    # MODULE INPUT REACTIVE EXPRESSIONS ----

    # * choiceData() ----
    choiceData <- shiny::reactive({

      shiny::req(choices())

      if (isFALSE(validate_param_picker_choices(choices()))) {
        shinyWidgets::show_toast(
          title = "Invalid Picker Choices!!!",
          type = "error",
          position = "bottom"
        )
      }
      else {
        return(choices())
      }

    })

    # _______________________________ ----
    # GLOBAL REACTIVE EXPRESSIONS ----

    # * choiceDataLength() ----
    choiceDataLength <- shiny::reactive({

      shiny::req(choiceData())

      if (isTRUE(length(choiceData()) > 0)) {
        return(length(choiceData()))
      } else {
        return(NULL)
      }

    })

    # _________ ----
    # OUTPUTS ----

    # * `picker_ui` ----
    output$picker_ui <- shiny::renderUI({

      shiny::req(choiceData())
      shiny::req(choiceDataLength())

      generate_param_pickers(x = choiceData(), validate = TRUE)

    })

    # __________________________________ ----
    # Reactive Expression - Picker Selections ----
    picker_selections <- shiny::reactive({

      shiny::req(choiceData())

      purrr::map(validate_param_picker_choices(choiceData()), function(choiceColumn) {

        rs <- purrr::map(names(choiceColumn), function(choice_name) {
          ifelse(is.null(input[[choice_name]]), NA, input[[choice_name]])
        })

        names(rs) <- names(choiceColumn)
        return(rs)

      })

    })

    # _____________________ ----
    # Return Picker Selections ----
    return(picker_selections)

  })

}

#' Test and Debug R shiny Module 'shinyParamPicker'
#'
#' @importFrom utils read.csv
#'
#' @param choices list
#' @param ... ellipsis
#'
#' @export
#'
#' @examples
#' \dontrun{
#' shinyParamPicker(choices)
#' }
shinyParamPicker <- function(choices, ...) {

  # Validate Input
  if (missing(choices)) {

    choices <- list(
      list(

        test_picker1 = list(
          multiple = TRUE,
          choices = LETTERS,
          label = "TEST PICKER1"
        ),

        test_picker2 = list(
          multiple = FALSE,
          choices = LETTERS,
          label = "TEST PICKER2"
        )

      ),

      list(
        test_picker3 = list(
          multiple = TRUE,
          choices = LETTERS,
          label = "TEST PICKER3"
        )
      )

    )

  }

  # Validate Input Expectations
  if (isFALSE(validate_param_picker_choices(x = choices))) {
    stop("`choices` must be valid input in call to `shinyParamPicker`")
  }

  # * `ui`
  ui <- shiny::fluidPage(
    shiny::column(
      width = 12,
      shinyParamPicker_ui('param_picker1')
    )
  )

  # * `server`
  server <- function(input, output, session) {

    raw_choices <- shiny::reactive({choices})

    picker_selections <- shinyParamPicker_server(
      id = 'param_picker1',
      choices = raw_choices
    )

    observe({

      shiny::req(picker_selections())
      print(picker_selections())

    })

  }

  shiny::shinyApp(ui, server, ...)

}

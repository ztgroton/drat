
#' shinyParamStorage_ui
#'
#' @param id character - A non-na, length 1 character vector
#'
#' @return R Shiny Tags
#' @export
#'
#' @examples
#' \dontrun{
#' shinyParamStorage(id = 'param_store1')
#' }
shinyParamStorage_ui <- function(id) {

  ns <- NS(id)

  div(
    id = id,
    tagList(

    )
  )

}

#' shinyParamStorage_server
#'
#' @param id character - A non-na, length 1 character vector
#' @param data data.frame
#'
#' @return Reactive Expression
#' @export
#'
#' @examples
#' \dontrun{
#' output_values <- shinyParamStorage(id = 'param_store1')
#' }
shinyParamStorage_server <- function(id, data) {

  moduleServer(id, function(input, output, session){

    ns <- session$ns

  })

}

#' Test and Debug R shiny Module 'shinyParamStorage'
#'
#' @importFrom utils read.csv
#'
#' @param data data.frame
#' @param ... ellipsis
#'
#' @export
#'
#' @examples
#' \dontrun{
#' shinyParamStorage(raw_data)
#' }
shinyParamStorage <- function(data, ...) {

  # Validate Input
  if (missing(data)) {stop("`data` is missing in call to `shinyParamStorage`")}

  # Validate Input Expectations
  if (!isTRUE(is.data.frame(data))) {
    stop("`data` must be 'data.frame' in call to `shinyParamStorage`")
  }

  # * `ui`
  ui <- shiny::tagList(
    shiny::column(
      width = 12,
      shinyParamStorage_ui('param_storage1')
    )
  )

  # * `server`
  server <- function(input, output, session) {

    raw_data <- shiny::reactive({data})

    selected_rows <- shinyParamStorage_server(
      id = 'param_storage1',
      data = raw_data
    )

    shiny::observe({
      req(selected_rows())
      print(selected_rows())
    })

  }

  shiny::shinyApp(ui, server, ...)

}

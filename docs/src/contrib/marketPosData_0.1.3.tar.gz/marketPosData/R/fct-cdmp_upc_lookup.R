
#' Fetch 'UPC-to-TWM Item' Lookup Table from CDMP Library
#'
#' @importFrom rlang .data
#'
#' @param use_dev logical
#'
#' @return data.frame
#' @export
#'
#' @examples
#' \dontrun{
#' output <- cdmp_upc_lookup()
#' }
cdmp_upc_lookup <- function(use_dev = FALSE) {

  # Validate Inputs ----
  if (missing(use_dev)) {use_dev <- FALSE}

  # Validate Input Expectations ----
  if (!isTRUE(identical(use_dev, TRUE)) && !isTRUE(identical(use_dev, FALSE))) {
    stop("`use_dev` must be TRUE/FALSE in call to `cdmp_upc_lookup`")
  }

  # MAIN LOGIC ----

  tryCatch({

    # Fetch UPC Lookup from 'conn'
    results <- cdmpLibrary::twm_item_upc(use_dev)

    # Convert 'upc' to numeric
    results <- results %>% dplyr::mutate(upc = as.numeric(.data$upc))

  }, error = function(e) {

    # Throw Error Message
    stop(sprintf("Error in %s: %s", deparse(e[["call"]]), e[["message"]]))

  })

  # Return Results
  return(results)

}

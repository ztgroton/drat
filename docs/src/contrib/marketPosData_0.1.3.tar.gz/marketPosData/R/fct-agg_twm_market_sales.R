
#' Aggregate Market Sales Data by TWM Item/Position
#'
#' @param market_sales data.frame
#'
#' @return data.frame
#' @export
#'
#' @examples
#' \dontrun{
#' output <- agg_twm_market_sales(market_sales)
#' }
agg_twm_market_sales <- function(market_sales) {

  # Validate Inputs
  if (missing(market_sales)) {stop("`market_sales` is missing in call to `agg_twm_market_sales`")}

  # Validate Input Expectations

  # * `market_sales`
  if (!isTRUE(is.data.frame(market_sales))) {
    stop("`market_sales` must be data.frame in call to `agg_twm_market_sales`")
  }

  # * `colnames(market_sales)`
  expected_columns <- c('twm_item_code', 'twm_position_key', 'sales_dollars', 'sales_dollars_ya')
  if (!isTRUE(all(expected_columns %in% colnames(market_sales)))) {
    stop("`colnames(market_sales)` must contain all expected columns in call to `agg_twm_market_sales`")
  }

  # MAIN LOGIC

  # Aggregate Market Sales by TWM Item/Position
  market_sales <- market_sales %>%
    dplyr::filter(!is.na(.data$twm_item_code), !is.na(.data$twm_position_key)) %>%
    dplyr::group_by(.data$twm_item_code, .data$twm_position_key) %>%
    dplyr::summarise(
      sales_dollars = sum(.data$sales_dollars),
      sales_dollars_ya = sum(.data$sales_dollars_ya)
    ) %>%
    dplyr::ungroup()

  # Return Market Sales
  return(market_sales)

}

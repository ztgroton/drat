
#' Upload Nielsen/IRI Market Sales Data to PSQL DB 'market_pos'
#'
#' @importFrom rlang .data
#'
#' @param file data.frame - Market Data
#' @param name character - Name of File
#' @param upload_map data.frame  - Original-to-Formatted Column Name Mappings
#'
#' @return TRUE
#' @export
#'
#' @examples
#' \dontrun{
#' upload_market_file(raw_data_frame, 'file_name_1', upload_map_data_frame)
#' }
upload_market_file <- function(file, name, upload_map) {

  tryCatch(
    {

      # Initialize Upload Connection ----
      upload_cn <- dbTools::psql_db_connect('market_pos')

      file_upload_name <- paste0('[', name, ']')
      suppressWarnings({
        file_upload_date <- lubridate::with_tz(Sys.time(), tzone = "GMT")
      })

      file_upload <- data.frame(
        file_name = file_upload_name,
        upload_date = file_upload_date,
        stringsAsFactors = FALSE
      )

      # MAIN LOGIC ----

      # * `scan_period` ----
      scan_upload <- file %>% dplyr::distinct(.data$week_ending)

      dbx::dbxUpsert(
        conn = upload_cn,
        table = DBI::Id(schema = 'common', table = 'scan_period'),
        records = scan_upload,
        where_cols = 'week_ending'
      )

      # * `market_shop` ----
      market_shop <- file %>%
        dplyr::distinct(.data$market_name, .data$shop_party) %>%
        dplyr::rename(name = .data$market_name)

      dbx::dbxUpsert(
        conn = upload_cn,
        table = DBI::Id(schema = 'common', table = 'market_shop'),
        records = market_shop,
        where_cols = c('name', 'shop_party'),
        skip_existing = TRUE
      )

      # * `market_scan` ----
      market_scan <- file %>%
        dplyr::distinct(
          .data$market_name,
          .data$shop_party,
          .data$department,
          .data$week_ending
        )

      dbx::dbxUpsert(
        conn = upload_cn,
        table = DBI::Id(schema = 'common', table = 'market_scan'),
        records = market_scan,
        where_cols = c('market_name', 'shop_party', 'department', 'week_ending')
      )

      # * `file_upload` ----
      dbx::dbxInsert(
        conn = upload_cn,
        table = DBI::Id(schema = 'common', table = 'file_upload'),
        records = file_upload,
        returning = c('id')
      ) -> file_upload_id

      file_upload_id <- as.numeric(file_upload_id)

      if (!isTRUE(is.numeric(file_upload_id)) || !isTRUE(length(file_upload_id) == 1) || isTRUE(is.na(file_upload_id))) {
        stop("`file_upload_id` must be a valid numeric value!!!", call. = FALSE)
      }

      # * `market_scan_upload` ----
      market_scan_upload <- market_scan %>%
        dplyr::mutate(
          file_name = file_upload_name,
          upload_date = file_upload_date
        )

      dbx::dbxUpsert(
        conn = upload_cn,
        table = DBI::Id(schema = 'common', table = 'market_scan_upload'),
        records = market_scan_upload,
        where_cols = c('market_name', 'shop_party', 'department', 'week_ending', 'file_name', 'upload_date'),
        skip_existing = TRUE
      )

      # * `market_scan_upload_detail` ----
      market_scan_upload_detail <- file %>%
        dplyr::select(
          .data$market_name,
          .data$shop_party,
          .data$department,
          .data$week_ending,

          .data$upc,
          .data$long_product_description,
          .data$base_size,
          .data$ba_brand_family,
          .data$ba_category,
          .data$ba_subcategory,
          .data$ba_wine_type_group,
          .data$ba_country,
          .data$ba_manufacturer,

          .data$sales_dollars,
          .data$sales_dollars_ya,
          .data$sales_units,
          .data$sales_units_ya
        ) %>%
        dplyr::mutate(
          file_id = file_upload_id,
          file_name = file_upload_name,
          upload_date = file_upload_date
        ) %>%
        dplyr::relocate(
          .data$file_id,
          .data$file_name,
          .data$upload_date,
          .after = dplyr::last_col()
        )

      dbx::dbxInsert(
        conn = upload_cn,
        table = DBI::Id(schema = 'common', table = 'market_scan_upload_detail'),
        records = market_scan_upload_detail
      )

      # * `upload_mapping` ----
      upload_mapping <- cbind(file_upload, upload_map)
      dbx::dbxInsert(
        conn = upload_cn,
        table = DBI::Id(schema = 'common', table = 'upload_mapping'),
        records = upload_mapping
      )

      # Deconstruct Upload Connection
      DBI::dbDisconnect(upload_cn)
      rm(upload_cn)

    }
    , error = function(e) {

      # Deconstruct Upload Connection
      DBI::dbDisconnect(upload_cn)
      rm(upload_cn)

      # Return Error Message
      message(sprintf("Error in %s: %s", deparse(e[["call"]]), e[["message"]]))

    }
  )

}


#' Archive Table Data for 'EDAP-merchandising' BQ Dataset
#'
#' @param name character - Name of 'LTS Dashboard' table to archive
#' @param archive_only TRUE/FALSE - Optionally indicate if the table data should be archived only, or also returned as a data.frame
#'
#' @return data.frame or TRUE
#' @export
#'
#' @examples
#' \dontrun{
#' archive_bq_table('market', TRUE)
#' results <- archive_bq_table('market', FALSE)
#' results <- archive_bq_table('market')
#' }
archive_bq_table <- function(name, archive_only) {

  # Validate Inputs
  if (missing(name)) {stop("`name` is missing in call to `archive_bq_table`")}
  if (missing(archive_only)) {archive_only <- FALSE}

  # Validate Input Expectations

  # * `name`
  dbTools::expect_scalar_char(name)

  # * `archive_only`
  dbTools::expect_scalar_logical(archive_only)

  # Pull Table Data (If Table Exists)
  download_tbl <- dbTools::bq_init_tbl(dataset = 'merchandising', table = name)
  if (!isTRUE(bigrquery::bq_table_exists(download_tbl))) {
    stop("`name` must point to existing table in 'merchandising' schema in call to `archive_bq_table`")
  } else {
    result <- bigrquery::bq_table_download(download_tbl)
  }

  # Archive Results
  archive_dir_path <- system.file("rds/archive/edap_merch", package = 'marketPosData')
  archive_file_path <- file.path(archive_dir_path, paste0(name, ".rds"))
  saveRDS(result, archive_file_path)

  # Return
  if (!isTRUE(archive_only)) {
    return(result)
  } else {
    invisible(TRUE)
  }

}

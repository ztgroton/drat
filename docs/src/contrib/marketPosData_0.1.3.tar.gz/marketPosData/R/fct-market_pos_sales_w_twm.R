
#' Pull Latest Market Sales Data with TWM UPC Matches
#'
#' @importFrom rlang .data
#'
#' @param markets character
#' @param dept character
#' @param shop_party character
#' @param twm_item_only logical
#'
#' @return data.frame
#' @export
#'
#' @examples
#' \dontrun{
#' output <- market_pos_sales_w_twm(markets, dept, shop_party)
#' }
market_pos_sales_w_twm <- function(markets, dept, shop_party = 'NLSN', twm_item_only = FALSE) {

  # Validate Inputs ----
  if (missing(markets)) {stop("`markets` is missing in call to `market_pos_sales_w_twm`")}
  if (missing(dept)) {dept <- c('Beer', 'Wine', 'Spirits', 'Mixers', 'Misc.')}
  if (missing(shop_party)) {shop_party <- 'NLSN'}
  if (missing(twm_item_only)) {twm_item_only <- FALSE}

  # Validate Input Expectations ----

  # * markets ----
  if (
    !isTRUE(is.character(markets))
    || isTRUE(any(purrr::map_lgl(markets, function(t){isTRUE(is.null(t)) || isTRUE(is.na(t))})))
    || !isTRUE(length(markets) > 0)
  ) {
    stop("`markets` has invalid value in call to `market_pos_sales_w_twm`")
  }

  # * dept ----
  if (
    !isTRUE(is.character(dept))
    || isTRUE(any(purrr::map_lgl(dept, function(t){isTRUE(is.null(t)) || isTRUE(is.na(t))})))
    || !isTRUE(length(dept) > 0)
  ) {
    stop("`dept` has invalid value in call to `market_pos_sales_w_twm`")
  }

  # * shop_party ----
  if (
    !isTRUE(is.character(shop_party))
    || !isTRUE(length(shop_party) == 1)
    || isTRUE(is.null(shop_party))
    || isTRUE(is.na(shop_party))
  ) {
    stop("`shop_party` has invalid value in call to `market_pos_sales_w_twm`")
  }

  # * twm_item_only ----
  if (!isTRUE(identical(twm_item_only, TRUE)) && !isTRUE(identical(twm_item_only, FALSE))) {
    stop("`twm_item_only` must be TRUE/FALSE in call to `market_pos_sales_w_twm`")
  }

  # MAIN LOGIC ----

  # Fetch Market Sales Data ----
  cat("Querying 'market_sales'.... ")
  tictoc::tic()
  market_sales <- vw_market_pos_sales(markets, dept, shop_party)
  tictoc::toc()

  # Fetch UPC Mappings ----
  cat("Querying 'upc_map'.... ")
  tictoc::tic()
  upc_map <- cdmpLibrary::vw_map_key(schema = tolower(shop_party), table = 'upc_num')
  tictoc::toc()

  # Left-Join 'market_sales' with 'upc_map' ----
  cat("Joining 'market_sales' with 'upc_map'.... ")
  tictoc::tic()
  market_sales <- market_sales %>%
    dplyr::left_join(
      upc_map %>%
        dplyr::select(.data$upc, .data$twm_item_code, .data$twm_position_key) %>%
        dplyr::mutate(
          twm_item_code = as.numeric(.data$twm_item_code),
          twm_position_key = as.numeric(.data$twm_position_key)
        )
      , by = 'upc'
    )
  tictoc::toc()

  # Fetch UPC Lookup Table ----
  cat("Querying 'item_lookup'.... ")
  tictoc::tic()
  item_lookup <- cdmpLibrary::twm_item() %>%
    dplyr::rename(
      twm_item_code = .data$item_code,
      twm_position_key = .data$position_key,
      twm_item_name = .data$item_name,
      twm_package_type = .data$package_type,
      twm_brand_name = .data$brand_name
    ) %>%
    dplyr::mutate(
      twm_item_code = as.numeric(.data$twm_item_code),
      twm_posiiton_key = as.numeric(.data$twm_position_key)
    )
  tictoc::toc()

  # Left-Join 'market_sales' with 'item_lookup' ----
  cat("Joining 'market_sales' with 'item_lookup'")
  tictoc::tic()
  market_sales <- market_sales %>%
    dplyr::left_join(
      item_lookup %>%
        dplyr::select(
          .data$twm_item_code, .data$twm_position_key,
          .data$twm_item_name, .data$twm_package_type,
          .data$twm_brand_name
        )
      , by = c('twm_item_code', 'twm_position_key')
    ) %>%
    dplyr::arrange(dplyr::desc(.data$sales_dollars))
  tictoc::toc()

  # Return 'market_sales'
  return(market_sales)

}

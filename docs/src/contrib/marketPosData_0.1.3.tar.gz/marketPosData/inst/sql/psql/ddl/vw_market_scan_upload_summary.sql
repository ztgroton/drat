
CREATE VIEW vw_market_scan_upload_summary AS 
select 
msu.shop_party, 
msu.market_name, 
mkt.state, 
mkt.type as market_type,
msu.department, 
msu.week_ending, 
fu.id as file_id, 
msu.file_name, 
msu.upload_date, 

sum(msud.sales_dollars) as total_sales_dollars, 
sum(msud.sales_units) as total_sales_units,

count(msu.*) as record_count

from common.market_scan_upload_detail msud

inner join common.file_upload fu
on msud.file_id = fu.id 

inner join common.market_scan_upload msu 
on msud.market_name = msu.market_name 
and msud.shop_party = msu.shop_party 
and msud.department = msu.department 
and msud.week_ending = msu.week_ending 
and msud.file_name = msu.file_name 
and msud.upload_date = msu.upload_date 

inner join common.market mkt 
on msu.market_name = mkt.name 

inner join 
(

select 
t.market_name, 
t.shop_party, 
t.department, 
t.week_ending, 
max(t.upload_date) as upload_date

from common.market_scan_upload t

group by t.market_name, t.shop_party, t.department, t.week_ending
) latest_file 
on msu.market_name = latest_file.market_name 
and msu.shop_party = latest_file.shop_party 
and msu.department = latest_file.department 
and msu.week_ending = latest_file.week_ending 
and msu.upload_date = latest_file.upload_date 

group by 
msu.shop_party, 
msu.market_name, 
mkt.state, 
mkt.type,
msu.department, 
msu.week_ending, 
fu.id, 
msu.file_name, 
msu.upload_date;


#' Returns Current Mappings based on 'schema' and 'table'
#'
#' @importFrom rlang .data
#'
#' @param schema character - name of schema containing desired table
#' @param table character - name of desired table
#' @param use_dev logical - optionally specify if development database should be used.
#'
#' @return data.frame
#' @export
#'
vw_map_key <- function(schema, table, use_dev = FALSE) {

  # Validate Inputs
  if (missing(schema)) {stop("`schema` is missing in call to `vw_map_key`", call. = FALSE)}
  if (missing(table)) {stop("`table` is missing in call to `vw_map_key`", call. = FALSE)}
  if (missing(use_dev)) {use_dev <- FALSE}

  # Validate Input Expectations

  # * `schema`
  expect_scalar_char(obj = schema)

  # * `table`
  expect_scalar_char(obj = table)

  # * `use_dev`
  if (!isTRUE(identical(use_dev, TRUE)) && !isTRUE(identical(use_dev, FALSE))) {
    stop("`use_dev` must be identical to TRUE/FALSE in call to `vw_map_key`")
  }

  # MAIN LOGIC

  # Setup DB Connection
  if (isTRUE(identical(use_dev, TRUE))) {
    conn <- psql_db_connect('comp_map_lib_dev')
  } else {
    conn <- psql_db_connect('comp_map_lib_prod')
  }

  # * Validate `schema` against expected Shop Parties
  expected_schemas <- c('nlsn', 'iri', 'bst', 'twm', 'tws')
  if (!isTRUE(all(schema %in% expected_schemas))) {
    stop("`schema` must be a valid shop party in call to `vw_map_key`", call. = FALSE)
  }

  # # * Validate `table` against expected Mapping Types
  # expected_types <- c('upc_text', 'upc_num', 'item_name', 'party_product_id')
  # if (!isTRUE(all(table %in% expected_types))) {
  #   stop("`table` must be a valid mapping type in call to `vw_map_key`", call. = FALSE)
  # }

  # Check if 'table' exists in 'schema'
  if (isTRUE(table_exists(conn, schema, table))) {

    # 'DBI' Table ID
    table_qry <- glue::glue("
                            select t.*, mld.item_name
                            from {schema}.{table} t
                            left outer join map_library.map_lib_detail mld
                            on t.key_hash = mld.key_hash
                            and t.map_order = mld.map_order
                            ")

    # Generate Key Mappings
    tryCatch({

      key <- DBI::dbGetQuery(conn = conn, table_qry)
      map <- DBI::dbGetQuery(conn = conn, "select * from map_library.twm_map")

      res <- key %>%
        dplyr::left_join(map, by = 'map_hash') %>%
        dplyr::select(-.data$map_hash)

      if (isTRUE('competitor_hash' %in% colnames(res))) {
        competitor_map <- get_competitor()
        res <- res %>%
          dplyr::left_join(competitor_map, by = 'competitor_hash') %>%
          dplyr::select(-.data$competitor_hash) %>%
          dplyr::relocate(.data$competitor_name) %>%
          dplyr::rename_with(.fn = function(x){'competitor'}, .cols = .data$competitor_name)
      }

      DBI::dbDisconnect(conn)
      return(res)

    }, error = function(e) {
      DBI::dbDisconnect(conn)
      stop(sprintf("Error in %s: %s", deparse(e[["call"]]), e[["message"]]), call. = FALSE)
    })


  } else {
    DBI::dbDisconnect(conn)
    stop(paste0("table `", table, "` DOES NOT EXIST in schema `", schema, "` -  SKIPPING!!!"), call. = FALSE)
  }

}

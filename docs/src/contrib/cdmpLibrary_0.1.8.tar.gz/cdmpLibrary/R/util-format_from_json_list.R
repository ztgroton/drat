
#' Format Data Types for List Data resulting from JSONB Conversion
#'
#' @param from_list list
#' @param non_key_names character
#'
#' @return list
#' @export
#'
#' @examples
#' \dontrun{
#' output <- format_from_json_list(from_list = input_list)
#' }
format_from_json_list <- function(from_list, non_key_names) {

  # Validate Inputs
  if (missing(from_list)) {stop("`from_list` is missing in call to `format_from_json_list`")}
  if (missing(non_key_names)) {non_key_names <- sort(c('schema', 'table', 'map_order'))}

  # Validate Input Expectations

  # * non_key_names ----
  if (!isTRUE(is.character(non_key_names)) || !isTRUE(length(non_key_names) > 0)) {
    stop("`non_key_names` must be non_empty character vector in call to `format_from_json_list`")
  }

  # * from_list ----
  if(!isTRUE(is.list(from_list)) || !isTRUE(length(from_list) > 0)) {
    stop("`from_list` must be non-empty list in call to `format_from_json_list`")
  }

  # * names(from_list) ----
  if (!isTRUE(all(non_key_names %in% names(from_list)))) {
    stop("`non_key_names` must be a subset of `names(from_list)` in call to `format_from_json_list`")
  }

  input_key_names <- sort(setdiff(names(from_list), non_key_names))

  if (!isTRUE(all(input_key_names %in% unique(cdmpLibrary::valid_key_fields$field)))) {
    stop("`from_list` does not have valid `key_names` in call to `format_from_json_list`")
  }

  # MAIN LOGIC

  # Set Data Types for `non_key_names`
  from_list$schema <- as.character(from_list$schema)
  from_list$table <- as.character(from_list$table)
  from_list$map_order <- as.numeric(from_list$map_order)

  # Set Data Types for `key_names`
  if (isTRUE(from_list$table == 'party_product_id')) {
    from_list$party_product_id <- as.numeric(from_list$party_product_id)
  } else if (from_list$table == 'upc_num') {
    #from_list$upc <- as.numeric(from_list$upc)
    from_list$upc <- as.character(from_list$upc)
  } else {
    for (key in input_key_names) {
      from_list[[key]] <- as.character(from_list[[key]])
    }
  }

  # Return `from_list`
  return(as.data.frame(from_list))

}


#' Setup Competitive Mapping Library in Specified Empty Database
#'
#' @param conn DBIConnection
#' @param populate logical
#' @param trig_final logical
#'
#' @return TRUE
#' @export
#'
#' @examples
#' \dontrun{
#' setup_db(psql_conn)
#' }
setup_db <- function(conn, populate = TRUE, trig_final = TRUE) {

  # Validate Inputs
  if (missing(conn)) {stop("`conn` is missing in call to `setup_db`")}
  if (missing(populate)) {populate <- TRUE}
  if (missing(trig_final)) {trig_final <- TRUE}

  # Validate Input Expectations

  # * `conn`
  if (!isTRUE(inherits(conn, 'DBIConnection'))) {
    stop("`conn` must inherit from 'DBIConnection' in call to `setup_db`")
  }

  # * `populate`
  if (!isTRUE(identical(populate, TRUE)) && !isTRUE(identical(populate, FALSE))) {
    stop("`populate` must be identical to TRUE/FALSE in call to `setup_db`")
  }

  # * `trig_final`
  if (!isTRUE(identical(trig_final, TRUE)) && !isTRUE(identical(trig_final, FALSE))) {
    stop("`trig_final` must be identical to TRUE/FALSE in call to `setup_db`")
  }

  # * `trig_final`

  # SETUP SCHEMAS
  cat("Setting Up Schemas... ")
  tictoc::tic()
  setup_schemas(conn)
  tictoc::toc()

  # ENABLE PGCRYPTO MODULE
  cat("Enabling 'pgcrypto'... ")
  tictoc::tic()
  setup_pgcrypto(conn)
  tictoc::toc()

  # SETUP COMMON TABLES
  cat("\nSetting Up Common Tables... \n\n")
  tictoc::tic()
  setup_common_tables(conn)
  tictoc::toc()

  # SETUP MAPPING TABLES
  cat("\nSetting Up Mapping Tables... \n")
  tictoc::tic()
  setup_mapping_tables(conn)
  tictoc::toc()

  # ENABLE TRIGGERS - ONLY IF `trig_final == FALSE`
  if (!isTRUE(trig_final)) {
    cat("\nEnabling Triggers... ")
    tictoc::tic()
    init_trig(conn)
    tictoc::toc()
  }

  # POPULATING MAPPING TABLES
  cat("\nPopulating Mapping Tables... \n")
  tictoc::tic()
  upload_mapping_tables_from_archive(conn)
  tictoc::toc()

  if (isTRUE(populate)) {

    # POPULATING 'MAP LIB' TABLE
    cat("\nPopulating 'MAP LIB' Table... ")
    tictoc::tic()
    upload_table_from_archive(conn, 'map_library', 'map_lib')
    tictoc::toc()

    # POPULATING 'MAP LIB UPDATE' TABLE
    cat("\nPopulating 'MAP LIB UPDATE' Table... ")
    tictoc::tic()
    upload_table_from_archive(conn, 'map_library', 'map_lib_update')
    tictoc::toc()

    # RESET 'MAP LIB UPDATE' AUTO_INCREMENT ID
    cat("\nReset 'MAP LIB UPDATE' Auto-Increment... ")
    tictoc::tic()
    reset_map_lib_update_id(conn)
    tictoc::toc()

  }

  # ENABLE TRIGGERS - ONLY IF `trig_final == TRUE`
  if (isTRUE(trig_final)) {
    cat("\nEnabling Triggers... ")
    tictoc::tic()
    init_trig(conn)
    tictoc::toc()
  }

  # Return Success
  invisible(TRUE)

}


#' Fetch Table Contents of 'upload_files.file_log'
#'
#' @param use_dev logical
#'
#' @return data.frame
#' @export
#'
#' @examples
#' \dontrun{
#' output <- get_file_log()
#' }
get_file_log <- function(use_dev = FALSE) {

  # Validate Inputs
  if (missing(use_dev)) {use_dev <- FALSE}

  # Validate Input Expectations

  # * use_dev ----
  if (!isTRUE(identical(use_dev, TRUE)) && !isTRUE(identical(use_dev, FALSE))) {
    stop("`use_dev` must be TRUE/FALSE in call to `get_file_log`")
  }

  # MAIN LOGIC ----

  # Initialize SQL Query
  qry <- "select * from upload_files.file_log"

  # Setup DB Connection
  if (isTRUE(identical(use_dev, TRUE))) {
    conn <- psql_db_connect('comp_map_lib_dev')
  } else {
    conn <- psql_db_connect('comp_map_lib_prod')
  }

  # Exeucte SQL / Fetch Results ----
  results <- DBI::dbGetQuery(conn, qry)

  # Close DB Connection ----
  DBI::dbDisconnect(conn)
  rm(conn)

  # Return Results ----
  return(results)

}

#' Fetch Table Contents of 'upload_files.record_log'
#'
#' @param file_hash character
#' @param use_dev logical
#'
#' @return data.frame
#' @export
#'
#' @examples
#' \dontrun{
#' output <- get_record_log()
#' }
get_record_log <- function(file_hash, use_dev = FALSE) {

  # Validate Inputs
  if (missing(file_hash)) {stop("`file_hash` is missing in call to `get_record_log`")}
  if (missing(use_dev)) {use_dev <- FALSE}

  # Validate Input Expectations

  # * use_dev ----
  if (!isTRUE(identical(use_dev, TRUE)) && !isTRUE(identical(use_dev, FALSE))) {
    stop("`use_dev` must be TRUE/FALSE in call to `get_record_log`")
  }

  # * file_hash ----
  if (!isTRUE(is.character(file_hash)) || !isTRUE(length(file_hash) > 0) || isTRUE(any(is.na(file_hash)))) {
    stop("`file_hash` must be valid character vector in call to `get_record_log`")
  }

  # MAIN LOGIC ----

  # Setup DB Connection
  if (isTRUE(identical(use_dev, TRUE))) {
    conn <- psql_db_connect('comp_map_lib_dev')
  } else {
    conn <- psql_db_connect('comp_map_lib_prod')
  }

  # Initialize SQL Query
  qry <- glue::glue_sql("select t.* from upload_files.record_log t where t.file_hash IN ({file_hash*})", .con = conn)

  # Exeucte SQL / Fetch Results ----
  results <- DBI::dbGetQuery(conn, qry)

  # Close DB Connection ----
  DBI::dbDisconnect(conn)
  rm(conn)

  # Return Results ----
  return(results)

}

#' Fetch Upload File Records and Matches for later use
#'
#' @importFrom rlang .data
#' @importFrom utils combn
#'
#' @param use_dev logical
#'
#' @return list
#' @export
#'
#' @examples
#' \dontrun{
#' output <- get_record_match_log()
#' }
get_record_match_log <- function(use_dev = FALSE) {

  # Validate Inputs
  if (missing(use_dev)) {use_dev <- FALSE}

  # Validate Input Expectations

  # * use_dev ----
  if (!isTRUE(identical(use_dev, TRUE)) && !isTRUE(identical(use_dev, FALSE))) {
    stop("`use_dev` must be TRUE/FALSE in call to `get_record_match_log`")
  }

  # MAIN LOGIC ----

  # Setup DB Connection
  if (isTRUE(identical(use_dev, TRUE))) {
    conn <- psql_db_connect('comp_map_lib_dev')
  } else {
    conn <- psql_db_connect('comp_map_lib_prod')
  }

  # Initialize 'file_log'
  cat("Initializing 'file_log'... ")
  tictoc::tic()
  file_log <- get_file_log()
  tictoc::toc()

  # Initialize 'item_lookup'
  cat("Initializing 'item_lookup'... ")
  tictoc::tic()
  item_lookup <- twm_item()
  tictoc::toc()

  # Iterate over 'file_log'
  cat("Iterating over 'file_log'... \n")
  results <- purrr::map(file_log$file_hash, function(x) {

    x_label <- paste(
      file_log %>% dplyr::filter(.data$file_hash == x) %>% dplyr::pull(.data$name),
      file_log %>% dplyr::filter(.data$file_hash == x) %>% dplyr::pull(.data$shop_party),
      file_log %>% dplyr::filter(.data$file_hash == x) %>% dplyr::pull(.data$upload_dt),
      sep = ' - '
    )

    cat(paste0("[", x_label, "]... "))
    tictoc::tic()

    x_records <- get_record_log(file_hash = x, use_dev = use_dev)
    x_matches <- vw_file_matches(file_hash = x, use_dev = use_dev) # item_detail = item_lookup

    # Join Records and Matches by 'orig_row_num'
    x_result <- x_records %>% dplyr::left_join(x_matches, by = 'orig_row_num')

    # Join 'x_result' with 'file_log' using 'file_hash'
    x_result <- x_result %>%
      dplyr::inner_join(
        file_log %>%
          dplyr::rename(
            file_name = .data$name,
            file_upload_dt = .data$upload_dt
          )
        , by = 'file_hash'
      ) %>%
      dplyr::relocate(
        .data$file_name,
        .data$file_upload_dt,
        .data$shop_party
      )

    # Remove 'file_hash' and 'record_hash' from 'x_result'
    x_result <- x_result %>% dplyr::select(-.data$file_hash, -.data$record_hash)

    tictoc::toc()
    return(x_result)

  })
  names(results) <- paste(file_log$name, file_log$shop_party, file_log$upload_dt, sep = ' - ')

  # Merge Results into single data.frame
  results <- as.data.frame(data.table::rbindlist(results))

  # Return Results
  return(results)

}


#' Query Data from an existing EDAP PSQL table
#'
#' @param db character - name of the database containing desired table
#' @param schema character - name of schema containing desired table
#' @param table character - name of desired table
#'
#' @return data.frame
#'
get_table_data <- function(db, schema, table) {

  if (missing(db)) {stop("`db` is missing in call to `get_table_data`", call. = FALSE)}
  if (missing(schema)) {stop("`schema` is missing in call to `get_table_data`", call. = FALSE)}
  if (missing(table)) {stop("`table` is missing in call to `get_table_data`", call. = FALSE)}

  db_conn <- dbTools::psql_db_connect(db)
  table_qry <- glue::glue_sql(
    "select * from {`schema`}.{`table`}",
    .con = db_conn
  )

  res <- DBI::dbGetQuery(db_conn, table_qry)

  DBI::dbDisconnect(db_conn)
  rm(db_conn)

  return(res)

}

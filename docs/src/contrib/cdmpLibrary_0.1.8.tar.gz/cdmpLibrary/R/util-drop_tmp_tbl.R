
#' Upload R Data.Frame to PSQL Table in 'public' schema
#'
#' @param name character
#'
#' @return TRUE
#' @export
#'
#' @examples
#' \dontrun{
#' drop_tmp_tbl('testfile')
#' }
drop_tmp_tbl <- function(name) {

  # Validate Inputs
  if (missing(name)) {stop("`name` is missing in call to `drop_tmp_tbl`")}

  # Validate Input Expectations

  # * `name`
  if (!isTRUE(is.character(name)) || !isTRUE(length(name) == 1) || !isFALSE(is.na(name))) {
    stop("`name` must be Non-NA length 1 character vector in call to `drop_tmp_tbl`")
  }

  # Initialize Query Template
  qry <- "DROP TABLE IF EXISTS public.{`name`}"

  # Setup DB Connection
  psql_conn <- psql_db_connect('comp_map_lib_prod')

  tryCatch({

    # Bind Parameter Values to Query
    qry <- glue::glue_sql(qry, .con = psql_conn)

    # Execute SQL Query
    DBI::dbExecute(psql_conn, qry)

    # Close DB Connection
    DBI::dbDisconnect(psql_conn)
    rm(psql_conn)

    # Return Success
    invisible(TRUE)

  }, error = function(e) {

    # Close DB Connection
    DBI::dbDisconnect(psql_conn)
    rm(psql_conn)

    # Stop with Error
    stop(sprintf("Error in %s: %s", deparse(e[["call"]]), e[["message"]]))

  })

}


#' Construct an Empty S3 Object of class 'cdmp_shop_key'
#'
#' @return S3 Object
#'
new_cdmp_shop_key <- function() {

  # Define Class Environment
  rs <- new.env()

  # Define Class Members
  rs$valid_key <- get_cdmp_valid_key_fields()
  rs$valid_type <- get_cdmp_valid_key_field_types()
  rs$template <- NULL
  rs$data <- new.env()

  # Update Class Path
  class(rs) <- c(setdiff('cdmp_shop_key', class(rs)), class(rs))

  # Return Object
  return(rs)

}

#' Get Valid Keys in CDMP Library as character vector
#'
#' @importFrom rlang .data
#'
#' @return character vector
#'
get_cdmp_valid_keys <- function() {

  psql_conn <- psql_db_connect('comp_map_lib_prod')
  qry <- "select distinct name from map_library.valid_key"
  res <- DBI::dbGetQuery(psql_conn, qry) %>% dplyr::pull(.data$name)

  DBI::dbDisconnect(psql_conn)
  rm(psql_conn)

  return(res)

}

#' Get Valid Key Fields in CDMP Library as character vector
#'
#' @importFrom rlang .data
#'
#' @return character vector
#'
get_cdmp_valid_key_fields <- function() {

  psql_conn <- psql_db_connect('comp_map_lib_prod')
  qry <- "select key, field from map_library.valid_key_field"
  data <- DBI::dbGetQuery(psql_conn, qry)

  key_vals <- sort(unique(data$key))
  res <- lapply(key_vals, function(key_val) {

    data %>%
      dplyr::filter(.data$key == key_val) %>%
      dplyr::pull(.data$field)

  })
  names(res) <- key_vals

  DBI::dbDisconnect(psql_conn)
  rm(psql_conn)

  return(res)

}

#' Get Data Types for Valid Key Fields in CDMP Library as character vector
#'
#' @importFrom rlang .data
#'
#' @return character vector
#'
get_cdmp_valid_key_field_types <- function() {

  psql_conn <- psql_db_connect('comp_map_lib_prod')
  qry <- "select * from map_library.valid_key_field"
  data <- DBI::dbGetQuery(psql_conn, qry)

  key_vals <- sort(unique(data$key))
  res <- lapply(key_vals, function(key_val) {

    types <- data %>%
      dplyr::filter(.data$key == key_val) %>%
      dplyr::pull(.data$type)

    fields <- data %>%
      dplyr::filter(.data$key == key_val) %>%
      dplyr::pull(.data$field)

    names(types) <- fields
    types

  })
  names(res) <- key_vals

  DBI::dbDisconnect(psql_conn)
  rm(psql_conn)

  return(res)

}

#' Get Valid Schema Names
#'
#' @return character vector
#'
get_valid_schema_names <- function() {

  psql_conn <- psql_db_connect('comp_map_lib_prod')
  qry <- "SELECT schema_name FROM information_schema.schemata;"
  data <- suppressMessages({DBI::dbGetQuery(psql_conn, qry)})

  DBI::dbDisconnect(psql_conn)
  rm(psql_conn)

  invalid_schemas <- c('pg_catalog', 'information_schema', 'public', 'map_library', 'upload_files', 'upload_matches')
  valid_schemas <- setdiff(data$schema_name, invalid_schemas)

  return(valid_schemas)

}

#' GEt Valid Mappings for a Schema
#'
#' @param sch character - schema name
#'
#' @return character vector
#'
get_valid_schema_keys <- function(sch) {

  # Validate Inputs
  if (missing(sch)) {sch <- get_valid_schema_names()}

  # Validate Input Expectations

  # * `sch`
  valid_schemas <- get_valid_schema_names()
  if (!isTRUE(length(sch) > 0) || !isTRUE(all(sch %in% valid_schemas))) {
    stop("`sch` must be a valid schema name in call to `get_valid_schema_keys`")
  }

  # Setup Connection to PSQL
  psql_conn <- psql_db_connect('comp_map_lib_prod')

  # Prepare SQL Query
  qry <- glue::glue_sql(
    "select distinct table_name FROM information_schema.tables where table_schema IN ({sch*})",
    .con = psql_conn
  )

  # Fetch Results
  result <- suppressMessages(DBI::dbGetQuery(psql_conn, qry))
  result <- result %>% dplyr::distinct(.data$table_name) %>% dplyr::pull(.data$table_name)

  # Close Connection to PSQL
  DBI::dbDisconnect(psql_conn)
  rm(psql_conn)

  # Return Results
  return(result)

}

#' Validate that 'obj' is properly formatted S3 Object of class 'cdmp_shop_key'
#'
#' @param obj S3 Object
#' @param bool TRUE/FALSE - indicates if function should invisibly return 'obj' or 'TRUE/FALSE'
#'
#' @return S3 Object, TRUE/FALSE
#'
validate_cdmp_shop_key <- function(obj, bool) {

  # Validate Inputs
  if (missing(obj)) {stop("`obj` is missing in call to `validate_cdmp_shop_key`", call. = FALSE)}
  if (missing(bool)) {bool <- FALSE}

  # Validate Input Expectations
  expect_env(obj, c('valid_key', 'valid_type', 'template', 'data'))
  expect_scalar_logical(bool)

  # * valid_key
  obj$valid_key <- get_cdmp_valid_key_fields()
  expect_list(obj$valid_key, type = 'character')

  # * valid_type
  obj$valid_type <- get_cdmp_valid_key_field_types()
  expect_list(obj$valid_key, type = 'character')

  # * template
  if (!isTRUE(is.null(obj$template))) {
    expect_list(obj$template, type = 'character')
    template_names <- purrr::map(names(obj$template), ~ names(obj$template[[.]]))
    expect_list_equal(obj1 = obj$valid_key, obj2 = template_names, type = 'character')
  }

  # * data
  data_names <- unique(intersect(names(obj$data), get_cdmp_valid_keys()))
  valid_key_fields <- get_cdmp_valid_key_fields()

  for (data_name in data_names) {

    has_competitor <- isTRUE('competitor' %in% colnames(obj$data[[data_name]]))
    if (isTRUE(has_competitor)) {
      expected_columns <- c('_ORIG_ROW_NUMBER_', 'competitor', valid_key_fields[[data_name]], 'twm_item_code', 'twm_position_key')
    } else {
      expected_columns <- c('_ORIG_ROW_NUMBER_', valid_key_fields[[data_name]], 'twm_item_code', 'twm_position_key')
    }

    expect_data_frame(df = obj$data[[data_name]], columns = expected_columns)

  }

  # Return Result
  if (isTRUE(bool)) {return(TRUE)}
  else {invisible(obj)}

}

#' Initialize an S3 Object of class 'cdmp_shop_key'
#'
#' @return S3 Object
#' @export
#'
cdmp_shop_key <- function() {

  new_cdmp_shop_key() %>% validate_cdmp_shop_key()

}


#' S3 Generic - Validate that 'obj' has valid cdmp keys
#'
#' @param obj R Object - expected S3 class 'cdmp_shop_key'
#'
#' @return TRUE/FALSE
#' @export
#'
refresh_valid_key <- function(obj) {UseMethod("refresh_valid_key", obj)}


#' S3 Generic - Validate if 'test_obj' satisfies key template of 'obj'
#'
#' @param obj R Object - expected S3 class 'cdmp_shop_key'
#' @param x list - named list with character vector elements
#' @param bool TRUE/FALSE - specifies whether original value should be returned on success or TRUE
#'
#' @return TRUE/FALSE
#' @export
#'
validate_template <- function(obj, x, bool) {UseMethod("validate_template", obj)}

#' S3 Generic - Generate Key Values for S3 Object of class 'cdmp_shop_key'
#'
#' @param obj S3 Object of class 'cdmp_shop_key'
#' @param data data.frame - raw cdmp shop data
#' @param competitor character - name of column specifying 'competitor'
#'
#' @return NULL
#' @export
#'
generate_key <- function(obj, data, competitor) {UseMethod("generate_key", obj)}

#' S3 Generic - Map Key Values for S3 Object of class 'cdmp_shop_key'
#'
#' @param obj S3 Object of class 'cdmp_shop_key'
#' @param shop_party character - specified 'shop_party'/schema
#' @param competitor character - name of column specifying 'competitor'
#'
#' @return NULL
#' @export
#'
map_key <- function(obj, shop_party, competitor) {UseMethod("map_key", obj)}

#' S3 Generic - Upsert Key Values for S3 Object of class 'cdmp_shop_key'
#'
#' @param obj S3 Object of class 'cdmp_shop_key'
#' @param shop_party character - specified 'shop_party'/schema
#' @param file_name character
#' @param file_hash character
#'
#' @return NULL
#' @export
#'
upsert_key <- function(obj, shop_party, file_name, file_hash) {UseMethod("upsert_key", obj)}

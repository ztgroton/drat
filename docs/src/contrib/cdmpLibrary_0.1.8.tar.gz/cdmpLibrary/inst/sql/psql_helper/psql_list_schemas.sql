
select schema_name
from information_schema.schemata
where schema_name NOT IN ('information_schema', 'pg_catalog')

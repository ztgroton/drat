
select

rml.file_hash,
fl.name as file_name,
fl.shop_party,
fl.upload_dt as file_upload_dt,

rml.orig_row_num,
rml.match_type,

ml.key_jsonb,
ml.map_order,

tm.twm_item_code,
tm.twm_position_key

from upload_files.record_match_log rml

inner join upload_files.file_log fl
on rml.file_hash = fl.file_hash

left outer join map_library.map_lib ml
on rml.key_hash = ml.key_hash

left outer join map_library.twm_map tm
on rml.map_hash = tm.map_hash

where fl.file_hash = {file_hash}

order by fl.upload_dt desc, rml.orig_row_num

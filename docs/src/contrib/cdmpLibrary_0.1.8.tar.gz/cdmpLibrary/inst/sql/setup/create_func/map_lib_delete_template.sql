
CREATE OR REPLACE FUNCTION public.map_lib_delete_template(sch TEXT, tbl TEXT)
  RETURNS TEXT
  LANGUAGE PLPGSQL
AS $$
DECLARE

  result TEXT;

BEGIN

  -- Build SELECT statement to generate key values
  SELECT format(
    CONCAT(
      'WITH old_record AS ( ',
      'select '::TEXT,
      public.pk_col_hash(sch::TEXT, tbl::TEXT)::TEXT, ' as key_hash, ',
      public.pk_col_jsonb(sch::TEXT, tbl::TEXT)::TEXT, ' as key_jsonb, ',
      't.map_order, ',
      't.map_hash, ',
      't.is_primary ',
      'from old_table t ',
      ') ',
      'DELETE FROM map_library.map_lib ml ',
      'USING old_record ',
      'WHERE ml.key_hash = old_record.key_hash ',
      'AND ml.map_order = old_record.map_order '
    )::TEXT
  ) INTO result;

  -- Return Result
  RETURN result;

END;
$$

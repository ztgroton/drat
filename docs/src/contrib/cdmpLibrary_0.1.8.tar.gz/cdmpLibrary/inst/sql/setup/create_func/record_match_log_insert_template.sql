
CREATE OR REPLACE FUNCTION public.record_match_log_insert_template(tbl TEXT, file_hash TEXT, map_schema TEXT, map_table TEXT)
  RETURNS TEXT
  LANGUAGE PLPGSQL
AS $$
DECLARE

  result TEXT;

BEGIN

  -- Build SELECT statement to generate key values
  result := CONCAT(
    'insert into upload_files.record_match_log (file_hash, orig_row_num, match_type, key_hash, map_hash) ',
    'select '::TEXT,
    format('%L as file_hash, ', file_hash::TEXT)::TEXT, -- file_hash::TEXT
    't.orig_row_num, '::TEXT,
    format('%L as match_type, ', map_table::TEXT)::TEXT, -- map_table::TEXT
    public.pk_col_hash(map_schema::TEXT, map_table::TEXT, TRUE)::TEXT, ' as key_hash, ',
    't.map_hash '::TEXT,
    format('from public.%I t ', tbl::TEXT)
  );

  -- Return Result
  RETURN result;

END;
$$

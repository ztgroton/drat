
CREATE OR REPLACE FUNCTION public.all_col_template(schema_val TEXT, table_val TEXT) 
  RETURNS TEXT
  LANGUAGE PLPGSQL
AS $$
DECLARE 
  
  tpcols TEXT[];
  result TEXT;
  
BEGIN 
  
  -- Insert Table Columns into Text Array
  tpcols := ARRAY(
    SELECT CONCAT('t.'::TEXT, c.column_name)::TEXT 
    
    FROM information_schema.columns c
    
    INNER JOIN information_schema.tables t 
    ON t.table_name = c.table_name 
    AND t.table_schema = c.table_schema 
    AND t.table_catalog = c.table_catalog
    
    WHERE c.table_schema = schema_val 
    AND c.table_name = table_val 
    AND t.table_type = 'BASE TABLE' 
    
    ORDER BY t.table_schema, t.table_name, c.ordinal_position
  );
  
  -- Convert Text Array into Comma-Separated String
  SELECT CONCAT(ARRAY_TO_STRING(tpcols, ', '), ', ') INTO result;
  
  -- Return Result 
  RETURN result;
  
END; 
$$


CREATE TRIGGER map_lib_update_trigger_insert AFTER INSERT  
ON map_library.map_lib REFERENCING NEW TABLE AS new_table
FOR EACH STATEMENT EXECUTE PROCEDURE public.log_map_lib_update();


CREATE OR REPLACE FUNCTION public.map_lib_update_template(sch TEXT, tbl TEXT)
  RETURNS TEXT
  LANGUAGE PLPGSQL
AS $$
DECLARE

  join_clause TEXT;
  result TEXT;

BEGIN

  select
  CONCAT('on ', STRING_AGG(CONCAT('t.', t, ' = o.', t), ' and '), ' ')
  into join_clause
  from unnest(public.pk_tbl_columns(sch::TEXT, tbl::TEXT)) t;

  -- Build SELECT statement to generate key values
  SELECT format(
    CONCAT(
      'WITH new_record AS ( ',
      'select '::TEXT,
      public.pk_col_hash(sch::TEXT, tbl::TEXT)::TEXT, ' as key_hash, ',
      public.pk_col_jsonb(sch::TEXT, tbl::TEXT)::TEXT, ' as key_jsonb, ',
      't.map_order, ',
      't.map_hash, ',
      't.is_primary ',
      'from new_table t ',
      'inner join old_table o ',
      join_clause,
      --'where (t.map_hash != o.map_hash) OR (t.is_primary != o.is_primary) ',
      ') ',
      'UPDATE map_library.map_lib ml ',
      'SET map_hash = new_record.map_hash, map_order = new_record.map_order ',
      'FROM new_record ',
      'WHERE ml.key_hash = new_record.key_hash ',
      'AND ml.map_order = new_record.map_order '
    )::TEXT
  ) INTO result;

  -- Return Result
  RETURN result;

END;
$$

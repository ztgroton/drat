
CREATE OR REPLACE PROCEDURE public.map_table_rebuild(map_schema TEXT, map_table TEXT)
LANGUAGE plpgsql SECURITY DEFINER
AS $$
DECLARE

  template_txt TEXT;

BEGIN

  -- Initialize 'template_text'
  select public.map_table_rebuild_template(map_schema::TEXT, map_table::TEXT) into template_txt;

  -- Execute SQL Commands in 'template_txt'
  EXECUTE template_txt;

END
$$


dbx::dbxUpsert(
  conn = comp_map_lib_prod,
  table = DBI::Id(schema = 'map_library', table = 'map_lib_detail'),
  records = latest_total_iri_sales %>% dplyr::select(key_hash, map_order, item_name, sales_dollars),
  where_cols = c('key_hash', 'map_order'),
  batch_size = 10000,
  skip_existing = FALSE
)


test <- DBI::dbGetQuery(
  conn = comp_map_lib_prod,
  "
  select count(t.*)
  from iri.upc_num t
  inner join map_library.map_lib_detail d
  on t.key_hash = d.key_hash
  and t.map_order = d.map_order
  "
)

DBI::dbExecute(
  conn = comp_map_lib_prod,
  "
  delete from iri.upc_num t where t.key_hash NOT IN (select distinct key_hash from map_library.map_lib_detail)
  "
)


CREATE OR REPLACE FUNCTION public.tmp_col_hash(data TEXT, sch TEXT DEFAULT NULL, tbl TEXT DEFAULT NULL, comp TEXT DEFAULT NULL)
  RETURNS TEXT
  LANGUAGE PLPGSQL
AS $$
DECLARE

  jsonb_txt TEXT;
  result TEXT;

BEGIN

  -- Call 'public.tmp_col_jsonb'
  SELECT public.tmp_col_jsonb(data, sch, tbl) INTO jsonb_txt;

  -- Create JSONB Element Template from input Column text value
  SELECT CONCAT('encode(public.digest('::TEXT, jsonb_txt::TEXT, '::TEXT, ''sha256''), ''hex'')'::TEXT) INTO result;

  -- Return Result
  RETURN result;

END;
$$


-- jsonb_template -> primary key support
-- pk_col_jsonb -> primary key support
-- record_jsonb -> EXCLUDED COLUMN support
-- tmp_col_jsonb -> 'competitor' support ,  'data' table support


CREATE OR REPLACE FUNCTION public.table2jsonb_cmd(
  sch TEXT,
  tbl TEXT,
  pk_only BOOLEAN DEFAULT FALSE,
  exclude_file_columns BOOLEAN DEFAULT FALSE,
  data_tbl TEXT DEFAULT NULL,
  log_tbl BOOLEAN DEFAULT FALSE,
  comp TEXT DEFAULT NULL
)
  RETURNS TEXT
  LANGUAGE PLPGSQL
AS $$
DECLARE

  tpcols TEXT[];
  result TEXT;

BEGIN

  -- Insert Primary Key Columns into Text Array
  SELECT public.col2array(sch, tbl, TRUE, pk_only, exclude_file_columns, data_tbl) into tpcols;

  IF (log_tbl = TRUE) THEN
    IF (sch IS NULL or tbl IS NULL) THEN
      RAISE EXCEPTION 'schema and table must both be specified when log_tbl is TRUE';
    ELSE
      tpcols := array_append(tpcols, CONCAT('''schema'', '''::TEXT, sch::TEXT, ''''::TEXT));
      tpcols := array_append(tpcols, CONCAT('''table'', '''::TEXT, tbl::TEXT, ''''::TEXT));
    END IF;
  END IF;

  IF (comp IS NOT NULL) THEN
    tpcols := array_append(tpcols, CONCAT('''competitor'', '''::TEXT, comp::TEXT, ''''::TEXT));
  END IF;

  -- Create JSONB Element Template from input Column text value
  SELECT CONCAT('jsonb_build_object('::TEXT, ARRAY_TO_STRING(tpcols, ', ')::TEXT, ')'::TEXT) INTO result;

  -- Return Result
  RETURN result;

END;
$$

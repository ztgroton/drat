
CREATE OR REPLACE FUNCTION public.map_lib_insert_template(sch TEXT, tbl TEXT)
  RETURNS TEXT
  LANGUAGE PLPGSQL
AS $$
DECLARE

  result TEXT;

BEGIN

  -- Build SELECT statement to generate key values
  SELECT format(
    CONCAT(
      'insert into map_library.map_lib (key_hash, key_jsonb, map_order, map_hash, is_primary)',
      'select '::TEXT,
      public.pk_col_hash(sch::TEXT, tbl::TEXT)::TEXT, ' as key_hash, ',
      public.pk_col_jsonb(sch::TEXT, tbl::TEXT)::TEXT, ' as key_jsonb, ',
      't.map_order, ',
      't.map_hash, ',
      't.is_primary '
      'from new_table t '
      'on conflict do nothing '
    )::TEXT
  ) INTO result;

  -- Return Result
  RETURN result;

END;
$$

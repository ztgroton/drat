
CREATE OR REPLACE FUNCTION public.tmp_col_jsonb(data TEXT, sch TEXT DEFAULT NULL, tbl TEXT DEFAULT NULL, comp TEXT DEFAULT NULL)
  RETURNS TEXT
  LANGUAGE PLPGSQL
AS $$
DECLARE

  tpcols TEXT[];
  result TEXT;

BEGIN

  -- Insert Primary Key Columns into Text Array
  tpcols := ARRAY(

    SELECT CONCAT(''''::TEXT, c.column_name::TEXT, ''', t."'::TEXT, c.column_name::TEXT, '"')::TEXT

    FROM information_schema.columns c

    INNER JOIN information_schema.tables t
    ON t.table_name = c.table_name
    AND t.table_schema = c.table_schema
    AND t.table_catalog = c.table_catalog

    WHERE c.table_schema = 'public'
    AND c.table_name = data
    AND t.table_type = 'BASE TABLE'

    ORDER BY t.table_schema, t.table_name, c.ordinal_position
  );

  IF ((sch IS NOT NULL) AND (tbl IS NOT NULL)) THEN
    tpcols := array_append(tpcols, CONCAT('''schema'', '''::TEXT, sch::TEXT, ''''::TEXT));
    tpcols := array_append(tpcols, CONCAT('''table'', '''::TEXT, tbl::TEXT, ''''::TEXT));
  END IF;

  IF (comp IS NOT NULL) THEN
    tpcols := array_append(tpcols, CONCAT('''competitor'', '''::TEXT, comp::TEXT, ''''::TEXT));
  END IF;

  -- Create JSONB Element Template from input Column text value
  SELECT CONCAT('jsonb_build_object('::TEXT, ARRAY_TO_STRING(tpcols, ', ')::TEXT, ')'::TEXT) INTO result;

  -- Return Result
  RETURN result;

END;
$$


CREATE OR REPLACE FUNCTION public.pk_col_jsonb(sch TEXT, tbl TEXT, log_tbl BOOLEAN DEFAULT TRUE)
  RETURNS TEXT
  LANGUAGE PLPGSQL
AS $$
DECLARE

  tpcols TEXT[];
  result TEXT;

BEGIN

  -- Insert Primary Key Columns into Text Array
  tpcols := ARRAY(

    SELECT CONCAT(''''::TEXT, c.column_name::TEXT, ''', t.'::TEXT, c.column_name::TEXT)::TEXT

    FROM information_schema.columns c

    INNER JOIN information_schema.tables t
    ON t.table_name = c.table_name
    AND t.table_schema = c.table_schema
    AND t.table_catalog = c.table_catalog

    INNER JOIN  -- primary keys
    (
      SELECT DISTINCT
      tc.constraint_name, tc.table_name, tc.table_schema, tc.table_catalog, kcu.column_name
      FROM information_schema.table_constraints AS tc
      JOIN information_schema.key_column_usage AS kcu
      ON tc.constraint_name = kcu.constraint_name
      WHERE constraint_type = 'PRIMARY KEY'
    ) pk
    ON pk.table_name = c.table_name
    AND pk.column_name = c.column_name
    AND pk.table_schema = c.table_schema
    AND pk.table_catalog = c.table_catalog

    WHERE c.table_schema = sch
    AND c.table_name = tbl
    AND t.table_type = 'BASE TABLE'

    ORDER BY t.table_schema, t.table_name, c.ordinal_position
  );

  IF (log_tbl = TRUE) THEN
    tpcols := array_append(tpcols, CONCAT('''schema'', '''::TEXT, sch::TEXT, ''''::TEXT));
    tpcols := array_append(tpcols, CONCAT('''table'', '''::TEXT, tbl::TEXT, ''''::TEXT));
  END IF;

  -- Create JSONB Element Template from input Column text value
  SELECT CONCAT('jsonb_build_object('::TEXT, ARRAY_TO_STRING(tpcols, ', ')::TEXT, ')'::TEXT) INTO result;

  -- Return Result
  RETURN result;

END;
$$

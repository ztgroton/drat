
test_that("`schema_exists` works", {
  expect_true(schema_exists(psql_db_connect('comp_map_lib_prod'), 'map_library'))
  expect_true(schema_exists(psql_db_connect('comp_map_lib_prod'), 'upload_files'))
  # expect_true(schema_exists(psql_db_connect('comp_map_lib'), 'upload_matches'))
  # expect_true(schema_exists(psql_db_connect('comp_map_lib'), 'nlsn'))
  # expect_true(schema_exists(psql_db_connect('comp_map_lib'), 'iri'))
  # expect_true(schema_exists(psql_db_connect('comp_map_lib'), 'bst'))
  # expect_true(schema_exists(psql_db_connect('comp_map_lib'), 'twm'))
  # expect_true(schema_exists(psql_db_connect('comp_map_lib'), 'tws'))
})

test_that("`table_exists` works", {
  expect_true(table_exists(psql_db_connect('comp_map_lib_prod'), 'map_library', 'map_lib'))
  expect_true(table_exists(psql_db_connect('comp_map_lib_prod'), 'map_library', 'map_lib_update'))
  # expect_true(table_exists(psql_db_connect('comp_map_lib'), 'map_library', 'twm_map'))
  # expect_true(table_exists(psql_db_connect('comp_map_lib'), 'map_library', 'competitor'))
})


#' Setup 'Common Table' Schema for Competitor Mapping Library
#'
#' @param dbname character - Name of existing PSQL Database
#'
#' @return TRUE
#'
#' @examples
#' \dontrun{
#' setup_upload_files_schema('comp_map_lib_prod')
#' }
setup_upload_files_schema <- function(dbname) {

  # Validate Inputs
  if (missing(dbname)) {dbname <- 'comp_map_lib_prod'}

  # Validate Input Expectations
  dbTools::expect_scalar_char(dbname)

  # Setup Connection
  conn <- dbTools::psql_db_connect(dbname)

  # SETUP SCHEMA

  # SETUP TABLES

  # * `upload_files.file_log`
  cat("Creating `upload_files.file_log`... ")
  tictoc::tic()
  create_file_log_table(conn)
  tictoc::toc()

  # * `upload_files.record_log`
  cat("Creating `upload_files.record_log`... ")
  tictoc::tic()
  create_record_log_table(conn)
  tictoc::toc()

  # * `upload_files.record_match_log`
  cat("Creating `upload_files.record_match_log`... ")
  tictoc::tic()
  create_record_match_log_table(conn)
  tictoc::toc()

  # Close Connection
  DBI::dbDisconnect(conn)
  rm(conn)

  # Return Success
  return(TRUE)

}

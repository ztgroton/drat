
#' Fetch Item-UPC Lookup Table from 'EDAP - edw'
#'
#' @param conn DBIConnection
#'
#' @return data.frame
#' @export
#'
#' @examples
#' \dontrun{
#' output <- refresh_twm_item_upc()
#' }
refresh_twm_item_upc <- function(conn) {

  # Validate Inputs
  if (missing(conn)) {stop("`conn` is missing in call to `refresh_twm_item_upc`")}

  # Setup Connection to 'EDW - conn_edw'
  conn_edw <- dbTools::bqsql_db_connect('edw')

  # Fetch SQL Query
  qry <- readr::read_file(system.file("sql/edw/dql/twm_item_upc.sql", package = 'cdmpLibrary'))

  # Execute SQL Query / Fetch Results
  results <- suppressMessages({DBI::dbGetQuery(conn_edw, qry)})

  # Close Connection to 'EDAP - edw'
  DBI::dbDisconnect(conn_edw)
  rm(conn_edw)

  # Initialize Table Id
  table_id <- DBI::Id(schema = 'map_library', table = "twm_item_upc")

  # Drop Table if Exists
  suppressMessages({DBI::dbExecute(conn = conn, glue::glue("DROP TABLE IF EXISTS map_library.twm_item_upc"))})

  # Create Table
  #message(paste0("\ncreating table `map_library.twm_item_upc`..."))
  suppressMessages({DBI::dbCreateTable(conn = conn, name = table_id, fields = results)})

  # Clear Existing Table Contents
  #message("\nclearing table contents...")
  suppressMessages({DBI::dbExecute(conn, "DELETE FROM map_library.twm_item_upc WHERE TRUE")})

  # Refresh Table Contents
  #message("\nupdating table contents...")
  suppressMessages({

    dbx::dbxInsert(
      conn = conn,
      table = table_id,
      records = results,
      batch_size = 1000000
    )

  })

  # Return Results
  invisible(results)

}

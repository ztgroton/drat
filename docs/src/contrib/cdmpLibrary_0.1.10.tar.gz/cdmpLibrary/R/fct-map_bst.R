
#' Helper Function for Mapping Costco Basket Data
#'
#' @param data data.frame - contains the raw data to be mapped
#' @param upc character - name of column containing UPCs
#' @param item_name character - name of column containing Item Names
#' @param basket_product_id character - name of column containing Basket Product IDs
#'
#' @return TRUE
#' @export
#'
#' @examples
#' \dontrun{
#' map_bst(raw_bst_data, upc, item_name, basket_product_id)
#' }
map_bst <- function(data, upc, item_name, basket_product_id) {

  # Validate Inputs
  if (missing(data)) {stop("`data` is missing in call to `map_bst`")}
  if (missing(upc)) {upc <- NULL}
  if (missing(item_name)) {item_name <- NULL}
  if (missing(basket_product_id)) {basket_product_id <- NULL}

  # Initialize `data` variable name
  data_name <- deparse(substitute(data))

  # Validate Input Expectations

  # * `data`
  if (!isTRUE(is.data.frame(data))) {
    stop("`data` must be type 'data.frame' in call to `map_bst`")
  }

  # * `upc`
  is_char <- isTRUE(is.character(upc))
  is_len1 <- isTRUE(length(upc) == 1)
  is_colname <- isTRUE(upc %in% colnames(data))
  if (!isTRUE(is_char) || !isTRUE(is_len1) || !isTRUE(is_colname)) {
    stop("`upc` must be single column name of `data` in call to `map_bst`")
  }

  # * `item_name`
  is_char <- isTRUE(is.character(item_name))
  is_len1 <- isTRUE(length(item_name) == 1)
  is_colname <- isTRUE(item_name %in% colnames(data))
  if (!isTRUE(is_char) || !isTRUE(is_len1) || !isTRUE(is_colname)) {
    stop("`item_name` must be single column name of `data` in call to `map_bst`")
  }

  # * `basket_product_id`
  is_char <- isTRUE(is.character(basket_product_id))
  is_len1 <- isTRUE(length(basket_product_id) == 1)
  is_colname <- isTRUE(basket_product_id %in% colnames(data))
  if (!isTRUE(is_char) || !isTRUE(is_len1) || !isTRUE(is_colname)) {
    stop("`basket_product_id` must be single column name of `data` in call to `map_bst`")
  }

  # * `data_name`
  is_char <- isTRUE(is.character(data_name))
  is_len1 <- isTRUE(length(data_name) == 1)
  is_non_na <- isTRUE(!is.na(data_name))
  if (!isTRUE(is_char) || !isTRUE(is_len1) || !isTRUE(is_non_na)) {
    stop("`data_name` must be non-na length 1 character in call to `map_bst`")
  }

  cat("BST...\n\n")

  # Initialize Empty S3 Object of class 'cdmp_shop_data'
  bst_shop <- cdmp_shop_data()

  # Load `data` into `bst_shop`
  load_file(obj = bst_shop, name = data_name, data = data)

  # Set 'Shop Party' as 'nlsn'
  set_shop_party(obj = bst_shop, shop_party = 'bst')

  # Set Key Template
  bst_name_keys <- list(
    item_name = c(item_name = item_name),
    upc_num = c(upc = upc),
    upc_text = c(upc = upc),
    party_product_id = c(party_product_id = basket_product_id)
  )
  set_key(obj = bst_shop, key = bst_name_keys)

  # Generate Keys
  generate_shop_key(obj = bst_shop)

  # Map Keys
  map_shop_key(obj = bst_shop)

  # Upload Mapped Keys
  upsert_shop_key(obj = bst_shop)

  # Return Success
  invisible(TRUE)

}

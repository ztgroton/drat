
#' S3 Method - Validate that 'obj' has valid cdmp keys
#'
#' @param obj R Object - expected S3 class 'cdmp_shop_key'
#'
#' @return TRUE/FALSE
#' @export
#'
#' @examples
#' \dontrun{
#' output <- refresh_valid_key.cdmp_shop_key(obj = cdmp_shop_key_obj)
#' }
refresh_valid_key.cdmp_shop_key <- function(obj) {

  # Validate Inputs
  if (missing(obj)) {stop("`obj` is missing in call to `refresh_valid_key.cdmp_shop_key`", call. = FALSE)}

  tryCatch({
    obj$valid_key <- get_cdmp_valid_key_fields()
    return(TRUE)
  }, error = function(e) {
    message(sprintf("Error in %s: %s", deparse(e[["call"]]), e[["message"]]))
    return(FALSE)
  })

}

#' S3 Method - Validate if 'x' satisfies valid key templates of 'obj'
#'
#' @param obj R Object - expected S3 class 'cdmp_shop_key'
#' @param x list
#' @param bool TRUE/FALSE
#'
#' @return TRUE/FALSE
#' @export
#'
#' @examples
#' \dontrun{
#'  output <- validate_template.cdmp_shop_key(obj = cdmp_shop_key_obj, x, bool = FALSE)
#' }
validate_template.cdmp_shop_key <- function(obj, x, bool) {

  # Validate Inputs
  if (missing(obj)) {stop("`obj` is missing in call to `validate_template.cdmp_shop_key`", call. = FALSE)}
  if (missing(x)) {stop("`x` is missing in call to `validate_template.cdmp_shop_key`", call. = FALSE)}
  if (missing(bool)) {bool <- FALSE}

  expect_scalar_logical(bool)
  expect_list(obj$valid_key, type = 'character')
  expect_list(x, type = 'character')

  tryCatch({

    shared_names <- unique(intersect(names(obj$valid_key), names(x)))
    expect_data_type(obj = shared_names, type = 'character', nz_len = TRUE)
    if (!isTRUE(identical(sort(names(x)), sort(shared_names)))) {
      stop("`names(x)` must be subset of `names(obj$valid_key)` in call to `validate_template.cdmp_shop_key`", call. = FALSE)
    }

    shared_template_names <- purrr::map(shared_names, ~ obj$valid_key[[.]])
    names(shared_template_names) <- shared_names

    shared_x_names <- purrr::map(shared_names, ~ names(x[[.]]))
    names(shared_x_names) <- shared_names

    expect_list_equal(obj1 = shared_template_names, obj2 = shared_x_names, type = 'character')

    if (isTRUE(bool)) {return(TRUE)}
    else {
      res <- purrr::map(shared_names, ~ x[[.]])
      names(res) <- shared_names
      return(res)
    }

  }, error = function(e) {
    message(sprintf("Error in %s: %s", deparse(e[["call"]]), e[["message"]]))
    return(FALSE)
  })

}

#' S3 Method - Clear Key Values for S3 Object of class 'cdmp_shop_key'
#'
#' @importFrom rlang .data
#'
#' @param obj S3 Object of class 'cdmp_shop_key'
#' @param data data.frame - raw cdmp shop data
#' @param competitor character - name of column specifying 'competitor'
#'
#' @return NULL
#' @export
#'
#' @examples
#' \dontrun{
#' generate_key.cdmp_shop_key(obj = cdmp_shop_key_obj, data, competitor)
#' }
generate_key.cdmp_shop_key <- function(obj, data, competitor) {

  # Validate Inputs
  if (missing(data)) {stop("`data` is missing in call to `generate_key.cdmp_shop_key`", call. = FALSE)}
  if (missing(competitor)) {stop("`competitor` is missing in call to `map_key.cdmp_shop_key`", call. = FALSE)}
  expect_data_frame(df = data)
  if (!isTRUE(is.null(competitor))) {expect_scalar_char(competitor)}

  if (!isTRUE('_ORIG_ROW_NUMBER_' %in% colnames(data))) {
    stop("'_ORIG_ROW_NUMBER_' must be subset of `colnames(data)` in call to `generate_key.cdmp_shop_key`", call. = FALSE)
  }

  # Validate 'obj'
  is_valid_obj <- validate_cdmp_shop_key(obj = obj, bool = TRUE)
  if (!isTRUE(is_valid_obj)) {
    stop("`obj` must be a valid `cdmp_shop_key` in call to `generate_key.cdmp_shop_key`", call. = FALSE)
  }

  # Validate 'obj$template' matches with 'colnames(data)'
  for (name in names(obj$template)) {
    matches_template <- isTRUE(all(obj$template[[name]] %in% colnames(data)))
    if (!isTRUE(matches_template)) {
      stop("`obj$template` must have all values in `colnames(data)` in call to `generate_key.cdmp_shop_key`", call. = FALSE)
    }
  }

  # Iterate over `obj$key$template` using `key`
  purrr::walk(names(obj$template), function(key) {

    cat(paste0("Generating Key `", key, "`..."))
    tictoc::tic()

    # Save 'Column Names' and 'Column Types' for selected template
    template_columns <- obj$template[[key]]
    template_types <- obj$valid_type[[key]]

    # Initialize 'data_columns' and 'group_columns', based on 'competitor' value
    if (!isTRUE(is.null(competitor))) {
      data_columns <- c('_ORIG_ROW_NUMBER_', competitor, template_columns)
      group_columns <- c('competitor', names(template_columns))
    } else {
      data_columns <- c('_ORIG_ROW_NUMBER_', template_columns)
      group_columns <- names(template_columns)
    }

    # Rename Raw Data Columns to corresponding Template Column Name
    res <- data[,c(data_columns)]

    inverse_template_columns <- names(template_columns)
    names(inverse_template_columns) <- template_columns

    for (col in names(inverse_template_columns)) {
      res <- res %>%
        dplyr::rename_with(.fn = function(x){inverse_template_columns[[col]]}, .cols = dplyr::all_of(col))
    }

    # Conditionally Rename 'competitor' Column
    if (!isTRUE(is.null(competitor))) {
      res <- res %>%
        dplyr::rename_with(.fn = function(x){'competitor'}, .cols = dplyr::all_of(competitor))
    }

    # Convert Template Columns to Appropriate Data Types
    type_function <- lapply(template_types, function(x) {
      if (isTRUE(x == 'TEXT')) {return(as.character)}
      else if (isTRUE(x == 'NUMERIC')) {return(as.numeric)}
      else {return(identity)}
    })
    names(type_function) <- names(template_types)

    for (col in names(template_types)) {
      res <- res %>% dplyr::mutate_at(col, type_function[[col]])
    }

    # Generate Nested Row Number Column
    res <- res %>%
      dplyr::group_by_at(group_columns) %>%
      dplyr::group_nest(.key = "_ORIG_ROW_NUMBER_") %>%
      dplyr::ungroup() %>%
      dplyr::relocate(.data$`_ORIG_ROW_NUMBER_`)

    # Initialize Blank Columns for TWM Mappings
    res$twm_item_code <- NA
    res$twm_position_key <- NA
    res <- res %>% dplyr::relocate(.data$twm_item_code, .data$twm_position_key, .after = dplyr::last_col())

    obj$data[[key]] <- res

    tictoc::toc()

  })

}

#' S3 Method - Map Key Values for S3 Object of class 'cdmp_shop_key'
#'
#' @importFrom rlang .data
#'
#' @param obj S3 Object of class 'cdmp_shop_key'
#' @param shop_party character - specified 'shop_party'/schema
#' @param competitor character - name of column specifying 'competitor'
#'
#' @return NULL
#' @export
#'
#' @examples
#' \dontrun{
#' map_key.cdmp_shop_key(obj = cdmp_shop_key_obj, shop_party, competitor)
#' }
map_key.cdmp_shop_key <- function(obj, shop_party, competitor) {

  # Validate Inputs
  if (missing(shop_party)) {stop("`shop_party` is missing in call to `map_key.cdmp_shop_key`", call. = FALSE)}
  if (missing(competitor)) {stop("`competitor` is missing in call to `map_key.cdmp_shop_key`", call. = FALSE)}

  expect_scalar_char(obj = shop_party)
  if (!isTRUE(is.null(competitor))) {expect_scalar_char(competitor)}

  # Validate 'obj'
  is_valid_obj <- validate_cdmp_shop_key(obj = obj, bool = TRUE)
  if (!isTRUE(is_valid_obj)) {
    stop("`obj` must be a valid `cdmp_shop_key` in call to `map_key.cdmp_shop_key`", call. = FALSE)
  }

  # Iterate over 'obj$data'
  purrr::walk(names(obj$data), function(key) {

    cat(paste0("Mapping Key `", key, "`..."))
    tictoc::tic()

    key_data <- obj$data[[key]]

    if (!isTRUE(is.null(competitor))) {
      key_data <- key_data %>% dplyr::rename_with(.fn = function(x){'competitor'}, .cols = c(competitor))
      template_columns <- c('competitor', names(obj$template[[key]]))
    } else {
      template_columns <- names(obj$template[[key]])
    }

    # Generate Key Hashes using Template Columns (and Map Order = 1)
    conn <- psql_db_connect('comp_map_lib_prod')

    new_hashes <- gen_key_hashes(
      conn = conn,
      data = key_data %>%
        dplyr::select_at(c(template_columns)) %>%
        dplyr::mutate(map_order = as.integer(1)),
      schema = shop_party,
      table = key,
      competitor = competitor
    )

    DBI::dbDisconnect(conn)
    rm(conn)

    # Join New Key Hashes to Key Data
    new_key_data <- key_data %>%
      dplyr::left_join(new_hashes, by = template_columns)

    # Validate Key Hash Values
    if (!isTRUE(all(!is.na(new_key_data$key_hash))))
    {
      stop("`new_key_data$key_hash` values were incorrectly generated in call to `map_key.cdmp_shop_key`")
    }

    key_data <- new_key_data %>% dplyr::select(-.data$map_order)
    rm(new_key_data)

    # Fetch Current Mappings
    key_map <- vw_map_key(schema = shop_party, table = key, include_detail = FALSE)
    key_map <- key_map %>%
      dplyr::select(.data$key_hash, .data$twm_item_code, .data$twm_position_key)

    key_data <- key_data %>%
      dplyr::select(-.data$twm_item_code, -.data$twm_position_key) %>%
      dplyr::left_join(key_map, by = 'key_hash')

    obj$data[[key]] <- key_data
    tictoc::toc()

  })

}

#' S3 Method - Upsert Key Values for S3 Object of class 'cdmp_shop_key'
#'
#' @importFrom rlang .data
#'
#' @param obj S3 Object of class 'cdmp_shop_key'
#' @param shop_party character - specified 'shop_party'/schema
#' @param file_name character
#' @param file_hash character
#'
#' @return NULL
#' @export
#'
#' @examples
#' \dontrun{
#' upsert_key.cdmp_shop_key(obj = cdmp_shop_key_obj, shop_party, file_name, file_hash)
#' }
upsert_key.cdmp_shop_key <- function(obj, shop_party, file_name, file_hash) {

  # Validate Inputs
  if (missing(shop_party)) {stop("`shop_party` is missing in call to `upsert_key.cdmp_shop_key`", call. = FALSE)}
  expect_scalar_char(obj = shop_party)

  # Validate 'obj'
  is_valid_obj <- validate_cdmp_shop_key(obj = obj, bool = TRUE)
  if (!isTRUE(is_valid_obj)) {
    stop("`obj` must be a valid `cdmp_shop_key` in call to `upsert_key.cdmp_shop_key`", call. = FALSE)
  }

  # Iterate over 'obj$data'
  purrr::walk(names(obj$data), function(key) {

    cat("\n-------- ")
    cat(paste0("Upserting Key `", key))
    cat("` --------\n")
    tictoc::tic()

    # key
    key_data <- obj$data[[key]]
    pk_columns <- setdiff(colnames(key_data), c('_ORIG_ROW_NUMBER_', 'key_hash', 'competitor', 'twm_item_code', 'twm_position_key'))

    if (isTRUE('competitor' %in% colnames(key_data))) {
      pk_na_columns <- c(pk_columns, 'competitor')
    } else {
      pk_na_columns <- pk_columns
    }

    pk_na <- purrr::map(pk_na_columns, function(col) {tidyr::replace_na(is.na(key_data[[col]]), TRUE)})
    pk_na <- purrr::reduce(pk_na, `|`)

    if (!isTRUE(is.logical(pk_na))) {
      stop("`pk_na` must only contain TRUE/FALSE in call to `upsert_key.cdmp_shop_key`", call. = FALSE)
    }

    if (isTRUE(any(is.na(pk_na))) || isTRUE(any(is.null(pk_na)))) {
      stop("`pk_na` must not contain any NA or NULL values in call to `upsert_key.cdmp_shop_key`", call. = FALSE)
    }

    key_data <- key_data %>% dplyr::filter(!pk_na)

    # competitor
    if (isTRUE('competitor' %in% colnames(key_data))) {
      pk_columns <- c('map_order', 'competitor_hash', pk_columns)
      final_columns <- c(pk_columns, 'is_primary', 'map_hash')
      competitor_hash <- get_competitor()

      key_data <- key_data %>%
        dplyr::left_join(competitor_hash, by = c('competitor' = 'competitor_name')) %>%
        dplyr::select(-.data$competitor)

    } else {
      pk_columns <- c('map_order', pk_columns)
      final_columns <- c('key_hash', pk_columns, 'is_primary', 'map_hash')
    }

    # map
    map_hash <- get_twm_map()
    key_data <- key_data %>%
      dplyr::left_join(map_hash, by = c('twm_item_code', 'twm_position_key')) %>%
      dplyr::select(-.data$twm_item_code, -.data$twm_position_key)

    # upload_data
    upload_data <- key_data %>% dplyr::mutate(map_order = 1, is_primary = TRUE)

    # match_upload_data
    match_upload_data <- upload_data %>%
      tidyr::unnest(col = c(.data$`_ORIG_ROW_NUMBER_`)) %>%
      dplyr::rename(orig_row_num = .data$`_ORIG_ROW_NUMBER_`) %>%
      dplyr::relocate(.data$orig_row_num)

    # Open DB Connection
    conn <- psql_db_connect('comp_map_lib_prod')

    # Upload File Match Data
    cat("Uploading File Matches...")
    tictoc::tic()
    match_upload_tbl <- upload_tmp_tbl(data = match_upload_data)
    tictoc::toc()

    # Process and Log File Matches
    cat("Processing and Loading into `upload_files.record_match_log`...")
    tictoc::tic()
    qry <- glue::glue_sql(
      "CALL public.record_match_log_insert(
	      {match_upload_tbl}::TEXT,
	      {file_hash}::TEXT,
        {match_shop_party}::TEXT,
        {match_key}::TEXT
      )"
      , match_shop_party = shop_party
      , match_key = key
      , .con = conn
    )

    DBI::dbExecute(conn, qry)
    drop_tmp_tbl(name = match_upload_tbl)
    tictoc::toc()

    # key_upload_data
    cat("Uploading Key Matches...")
    tictoc::tic()
    key_upload_data <- upload_data[,c(final_columns)]

    table_id <- DBI::Id(schema = shop_party, table = key)

    dbx::dbxUpsert(
      conn = conn,
      table = table_id,
      records = key_upload_data,
      where_cols = pk_columns,
      skip_existing = TRUE
    )

    # Close DB Connection
    DBI::dbDisconnect(conn)
    rm(conn)
    tictoc::toc()

    tictoc::toc()

  })

}

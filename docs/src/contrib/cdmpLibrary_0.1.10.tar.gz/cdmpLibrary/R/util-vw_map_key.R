
#' Returns Current Mappings based on 'schema' and 'table'
#'
#' @importFrom rlang .data
#'
#' @param schema character - name of schema containing desired table
#' @param table character - name of desired table
#' @param include_detail logical - optionally specify if 'Key Details' should be included in output.
#' @param use_dev logical - optionally specify if development database should be used.
#'
#' @return data.frame
#' @export
#'
vw_map_key <- function(schema, table, include_detail = TRUE, use_dev = FALSE) {

  # Validate Inputs
  if (missing(schema)) {stop("`schema` is missing in call to `vw_map_key`", call. = FALSE)}
  if (missing(table)) {stop("`table` is missing in call to `vw_map_key`", call. = FALSE)}
  if (missing(include_detail)) {include_detail <- TRUE}
  if (missing(use_dev)) {use_dev <- FALSE}

  # Validate Input Expectations

  # * `schema`
  if (
    !isTRUE(is.character(schema))
    || !isTRUE(length(schema) > 0)
    || isTRUE(any(is.null(schema)))
    || isTRUE(any(is.na(schema)))
  ) {
    stop("`schema` has invalid value in call to `vw_map_key`")
  }

  schema <- tolower(schema)

  # * `table`
  expect_scalar_char(obj = table)

  # * `include_detail`
  if (!isTRUE(identical(include_detail, TRUE)) && !isTRUE(identical(include_detail, FALSE))) {
    stop("`include_detail` must be identical to TRUE/FALSE in call to `vw_map_key`")
  }

  # * `use_dev`
  if (!isTRUE(identical(use_dev, TRUE)) && !isTRUE(identical(use_dev, FALSE))) {
    stop("`use_dev` must be identical to TRUE/FALSE in call to `vw_map_key`")
  }

  # MAIN LOGIC

  # Setup DB Connection
  if (isTRUE(identical(use_dev, TRUE))) {
    conn <- psql_db_connect('comp_map_lib_dev')
  } else {
    conn <- psql_db_connect('comp_map_lib_prod')
  }

  # * Validate `schema` against expected Shop Parties
  expected_schemas <- c('nlsn', 'iri', 'bst', 'twm', 'tws')
  if (!isTRUE(all(schema %in% expected_schemas))) {
    stop("`schema` must be a valid shop party in call to `vw_map_key`", call. = FALSE)
  }

  # MAIN LOGIC

  # Iterate over 'schema'
  res <- purrr::map(schema, function(schema) {

    # Check if 'table' exists in 'schema'
    if (isTRUE(table_exists(conn, schema, table))) {

      # Initialize 'table_qry' based on 'include_detail'
      if (isTRUE(include_detail)) {
        table_qry <- glue::glue("
                            select t.*, mld.item_name, mld.sales_dollars
                            from {schema}.{table} t
                            left outer join map_library.map_lib_detail mld
                            on t.key_hash = mld.key_hash
                            and t.map_order = mld.map_order
                            order by COALESCE(mld.sales_dollars, -1) desc
                            ")
      } else if (isFALSE(include_detail)) {
        table_qry <- glue::glue("
                            select t.*
                            from {schema}.{table} t
                            ")
      }

      # Generate Key Mappings
      tryCatch({

        key <- DBI::dbGetQuery(conn = conn, table_qry)
        map <- DBI::dbGetQuery(conn = conn, "select * from map_library.twm_map")

        res <- key %>%
          dplyr::left_join(map, by = 'map_hash') %>%
          dplyr::select(-.data$map_hash)

        if (isTRUE('competitor_hash' %in% colnames(res))) {
          competitor_map <- get_competitor()
          res <- res %>%
            dplyr::left_join(competitor_map, by = 'competitor_hash') %>%
            dplyr::select(-.data$competitor_hash) %>%
            dplyr::relocate(.data$competitor_name) %>%
            dplyr::rename_with(.fn = function(x){'competitor'}, .cols = .data$competitor_name)
        }

        return(res)

      }, error = function(e) {
        message(sprintf("Error in %s: %s", deparse(e[["call"]]), e[["message"]]), call. = FALSE)
      })


    } else {
      message(paste0("table `", table, "` DOES NOT EXIST in schema `", schema, "` -  SKIPPING!!!"), call. = FALSE)
    }

  })

  # Close DB Connection
  DBI::dbDisconnect(conn)
  rm(conn)

  # Row-Bind Results into Single DataFrame
  res <- res %>% purrr::reduce(dplyr::bind_rows)

  # Return Results
  return(res)

}

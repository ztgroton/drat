
#' Setup Competitive Mapping Library 'Common' Tables
#'
#' @param conn DBIConnection
#'
#' @return TRUE
#' @export
#'
#' @examples
#' \dontrun{
#' setup_common_tables(psql_conn)
#' }
setup_common_tables <- function(conn) {

  # Validate Inputs
  if (missing(conn)) {stop("`conn` is missing in call to `setup_common_tables`")}

  # Validate Input Expectations

  # * `conn`
  if (!isTRUE(inherits(conn, 'DBIConnection'))) {
    stop("`conn` must inherit from 'DBIConnection' in call to `setup_common_tables`")
  }

  # ____________________________________ ----
  # CREATE COMPETITOR TABLE ----
  cat("Creating Competitor Table... ")
  tictoc::tic()
  create_competitor_table(conn)
  tictoc::toc()

  # ____________________________________ ----
  # CREATE VALID KEY TABLE ----
  cat("Creating Valid Key Table... ")
  tictoc::tic()
  create_valid_key_table(conn)
  tictoc::toc()

  # ____________________________________ ----
  # CREATE VALID KEY FIELD TABLE ----
  cat("Creating Valid Key Field Table... ")
  tictoc::tic()
  create_valid_key_field_table(conn)
  tictoc::toc()

  # ____________________________________ ----
  # CREATE TWM MAP TABLE ----
  cat("Creating TWM Map Table... ")
  tictoc::tic()
  create_twm_map_table(conn)
  tictoc::toc()

  # ____________________________________ ----
  # UPLOAD TWM MAP TABLE ----
  upload_results <- readRDS(system.file('databases/comp_map_lib/map_library/twm_map.rds', package = 'cdmpLibrary'))

  cat("Populating TWM Map Table... ")
  tictoc::tic()
  upload_twm_map_table(conn, upload_results)
  tictoc::toc()

  # ____________________________________ ----
  # INITIALIZE STORED FUNCTIONS ----
  cat("Initializing Stored Functions... ")
  tictoc::tic()
  init_func(conn)
  tictoc::toc()

  # ____________________________________ ----
  # INITIALIZE STORED PROCEDURES ----
  cat("Initalizing Stored Procedures... ")
  tictoc::tic()
  init_proc(conn)
  tictoc::toc()

  # ____________________________________ ----
  # CREATE MAP LIB TABLE ----
  cat("Creating `Map Lib Table`... ")
  tictoc::tic()
  create_map_lib_table(conn)
  tictoc::toc()

  # ____________________________________ ----
  # CREATE MAP LIB UPDATE TABLE ----
  cat("Creating `Map Lib Update` Table... ")
  tictoc::tic()
  create_map_lib_update_table(conn)
  tictoc::toc()

  # ____________________________________ ----
  # CREATE TWM ITEM UPC TABLE ----
  cat("Creating `TWM Item UPC` Table... ")
  tictoc::tic()
  create_twm_item_upc_table(conn)
  tictoc::toc()

  # ____________________________________ ----
  # * CREATE FILE LOG TABLE
  cat("Creating `upload_files.file_log`... ")
  tictoc::tic()
  create_file_log_table(conn)
  tictoc::toc()

  # ____________________________________ ----
  # * CREATE RECORD LOG TABLE
  cat("Creating `upload_files.record_log`... ")
  tictoc::tic()
  create_record_log_table(conn)
  tictoc::toc()

  # ____________________________________ ----
  # * CREATE RECORD MATCH LOG TABLE
  cat("Creating `upload_files.record_match_log`... ")
  tictoc::tic()
  create_record_match_log_table(conn)
  tictoc::toc()

  # Return Success
  invisible(TRUE)

}

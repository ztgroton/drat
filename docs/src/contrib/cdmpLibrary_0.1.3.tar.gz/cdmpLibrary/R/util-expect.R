
#' Verify that R Object meets Data Type Constraints
#'
#' @param obj R Object
#' @param type character - desired data type / 'character', 'numeric' or 'logical'
#' @param nz_len TRUE/FALSE - specifies if 'length(obj)' must be non-zero
#' @param is_scalar TRUE/FALSE - specifies if 'length(obj)' must equal 1
#' @param allow_na TRUE/FALSE - specifies if NA elements are allowed in 'obj'
#' @param check_names TRUE/FALSE - specifies if 'names(obj)' should meet same criteria
#'
#' @return R Object
#' @export
#'
expect_data_type <- function(obj, type, nz_len, is_scalar, allow_na, check_names) {

  # Handle Missing Inputs and Apply Default Values
  if (missing(obj)) {stop("`obj` is missing in call to `expect_data_type`", call. = FALSE)}
  if (missing(type)) {stop("`type` is missing in call to `expect_data_type`", call. = FALSE)}
  if (missing(nz_len)) {nz_len <- FALSE}
  if (missing(is_scalar)) {is_scalar <- FALSE}
  if (missing(allow_na)) {allow_na <- FALSE}
  if (missing(check_names)) {check_names <- FALSE}

  if (isTRUE(identical(is_scalar, TRUE))) {nz_len <- TRUE}

  valid_types <- c('character', 'numeric', 'logical')
  if (!isTRUE(type %in% valid_types)) {
    stop("`type` must be valid value in call to `expect_data_type`")
  }

  # Main Logic
  q_obj <- testthat::quasi_label(rlang::enquo(obj), arg = "object")

  # * type
  is_type <- FALSE

  if (isTRUE(identical(type, 'character'))) {is_type <- isTRUE(is.character(obj))}
  else if (isTRUE(identical(type, 'numeric'))) {is_type <- isTRUE(is.numeric(obj))}
  else if (isTRUE(identical(type, 'logical'))) {is_type <- isTRUE(is.logical(obj))}
  else {
    message <- sprintf("`type` must be one of: %s", valid_types)
    stop(message, call. = FALSE)
  }

  if (!isTRUE(is_type)) {
    message <- sprintf("%s must be data type %s", q_obj$lab, type)
    stop(message, call. = FALSE)
  }

  # * `nz_len`
  if (!isTRUE(is.logical(nz_len)) || !isTRUE(length(nz_len) == 1) || isTRUE(is.na(nz_len))) {
    message <- "`nz_len` must be TRUE/FALSE in call to `expect_data_type`"
    stop(message, call. = FALSE)
  }

  if (isTRUE(nz_len)) {
    is_nz_len <- isTRUE(length(obj) > 0)
    if (!isTRUE(is_nz_len)) {
      message <- sprintf("%s must have non-zero length", q_obj$lab)
      stop(message, call. = FALSE)
    }
  }

  # * `is_scalar`
  if (!isTRUE(is.logical(is_scalar)) || !isTRUE(length(is_scalar) == 1) || isTRUE(is.na(is_scalar))) {
    message <- "`is_scalar` must be TRUE/FALSE in call to `expect_data_type`"
    stop(message, call. = FALSE)
  }

  if (isTRUE(is_scalar)) {
    is_scalar <- isTRUE(length(obj) == 1)
    if (!isTRUE(is_scalar)) {
      message <- sprintf("%s must have length equal to 1", q_obj$lab)
      stop(message, call. = FALSE)
    }
  }

  # * `allow_na`
  if (!isTRUE(is.logical(allow_na)) || !isTRUE(length(allow_na) == 1) || isTRUE(is.na(allow_na))) {
    message <- "`allow_na` must be TRUE/FALSE in call to `expect_data_type`"
    stop(message, call. = FALSE)
  }

  if (!isTRUE(allow_na)) {
    is_allow_na <- !isTRUE(any(purrr::map_lgl(obj, ~ is.null(.) || is.na(.))))
    if (!isTRUE(is_allow_na)) {
      message <- sprintf("%s cannot contain NA/NULL elements", q_obj$lab)
      stop(message, call. = FALSE)
    }
  }

  # * `check_names`
  if (!isTRUE(is.logical(check_names)) || !isTRUE(length(check_names) == 1) || isTRUE(is.na(check_names))) {
    message <- "`check_names` must be TRUE/FALSE in call to `expect_data_type`"
    stop(message, call. = FALSE)
  }

  if (isTRUE(check_names)) {
    expect_data_type(
      obj = names(obj), type = type,
      nz_len = nz_len, is_scalar = is_scalar, allow_na = allow_na,
      check_names = FALSE
    )
  }

  # Return Final Result
  return(TRUE)

}

#' Verifies that R Object is Scaar Non-NA Logical
#'
#' @param obj R Object
#'
#' @return R Object
#' @export
#'
expect_scalar_logical <- function(obj) {

  # Handle Missing Inputs and Apply Default Values
  if (missing(obj)) {stop("`obj` is missing in call to `expect_scalar_logical`", call. = FALSE)}

  # Main Logic

  # * `obj`
  expect_data_type(obj = obj, type = 'logical', is_scalar = TRUE)

  # Return Final Result
  return(TRUE)

}

#' Verifies that R Object is Scalar Non-NA Character
#'
#' @param obj R Object
#'
#' @return R Object
#' @export
#'
expect_scalar_char <- function(obj) {

  # Handle Missing Inputs and Apply Default Values
  if (missing(obj)) {stop("`obj` is missing in call to `expect_scalar_char`", call. = FALSE)}

  # Main Logic

  # * `obj`
  expect_data_type(obj = obj, type = 'character', is_scalar = TRUE)

  # Return Final Result
  return(TRUE)

}

#' Verifies that R Object is Scalar Non-NA Numeric
#'
#' @param obj R Object
#'
#' @return R Object
#' @export
#'
expect_scalar_numeric <- function(obj) {

  # Handle Missing Inputs and Apply Default Values
  if (missing(obj)) {stop("`obj` is missing in call to `expect_scalar_numeric`", call. = FALSE)}

  # Main Logic

  # * `obj`
  expect_data_type(obj = obj, type = 'numeric', is_scalar = TRUE)

  # Return Final Result
  return(TRUE)

}

#' Verifies that R Object is Scalar Non-NA Integer
#'
#' @param obj R Object
#'
#' @return R Object
#' @export
#'
expect_scalar_integer <- function(obj) {

  # Handle Missing Inputs and Apply Default Values
  if (missing(obj)) {stop("`obj` is missing in call to `expect_scalar_integer`", call. = FALSE)}

  # Main Logic

  # * `obj`
  expect_data_type(obj = obj, type = 'numeric', is_scalar = TRUE)
  if (!isTRUE(obj %% 1 == 0)) {return(FALSE)}

  # Return Final Result
  return(TRUE)

}

#' Verifies that R Object is 'DBIConnection'
#'
#' @param obj R Object
#'
#' @return R Object
#' @export
#'
expect_dbi <- function(obj) {

  # Handle Missing Inputs and Apply Default Values
  if (missing(obj)) {stop("`obj` is missing in call to `expect_dbi`", call. = FALSE)}

  # Main Logic
  q_obj <- testthat::quasi_label(rlang::enquo(obj), arg = "object")

  # * `obj`
  is_dbi <- isTRUE(inherits(obj, 'DBIConnection'))
  if (!isTRUE(is_dbi)) {
    message <- sprintf("%s must inherit from 'DBIConnection'", q_obj$lab)
    stop(message, call. = FALSE)
  }

  return(TRUE)

}

#' Verifies that R Object is DataFrame
#'
#' @param df R Object
#' @param columns character - specifies expected columns
#'
#' @return R Object
#' @export
#'
expect_data_frame <- function(df, columns) {

  if (missing(df)) {stop("`df` is missing in call to `expect_data_frame`", call. = FALSE)}
  if (missing(columns)) {columns <- NULL}

  # Main Logic
  q_df <- testthat::quasi_label(rlang::enquo(df), arg = "object")
  q_columns <- testthat::quasi_label(rlang::enquo(columns), arg = "object")

  is_data_frame <- isTRUE(inherits(df, 'data.frame'))
  if (!isTRUE(is_data_frame)) {
    message <- sprintf("%s must be 'data.frame'", q_df$lab)
    stop(message, call. = FALSE)
  }

  if (!isTRUE(is.null(columns))) {
    expect_data_type(obj = columns, type = 'character', nz_len = TRUE)
    has_columns <- isTRUE(all(columns %in% colnames(df)))

    if (!isTRUE(has_columns)) {
      message <- sprintf("%s must have columns '%s'", q_df$lab, q_columns$lab)
      stop(message, call. = FALSE)
    }
  }

  return(TRUE)

}

#' Verifies that Column exists in DataFrame
#'
#' @param df data.frame
#' @param columns character
#'
#' @return R Object
#' @export
#'
expect_col_exists <- function(df, columns) {

  if (missing(df)) {stop("`df` is missing in call to `expect_data_frame`", call. = FALSE)}
  if (missing(columns)) {columns <- NULL}

  expect_data_frame(df)
  expect_data_type(columns, type = 'character', nz_len = TRUE)

  q_df <- testthat::quasi_label(rlang::enquo(df), arg = "object")
  q_columns <- testthat::quasi_label(rlang::enquo(columns), arg = "object")

  for (col in columns) {
    if (!isTRUE(col %in% colnames(df))) {
      message <- sprintf("column '%s' must exist in data.frame %s", col, q_df$lab)
      stop(message, call. = FALSE)
    }
  }

  return(TRUE)

}

#' Verifies that Column exists in DataFrame
#'
#' @param df data.frame
#' @param column character
#'
#' @return R Object
#' @export
#'
expect_valid_competitor <- function(df, column) {

  if (missing(df)) {stop("`df` is missing in call to `expect_data_frame`", call. = FALSE)}
  if (missing(column)) {column <- NULL}

  expect_col_exists(df, column)

  # Main Logic
  q_df <- testthat::quasi_label(rlang::enquo(df), arg = "object")

  psql_conn <- psql_db_connect('comp_map_lib')
  map_lib_competitors <- DBI::dbGetQuery(psql_conn, "select * from map_library.competitor")
  DBI::dbDisconnect(psql_conn)
  rm(psql_conn)

  unq_data_competitors <- df %>% dplyr::pull(!!column) %>% unique() %>% as.character()

  if (!isTRUE(all(unq_data_competitors %in% map_lib_competitors$competitor_name))) {
    message <- sprintf("column '%s'.'%s' contains unrecognized competitors", q_df$lab, column)
    stop(message, call. = FALSE)
  }

  return(TRUE)

}

#' Verify that 'obj' is an environment, with optional names
#'
#' @param obj R Object - expected to be base type 'environment'
#' @param names character or NULL - indicates expected names in 'obj'
#'
#' @return R Object
#' @export
#'
expect_env <- function(obj, names) {

  if (missing(obj)) {stop("`obj` is missing in call to `expect_env`", call. = FALSE)}
  if (missing(names)) {names <- NULL}

  # Main Logic
  q_obj <- testthat::quasi_label(rlang::enquo(obj), arg = "object")
  q_names <- testthat::quasi_label(rlang::enquo(names), arg = "object")

  # * `obj`
  is_env <- isTRUE(is.environment(obj))
  if (!isTRUE(is_env)) {
    message <- sprintf("%s must have 'environment' base type", q_obj$lab)
    stop(message, call. = FALSE)
  }

  # * `names`
  if (!isTRUE(is.null(names))) {

    expect_data_type(obj = names, type = 'character', nz_len = TRUE)
    names_label <- rlang::expr_text(rlang::enquo(names))

    is_expected <- isTRUE(identical(sort(names(obj)), sort(names)))
    if (!isTRUE(is_expected)) {
      message <- sprintf("'names(%s)' does not match %s", q_obj$lab, q_names$lab)
      stop(message, call. = FALSE)
    }

  }

  return(TRUE)

}

#' Verify that 'obj' is a list, with optional names
#'
#' @param obj R Object - expected to be base type 'list'
#' @param names character or NULL - indicates expected names in 'obj'
#' @param type character - indicates allowed data type of list elements
#'
#' @return R Object
#' @export
#'
expect_list <- function(obj, names, type) {

  if (missing(obj)) {stop("`obj` is missing in call to `expect_list`", call. = FALSE)}
  if (missing(names)) {names <- NULL}
  if (missing(type)) {type <- 'character'}

  expect_scalar_char(type)

  # Main Logic
  q_obj <- testthat::quasi_label(rlang::enquo(obj), arg = "object")
  q_names <- testthat::quasi_label(rlang::enquo(names), arg = "object")

  # * `obj`
  is_list <- isTRUE(is.list(obj))
  if (!isTRUE(is_list)) {
    message <- sprintf("%s must have 'list' base type", q_obj$lab)
    stop(message, call. = FALSE)
  }

  # * `names`
  if (!isTRUE(is.null(names))) {

    expect_data_type(obj = names, type = 'character', nz_len = TRUE)
    names_label <- rlang::expr_text(rlang::enquo(names))

    is_expected <- isTRUE(identical(sort(names(obj)), sort(names)))
    if (!isTRUE(is_expected)) {
      message <- sprintf("'names(%s)' does not match %s", q_obj$lab, q_names$lab)
      stop(message, call. = FALSE)
    }

  }

  # * `type`
  valid_type <- isTRUE(all(purrr::map_lgl(obj, function(x) {
    isTRUE(expect_data_type(x, type = type, nz_len = TRUE))
  })))

  if (!isTRUE(valid_type)) {
    message <- sprintf("'%s' elements must all match %s", q_obj$lab, type)
    stop(message, call. = FALSE)
  }

  return(TRUE)

}


#' Verify that 'obj' is a list, with optional names
#'
#' @param obj1 R Object - expected to be base type 'list'
#' @param obj2 R Object - expected to be base type 'list'
#' @param type character - indicates allowed data type of list elements
#'
#' @return R Object
#' @export
#'
expect_list_equal <- function(obj1, obj2, type) {

  if (missing(type)) {type <- 'character'}

  expect_scalar_char(type)

  # Main Logic
  obj1_label <- rlang::expr_text(rlang::enquo(obj1))
  obj2_label <- rlang::expr_text(rlang::enquo(obj2))

  obj_names <- unique(intersect(names(obj1), names(obj2)))
  expect_list(obj = obj1, names = obj_names, type = type)
  expect_list(obj = obj2, names = obj_names, type = type)

  obj_all_equal <- isTRUE(all(purrr::map_lgl(obj_names, ~ isTRUE(identical(obj1[[.]], obj2[[.]])))))
  if (!isTRUE(obj_all_equal)) {
    message <- sprintf("'%s' does not match '%s'", obj1_label, obj2_label)
    stop(message, call. = FALSE)
  }

  return(TRUE)

}

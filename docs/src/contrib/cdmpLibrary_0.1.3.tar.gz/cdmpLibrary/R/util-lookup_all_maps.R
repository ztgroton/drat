
#' Returns ALL Current Mappings for TWM Item/Position
#'
#' @importFrom rlang .data
#'
#' @param item_code numeric - Single TWM Item Code
#' @param position_key numeric - Single TWM Position Key
#' @param use_dev logical - optionally specify if development database should be used.
#'
#' @return data.frame
#' @export
#'
#' @examples
#' \dontrun{
#' output <- lookup_all_maps(item_code = 29123, position_key = 3)
#' }
lookup_all_maps <- function(item_code, position_key, use_dev = FALSE) {

  # Validate Inputs
  if (missing(item_code)) {stop("`item_code` is missing in call to `lookup_all_maps`", call. = FALSE)}
  if (missing(position_key)) {stop("`position_key` is missing in call to `lookup_all_maps`", call. = FALSE)}
  if (missing(use_dev)) {use_dev <- FALSE}

  # Validate Input Expectations

  # * `item_code`
  if (!isTRUE(is.numeric(item_code)) || !isTRUE(length(item_code) == 1) || isTRUE(is.na(item_code))) {
    stop("`item_code` must be scalar numeric in call to `lookup_all_maps`")
  }

  # * `position_key`
  if (!isTRUE(position_key %in% c(1,2,3)) || !isTRUE(length(position_key) == 1)) {
    stop("`position_key` must equal 1, 2 or 3 in call to `lookup_all_maps`")
  }

  # * `use_dev`
  if (!isTRUE(identical(use_dev, TRUE)) && !isTRUE(identical(use_dev, FALSE))) {
    stop("`use_dev` must be identical to TRUE/FALSE in call to `lookup_all_maps`")
  }

  # MAIN LOGIC

  # Setup DB Connection
  if (isTRUE(identical(use_dev, TRUE))) {
    conn <- psql_db_connect('comp_map_lib_dev')
  } else {
    conn <- psql_db_connect('comp_map_lib')
  }

  # MAIN LOGIC

  # Initialize 'all_maps'
  all_maps <- cdmpLibrary::valid_mapping_schemas
  all_maps <- all_maps[c('nlsn', 'iri', 'bst')]

  # Iterate over 'all_maps' / Compile Unique Key Hashes
  key_hashes <- purrr::map(names(all_maps), function(sch) {

    tables <- all_maps[[sch]]

    tmp_res <- purrr::map(tables, function(tbl) {

      lookup_custom_map(
        schema = sch,
        table = tbl,
        item_code = item_code,
        position_key = position_key
      ) %>%
        dplyr::select(.data$key_hash)

    })
    names(tmp_res) <- tables

    tmp_res <- purrr::reduce(tmp_res, `rbind`)
    return(tmp_res)

  })
  names(key_hashes) <- names(all_maps)

  key_hashes <- purrr::reduce(key_hashes, `rbind`) %>%
    dplyr::distinct(.data$key_hash) %>%
    dplyr::pull(.data$key_hash)

  # Query 'map_library.map_lib'
  map_lib_qry <- glue::glue_sql(
    "select t.*
    from map_library.map_lib t
    where t.key_hash IN ({key_hashes*})",
    .con = conn
  )

  res <- DBI::dbGetQuery(conn = conn, map_lib_qry)

  if (isTRUE(nrow(res) > 0)) {

    # Format JSON Data
    json_data <- purrr::map(res$key_jsonb, jsonlite::fromJSON) %>%
      purrr::map(function(x){format_from_json_list(x)}) %>%
      jsonlite::toJSON() %>% jsonlite::fromJSON() %>%
      dplyr::relocate(.data$schema, .data$table) %>%
      dplyr::relocate(.data$map_order, .after = dplyr::last_col())

    # Add TWM Item Info to JSON Data
    final_res <- json_data %>%
      dplyr::mutate(
        item_code = item_code,
        position_key = position_key
      ) %>%
      dplyr::arrange(.data$schema, .data$table) %>%
      dplyr::rename(
        shop_party = .data$schema,
        map_name = .data$table
      )

  } else {
    final_res <- NA
  }

  # Return Result
  return(final_res)

}

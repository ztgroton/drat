
#' Upload Table Contents from Archived Data
#'
#' @param conn DBIConnection
#' @param schema character
#' @param table character
#' @param use_dev logical
#'
#' @return TRUE
#' @export
#'
#' @examples
#' \dontrun{
#' upload_table_from_archive(conn = psql_conn, schema = 'nlsn', table = 'upc_num')
#' }
upload_table_from_archive <- function(conn, schema, table, use_dev = FALSE) {

  # Validate Inputs
  if (missing(conn)) {stop("`conn` is missing in call to `upload_table_from_archive`")}
  if (missing(schema)) {stop("`schema` is missing in call to `upload_table_from_archive`")}
  if (missing(table)) {stop("`table` is missing in call to `upload_table_from_archive`")}
  if (missing(use_dev)) {use_dev <- FALSE}

  # Validate Input Expectations

  # * `conn`
  if (!isTRUE(inherits(conn, 'DBIConnection'))) {
    stop("`conn` must inherit from 'DBIConnection' in call to `upload_table_from_archive`")
  }

  # * `schema`
  if (!isTRUE(is.character(schema)) || !isTRUE(length(schema) == 1) || !isFALSE(is.na(schema))) {
    stop("`schema` must be Non-NA length 1 character vector in call to `upload_table_from_archive`")
  }

  # * `table`
  if (!isTRUE(is.character(table)) || !isTRUE(length(table) == 1) || !isFALSE(is.na(table))) {
    stop("`table` must be Non-NA length 1 character vector in call to `upload_table_from_archive`")
  }

  # * `use_dev`
  if (!isTRUE(identical(use_dev, TRUE)) && !isTRUE(identical(use_dev, FALSE))) {
    stop("`use_dev` must be identical to TRUE/FALSE in call to `upload_table_from_archive`")
  }

  if (isTRUE(identical(use_dev, TRUE))) {
    archive_db <- 'comp_map_lib_dev'
  } else {
    archive_db <- 'comp_map_lib'
  }

  # Generate Archive Data Path
  archive_path <- system.file(paste('databases', archive_db, schema, sep = '/'), package = 'cdmpLibrary')
  archive_file_name <- paste0(table, '.rds')
  archive_file_path <- file.path(archive_path, archive_file_name)

  # Fetch Archive RDS Data
  archive_data <- readRDS(archive_file_path)

  # Initialize Destination Table Id
  dest_table <- DBI::Id(schema = schema, table = table)

  # Insert Archived Data into Destination Table
  dbx::dbxInsert(
    conn = conn,
    table = dest_table,
    records = archive_data,
    batch_size = 1000000
  )

  # Return Success
  invisible(TRUE)

}

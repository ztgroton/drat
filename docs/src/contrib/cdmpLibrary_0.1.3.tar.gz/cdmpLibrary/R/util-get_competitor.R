
#' Return Active Competitors in Mapping Library
#'
#' @return data.frame
#' @export
#'
get_competitor <- function() {

  psql_conn <- psql_db_connect('comp_map_lib')
  res <- DBI::dbGetQuery(psql_conn, "select * from map_library.competitor")
  DBI::dbDisconnect(psql_conn)
  rm(psql_conn)

  return(res)

}

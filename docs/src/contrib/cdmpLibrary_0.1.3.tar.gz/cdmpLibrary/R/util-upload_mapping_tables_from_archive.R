
#' Populate Mapping Tables from Archived Data
#'
#' @param conn DBIConnection
#' @param use_dev logical
#'
#' @return TRUE
#' @export
#'
#' @examples
#' \dontrun{
#' upload_mapping_tables_from_archive(conn = psql_conn)
#' }
upload_mapping_tables_from_archive <- function(conn, use_dev = FALSE) {

  # Validate Inputs
  if (missing(conn)) {stop("`conn` is missing in call to `setup_mapping_tables`")}

  # Validate Input Expectations

  # * `conn`
  if (!isTRUE(inherits(conn, 'DBIConnection'))) {
    stop("`conn` must inherit from 'DBIConnection' in call to `setup_mapping_tables`")
  }

  # ____________________________________ ----
  # CREATE MAPPING TABLES ----

  # Iterate over `names(valid_mapping_schemas)`
  purrr::walk(names(cdmpLibrary::valid_mapping_schemas), function(schema) {

    # Get Schema Tables
    tables <- cdmpLibrary::valid_mapping_schemas[[schema]]

    # Iterate Over `tables`
    for (table in tables) {

      # Upload Archived Table Contents
      cat(paste0(toupper(schema), ' - ', toupper(table), '... '))
      tictoc::tic()
      upload_table_from_archive(
        conn = conn,
        schema = schema,
        table = table,
        use_dev = use_dev
      )
      tictoc::toc()

    }

  })

  # Return Success
  invisible(TRUE)

}

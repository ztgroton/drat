
#' Create Table 'map_library.competitor'
#'
#' @param conn DBIConnection - R Database Connection Object
#'
#' @return NULL
#'
create_competitor_table <- function(conn) {

  # Validate Inputs
  if (missing(conn)) {stop("`conn` is missing in call to `create_competitor_table`", call. = FALSE)}

  # Validate Input Expectations
  expect_dbi(conn)

  # Check if 'map_library' schema already exists
  exist_qry <- "SELECT schema_name FROM information_schema.schemata WHERE schema_name = 'map_library'"
  map_library_exists <- isTRUE(nrow(DBI::dbGetQuery(conn, exist_qry)) == 1)
  if (isTRUE(map_library_exists)) {

    DBI::dbExecute(
      conn = conn,
      glue::glue(
        "
        CREATE TABLE IF NOT EXISTS map_library.competitor
        (
          competitor_hash TEXT NOT NULL CHECK (competitor_hash = encode(public.digest(competitor_name::TEXT, 'sha256'), 'hex')),
          competitor_name TEXT NOT NULL,
          CONSTRAINT comp_map_lib_competitor_pkey PRIMARY KEY (competitor_hash)
        );
        "
      )
    )

  } else {
    message("schema `map_library` DOES NOT EXIST")
  }

  # Initialize Table Contents
  if (!isTRUE(init_table_data(conn, 'map_library', 'competitor'))) {
    stop("Failure to Initialize Table Contents for `map_library.competitor`")
  }

  invisible(return(NULL))

}

#' Create Table 'map_library.twm_map'
#'
#' @param conn DBIConnection - R Database Connection Object
#'
#' @return NULL
#'
create_twm_map_table <- function(conn) {

  # Validate Inputs
  if (missing(conn)) {stop("`conn` is missing in call to `create_twm_map_table`", call. = FALSE)}

  # Validate Input Expectations
  expect_dbi(conn)

  # Check if 'map_library' schema already exists
  exist_qry <- "SELECT schema_name FROM information_schema.schemata WHERE schema_name = 'map_library'"
  map_library_exists <- isTRUE(nrow(DBI::dbGetQuery(conn, exist_qry)) == 1)
  if (isTRUE(map_library_exists)) {

    DBI::dbExecute(
      conn = conn,
      glue::glue(
        "
        CREATE TABLE IF NOT EXISTS map_library.twm_map
        (
          map_hash TEXT NOT NULL CHECK (map_hash = encode(public.digest(CONCAT(twm_item_code::TEXT, '-'::TEXT, twm_position_key::TEXT), 'sha256'), 'hex')),
          twm_item_code NUMERIC NOT NULL,
          twm_position_key INTEGER NOT NULL CHECK (twm_position_key IN (1,2,3)),
          CONSTRAINT comp_map_lib_twm_map_pkey PRIMARY KEY (map_hash)
        );
        "
      )
    )

  } else {
    message("schema `map_library` DOES NOT EXIST")
  }

  invisible(return(NULL))

}

#' Create Table 'map_library.map_lib'
#'
#' @param conn DBIConnection - R Database Connection Object
#'
#' @return NULL
#'
create_map_lib_table <- function(conn) {

  # Validate Inputs
  if (missing(conn)) {stop("`conn` is missing in call to `create_map_lib_table`", call. = FALSE)}

  # Validate Input Expectations
  expect_dbi(conn)

  # Check if 'map_library' schema already exists
  exist_qry <- "SELECT schema_name FROM information_schema.schemata WHERE schema_name = 'map_library'"
  map_library_exists <- isTRUE(nrow(DBI::dbGetQuery(conn, exist_qry)) == 1)
  if (isTRUE(map_library_exists)) {

    DBI::dbExecute(
      conn = conn,
      glue::glue(
        "
        CREATE TABLE IF NOT EXISTS map_library.map_lib
        (
          key_hash TEXT NOT NULL CHECK (encode(public.digest(key_jsonb::TEXT, 'sha256'), 'hex') = key_hash),
          key_jsonb JSONB NOT NULL,
          map_order INTEGER DEFAULT 1 CHECK (map_order > 0),
          map_hash TEXT DEFAULT NULL,
          is_primary BOOLEAN NOT NULL CHECK((is_primary AND map_order = 1) OR map_order > 1),
          CONSTRAINT comp_map_lib_map_lib_pkey PRIMARY KEY (key_hash, map_order),
          CONSTRAINT comp_map_lib_map_lib_fkey1 FOREIGN KEY (map_hash) REFERENCES map_library.twm_map (map_hash) ON DELETE RESTRICT ON UPDATE CASCADE
        );
        "
      )
    )

  } else {
    message("schema `map_library` DOES NOT EXIST")
  }

  invisible(return(NULL))

}

#' Create Table 'map_library.map_lib_update'
#'
#' @param conn DBIConnection - R Database Connection Object
#'
#' @return NULL
#'
create_map_lib_update_table <- function(conn) {

  # Validate Inputs
  if (missing(conn)) {stop("`conn` is missing in call to `create_map_lib_update_table`", call. = FALSE)}

  # Validate Input Expectations
  expect_dbi(conn)

  # Check if 'map_library' schema already exists
  exist_qry <- "SELECT schema_name FROM information_schema.schemata WHERE schema_name = 'map_library'"
  map_library_exists <- isTRUE(nrow(DBI::dbGetQuery(conn, exist_qry)) == 1)
  if (isTRUE(map_library_exists)) {

    DBI::dbExecute(
      conn = conn,
      glue::glue(
        "
        CREATE TABLE IF NOT EXISTS map_library.map_lib_update
        (
          id SERIAL NOT NULL,
          edit_time TIMESTAMPTZ NOT NULL,
          edit_type TEXT NOT NULL CHECK (edit_type IN ('I', 'U', 'D')),
          key_hash TEXT NOT NULL CHECK (encode(public.digest(key_jsonb::TEXT, 'sha256'), 'hex') = key_hash),
          key_jsonb JSONB NOT NULL,
          map_order INTEGER NOT NULL,
          map_hash TEXT DEFAULT NULL,
          is_primary BOOLEAN NOT NULL,
          CONSTRAINT comp_map_lib_map_lib_update_pkey PRIMARY KEY (id),
          CONSTRAINT comp_map_lib_map_lib_update_fkey1 FOREIGN KEY (map_hash) REFERENCES map_library.twm_map (map_hash) ON UPDATE RESTRICT ON DELETE RESTRICT
        );
        "
      )
    )

  } else {
    message("schema `map_library` DOES NOT EXIST")
  }

  invisible(return(NULL))

}

#' Create Table 'map_library.valid_key'
#'
#' @param conn DBIConnection - R Database Connection Object
#'
#' @return NULL
#'
create_valid_key_table <- function(conn) {

  # Validate Inputs
  if (missing(conn)) {stop("`conn` is missing in call to `create_valid_key_table`", call. = FALSE)}

  # Validate Input Expectations
  expect_dbi(conn)

  # Check if 'map_library' schema already exists
  exist_qry <- "SELECT schema_name FROM information_schema.schemata WHERE schema_name = 'map_library'"
  map_library_exists <- isTRUE(nrow(DBI::dbGetQuery(conn, exist_qry)) == 1)
  if (isTRUE(map_library_exists)) {

    DBI::dbExecute(
      conn = conn,
      glue::glue(
        "
        CREATE TABLE IF NOT EXISTS map_library.valid_key
        (
          name TEXT NOT NULL,
          CONSTRAINT comp_map_lib_valid_key_pkey PRIMARY KEY (name)
        );
        "
      )
    )

  } else {
    message("schema `map_library` DOES NOT EXIST")
  }

  # Initialize Table Contents
  if (!isTRUE(init_table_data(conn, 'map_library', 'valid_key'))) {
    stop("Failure to Initialize Table Contents for `map_library.valid_key`")
  }

  invisible(return(NULL))

}

#' Create Table 'map_library.valid_key_field'
#'
#' @param conn DBIConnection - R Database Connection Object
#'
#' @return NULL
#'
create_valid_key_field_table <- function(conn) {

  # Validate Inputs
  if (missing(conn)) {stop("`conn` is missing in call to `create_valid_key_field_table`", call. = FALSE)}

  # Validate Input Expectations
  expect_dbi(conn)

  # Check if 'map_library' schema already exists
  exist_qry <- "SELECT schema_name FROM information_schema.schemata WHERE schema_name = 'map_library'"
  map_library_exists <- isTRUE(nrow(DBI::dbGetQuery(conn, exist_qry)) == 1)
  if (isTRUE(map_library_exists)) {

    DBI::dbExecute(
      conn = conn,
      glue::glue(
        "
        CREATE TABLE IF NOT EXISTS map_library.valid_key_field
        (
          key TEXT NOT NULL,
          field TEXT NOT NULL,
          type TEXT NOT NULL,
          CONSTRAINT comp_map_lib_valid_key_field_pkey PRIMARY KEY (key, field),
          CONSTRAINT comp_map_lib_valid_key_field_fkey1 FOREIGN KEY (key) REFERENCES map_library.valid_key (name) ON UPDATE CASCADE ON DELETE CASCADE
        );
        "
      )
    )

  } else {
    message("schema `map_library` DOES NOT EXIST")
  }

  # Initialize Table Contents
  if (!isTRUE(init_table_data(conn, 'map_library', 'valid_key_field'))) {
    stop("Failure to Initialize Table Contents for `map_library.valid_key_field`")
  }

  invisible(return(NULL))

}

#' Create Table 'upload_files.file_log'
#'
#' @param conn DBIConnection - R Database Connection Object
#'
#' @return NULL
#'
create_file_log_table <- function(conn) {

  # Validate Inputs
  if (missing(conn)) {stop("`conn` is missing in call to `create_file_log_table`", call. = FALSE)}

  # Validate Input Expectations
  expect_dbi(conn)

  # Check if 'upload_files' schema already exists
  exist_qry <- "SELECT schema_name FROM information_schema.schemata WHERE schema_name = 'upload_files'"
  schema_exists <- isTRUE(nrow(DBI::dbGetQuery(conn, exist_qry)) == 1)
  if (isTRUE(schema_exists)) {

    DBI::dbExecute(
      conn = conn,
      glue::glue(
        "
        CREATE TABLE IF NOT EXISTS upload_files.file_log
        (
          file_hash TEXT NOT NULL,
          name TEXT NOT NULL,
          upload_dt TIMESTAMPTZ NOT NULL,
          shop_party TEXT NOT NULL,
          CONSTRAINT comp_map_lib_file_log_pkey PRIMARY KEY (file_hash)
        );
        "
      )
    )

  } else {
    message("schema `upload_files` DOES NOT EXIST")
  }

  invisible(NULL)

}

#' Create Table 'upload_files.record_log'
#'
#' @param conn DBIConnection - R Database Connection Object
#'
#' @return NULL
#'
create_record_log_table <- function(conn) {

  # Validate Inputs
  if (missing(conn)) {stop("`conn` is missing in call to `create_record_log_table`", call. = FALSE)}

  # Validate Input Expectations
  expect_dbi(conn)

  # Check if 'upload_files' schema already exists
  exist_qry <- "SELECT schema_name FROM information_schema.schemata WHERE schema_name = 'upload_files'"
  schema_exists <- isTRUE(nrow(DBI::dbGetQuery(conn, exist_qry)) == 1)
  if (isTRUE(schema_exists)) {

    DBI::dbExecute(
      conn = conn,
      glue::glue(
        "
        CREATE TABLE IF NOT EXISTS upload_files.record_log
        (
          file_hash TEXT NOT NULL,
          orig_row_num INTEGER NOT NULL CHECK (orig_row_num > 0),
          record_jsonb JSONB NOT NULL,
          record_hash TEXT NOT NULL CHECK (encode(public.digest(record_jsonb::TEXT, 'sha256'), 'hex') = record_hash),
          CONSTRAINT comp_map_lib_record_log_pkey PRIMARY KEY (file_hash, orig_row_num),
          CONSTRAINT comp_map_lib_record_log_fkey1 FOREIGN KEY (file_hash) REFERENCES upload_files.file_log (file_hash) ON UPDATE CASCADE ON DELETE CASCADE
        );
        "
      )
    )

  } else {
    message("schema `upload_files` DOES NOT EXIST")
  }

  invisible(NULL)

}

#' Create Table 'upload_files.record_match_log'
#'
#' @param conn DBIConnection - R Database Connection Object
#'
#' @return NULL
#'
create_record_match_log_table <- function(conn) {

  # Validate Inputs
  if (missing(conn)) {stop("`conn` is missing in call to `create_record_match_log_table`", call. = FALSE)}

  # Validate Input Expectations
  expect_dbi(conn)

  # Check if 'upload_files' schema already exists
  exist_qry <- "SELECT schema_name FROM information_schema.schemata WHERE schema_name = 'upload_files'"
  schema_exists <- isTRUE(nrow(DBI::dbGetQuery(conn, exist_qry)) == 1)
  if (isTRUE(schema_exists)) {

    DBI::dbExecute(
      conn = conn,
      glue::glue(
        "
        CREATE TABLE IF NOT EXISTS upload_files.record_match_log
        (
          file_hash TEXT NOT NULL,
          orig_row_num INTEGER NOT NULL CHECK (orig_row_num > 0),
          match_type TEXT NOT NULL,
          key_hash TEXT DEFAULT NULL,
          map_hash TEXT DEFAULT NULL,
          CONSTRAINT comp_map_lib_record_match_log_pkey PRIMARY KEY (file_hash, orig_row_num, match_type),
          CONSTRAINT comp_map_lib_record_match_log_fkey1 FOREIGN KEY (file_hash, orig_row_num) REFERENCES upload_files.record_log (file_hash, orig_row_num) ON UPDATE CASCADE ON DELETE CASCADE,
          CONSTRAINT comp_map_lib_record_match_log_fkey2 FOREIGN KEY (match_type) REFERENCES map_library.valid_key (name) ON UPDATE CASCADE ON DELETE CASCADE
        );
        "
      )
    )

  } else {
    message("schema `upload_files` DOES NOT EXIST")
  }

  invisible(NULL)

}

#' Create Mapping Table in Existing Schema
#'
#' @param conn DBIConnection
#' @param schema character
#' @param table character
#' @param tablename character
#' @param include_competitor logical
#'
#' @return TRUE
#' @export
#'
#' @examples
#' \dontrun{
#' create_mapping_table(
#'   conn = psql_conn,
#'   schema = 'nlsn',
#'   table = template,
#'   tablename = 'upc_num'
#' )
#' }
create_mapping_table <- function(conn, schema, table, tablename, include_competitor = FALSE) {

  # Validate Inputs
  if (missing(conn)) {stop("`conn` is missing in call to `create_mapping_table`", call. = FALSE)}
  if (missing(schema)) {stop("`schema` is missing in call to `create_mapping_table`", call. = FALSE)}
  if (missing(table)) {stop("`table` is missing in call to `create_mapping_table`", call. = FALSE)}
  if (missing(tablename)) {stop("`tablename` is missing in call to `create_mapping_table`", call. = FALSE)}
  if (missing(include_competitor)) {include_competitor <- FALSE}

  # * `conn`
  if (!isTRUE(inherits(conn, 'DBIConnection'))) {
    stop("`conn` must inherit from 'DBIConnection' in call to `create_mapping_table`", call. = FALSE)
  }

  # * `schema`
  if (!isTRUE(is.character(schema)) || !isTRUE(length(schema) == 1) || isTRUE(is.na(schema))) {
    stop("`schema` must be a character in call to `create_mapping_table`", call. = FALSE)
  }

  # * `table`
  table_is_data_frame <- isTRUE(is.data.frame(table))
  table_colnames <- isTRUE(all(purrr::map_lgl(table, ~ isTRUE(any('character' %in% class(.))))))
  table_onerow <- isTRUE(nrow(table) == 1)

  if (!isTRUE(table_is_data_frame) || !isTRUE(table_colnames) || !isTRUE(table_onerow)) {
    stop("`table` must be a data.frame with one row in call to `create_mapping_table`", call. = FALSE)
  }

  # * `tablename`
  if (!isTRUE(is.character(tablename)) || !isTRUE(length(tablename) == 1) || isTRUE(is.na(tablename))) {
    stop("`tablename` must be a character in call to `create_mapping_table`", call. = FALSE)
  }

  # * `include_competitor`
  if (!isTRUE(is.logical(include_competitor)) || !isTRUE(length(include_competitor) == 1) || isTRUE(is.na(include_competitor))) {
    stop("`include_competitor` must be a logical in call to `create_mapping_table`", call. = FALSE)
  }

  # 'Gather' table
  table <- table %>% tidyr::gather(key = 'colname', value = 'coltype')

  # Generate 'CREATE' statement
  header_stmt <- paste0("CREATE TABLE IF NOT EXISTS {schema}.{tablename} (\n\n ")

  if (isTRUE(include_competitor)) {

    key_hash_name <- c(paste0("'", table$colname, "'"), "'competitor_hash'", "'map_order'", "'schema'", "'table'")
    key_hash_val <- c(table$colname, "competitor_hash", "map_order", paste0("'", schema, "'"), paste0("'", tablename, "'"))

    key_hash_col_stmt <- paste0(paste(key_hash_name, key_hash_val, sep = ', '), collapse = ', ')

    column_stmt <- paste0(
      "key_hash TEXT NOT NULL CHECK (key_hash = encode(public.digest(jsonb_build_object(", key_hash_col_stmt, ")::TEXT, 'sha256'), 'hex')), \n\n",
      paste(table$colname, table$coltype, ' NOT NULL, \n', collapse = ' '),
      '\n map_order INTEGER DEFAULT 1 CHECK (map_order > 0),',
      '\n is_primary BOOLEAN DEFAULT TRUE CHECK((is_primary AND map_order = 1) OR map_order > 1),',
      '\n competitor_hash TEXT NOT NULL,',
      '\n map_hash TEXT DEFAULT NULL,\n\n '
    )

    constraint_stmt <- paste0(
      'CONSTRAINT comp_map_lib_{schema}_{tablename}_unq UNIQUE (key_hash), \n\n ',
      'CONSTRAINT comp_map_lib_{schema}_{tablename}_pkey PRIMARY KEY (', paste0(c(table$colname, 'map_order', 'competitor_hash'), collapse = ', '), '), \n\n ',
      'CONSTRAINT comp_map_lib_{schema}_{tablename}_twm_map_fkey1 FOREIGN KEY (map_hash) REFERENCES map_library.twm_map (map_hash) ON UPDATE CASCADE ON DELETE RESTRICT, \n',
      'CONSTRAINT comp_map_lib_{schema}_{tablename}_twm_map_fkey2 FOREIGN KEY (competitor_hash) REFERENCES map_library.competitor (competitor_hash) ON UPDATE CASCADE ON DELETE RESTRICT '
    )

  } else if (isFALSE(include_competitor)) {

    key_hash_name <- c(paste0("'", table$colname, "'"), "'map_order'", "'schema'", "'table'")
    key_hash_val <- c(table$colname, "map_order", paste0("'", schema, "'"), paste0("'", tablename, "'"))

    key_hash_col_stmt <- paste0(paste(key_hash_name, key_hash_val, sep = ', '), collapse = ', ')

    column_stmt <- paste0(
      "key_hash TEXT NOT NULL CHECK (key_hash = encode(public.digest(jsonb_build_object(", key_hash_col_stmt, ")::TEXT, 'sha256'), 'hex')), \n\n",
      paste(table$colname, table$coltype, ' NOT NULL, \n', collapse = ' '),
      '\n map_order INTEGER DEFAULT 1 CHECK (map_order > 0),',
      '\n is_primary BOOLEAN DEFAULT TRUE CHECK((is_primary AND map_order = 1) OR map_order > 1),',
      '\n map_hash TEXT DEFAULT NULL,\n\n '
    )

    constraint_stmt <- paste0(
      'CONSTRAINT comp_map_lib_{schema}_{tablename}_unq UNIQUE (key_hash), \n\n ',
      'CONSTRAINT comp_map_lib_{schema}_{tablename}_pkey PRIMARY KEY (', paste0(c(table$colname, 'map_order'), collapse = ', '), '), \n\n ',
      'CONSTRAINT comp_map_lib_{schema}_{tablename}_twm_map_fkey FOREIGN KEY (map_hash) REFERENCES map_library.twm_map (map_hash) ON UPDATE CASCADE ON DELETE RESTRICT '
    )

  } else {
    stop("`include_competitor` must be a logical in call to `create_mapping_table`", call. = FALSE)
  }

  end_stmt <- paste0("\n\n)")

  create_stmt <- glue::glue(paste0(header_stmt, column_stmt, constraint_stmt, end_stmt, collapse = ' '))

  # Execute 'CREATE' statement
  tryCatch({

    DBI::dbBegin(conn)
    DBI::dbExecute(conn, create_stmt)
    DBI::dbCommit(conn)

  }, warning = function(w) {
    message(sprintf("Warning in %s: %s", deparse(w[["call"]]), w[["message"]]))
  }, error = function(e) {

    DBI::dbRollback(conn)
    message(sprintf("Error in %s: %s", deparse(e[["call"]]), e[["message"]]))

  })

  # Return Success
  invisible(TRUE)

}



#' Rebuild New Mapping Table in Existing Schema
#'
#' @param conn DBIConnection
#' @param schema character
#' @param table character
#' @param tablename character
#' @param include_competitor logical
#'
#' @return TRUE
#' @export
#'
#' @examples
#' \dontrun{
#' rebuild_mapping_table(
#'   conn = psql_conn,
#'   schema = 'nlsn',
#'   table = template,
#'   tablename = 'upc_num_v2'
#' )
#' }
rebuild_mapping_table <- function(conn, schema, table, tablename, include_competitor = FALSE) {

  # Validate Inputs
  if (missing(conn)) {stop("`conn` is missing in call to `rebuild_mapping_table`", call. = FALSE)}
  if (missing(schema)) {stop("`schema` is missing in call to `rebuild_mapping_table`", call. = FALSE)}
  if (missing(table)) {stop("`table` is missing in call to `rebuild_mapping_table`", call. = FALSE)}
  if (missing(tablename)) {stop("`tablename` is missing in call to `rebuild_mapping_table`", call. = FALSE)}
  if (missing(include_competitor)) {include_competitor <- FALSE}

  # * `conn`
  if (!isTRUE(inherits(conn, 'DBIConnection'))) {
    stop("`conn` must inherit from 'DBIConnection' in call to `rebuild_mapping_table`", call. = FALSE)
  }

  # * `schema`
  if (!isTRUE(is.character(schema)) || !isTRUE(length(schema) == 1) || isTRUE(is.na(schema))) {
    stop("`schema` must be a character in call to `rebuild_mapping_table`", call. = FALSE)
  }

  # * `table`
  table_is_data_frame <- isTRUE(is.data.frame(table))
  table_colnames <- isTRUE(all(purrr::map_lgl(table, ~ isTRUE(any('character' %in% class(.))))))
  table_onerow <- isTRUE(nrow(table) == 1)

  if (!isTRUE(table_is_data_frame) || !isTRUE(table_colnames) || !isTRUE(table_onerow)) {
    stop("`table` must be a data.frame with one row in call to `rebuild_mapping_table`", call. = FALSE)
  }

  # * `tablename`
  if (!isTRUE(is.character(tablename)) || !isTRUE(length(tablename) == 1) || isTRUE(is.na(tablename))) {
    stop("`tablename` must be a character in call to `rebuild_mapping_table`", call. = FALSE)
  }

  # * `include_competitor`
  if (!isTRUE(is.logical(include_competitor)) || !isTRUE(length(include_competitor) == 1) || isTRUE(is.na(include_competitor))) {
    stop("`include_competitor` must be a logical in call to `rebuild_mapping_table`", call. = FALSE)
  }

  # 'Gather' table
  table <- table %>% tidyr::gather(key = 'colname', value = 'coltype')

  # Generate 'CREATE' statement
  header_stmt <- paste0("CREATE TABLE IF NOT EXISTS {schema}.{tablename} (\n\n ")

  if (isTRUE(include_competitor)) {

    key_hash_name <- c(paste0("'", table$colname, "'"), "'competitor_hash'", "'map_order'", "'schema'", "'table'")
    key_hash_val <- c(table$colname, "competitor_hash", "map_order", paste0("'", schema, "'"), paste0("'", tablename, "'"))

    key_hash_col_stmt <- paste0(paste(key_hash_name, key_hash_val, sep = ', '), collapse = ', ')

    column_stmt <- paste0(
      "key_hash TEXT NOT NULL CHECK (key_hash = encode(public.digest(jsonb_build_object(", key_hash_col_stmt, ")::TEXT, 'sha256'), 'hex')), \n\n",
      paste(table$colname, table$coltype, ' NOT NULL, \n', collapse = ' '),
      '\n map_order INTEGER DEFAULT 1 CHECK (map_order > 0),',
      '\n is_primary BOOLEAN DEFAULT TRUE CHECK((is_primary AND map_order = 1) OR map_order > 1),',
      '\n competitor_hash TEXT NOT NULL,',
      '\n map_hash TEXT DEFAULT NULL,\n\n '
    )

    constraint_stmt <- paste0(
      'CONSTRAINT comp_map_lib_{schema}_{tablename}_unq UNIQUE (key_hash), \n\n ',
      'CONSTRAINT comp_map_lib_{schema}_{tablename}_pkey PRIMARY KEY (', paste0(c(table$colname, 'map_order', 'competitor_hash'), collapse = ', '), '), \n\n ',
      'CONSTRAINT comp_map_lib_{schema}_{tablename}_twm_map_fkey1 FOREIGN KEY (map_hash) REFERENCES map_library.twm_map (map_hash) ON UPDATE CASCADE ON DELETE RESTRICT, \n',
      'CONSTRAINT comp_map_lib_{schema}_{tablename}_twm_map_fkey2 FOREIGN KEY (competitor_hash) REFERENCES map_library.competitor (competitor_hash) ON UPDATE CASCADE ON DELETE RESTRICT '
    )

  } else if (isFALSE(include_competitor)) {

    key_hash_name <- c(paste0("'", table$colname, "'"), "'map_order'", "'schema'", "'table'")
    key_hash_val <- c(table$colname, "map_order", paste0("'", schema, "'"), paste0("'", tablename, "'"))

    key_hash_col_stmt <- paste0(paste(key_hash_name, key_hash_val, sep = ', '), collapse = ', ')

    column_stmt <- paste0(
      "key_hash TEXT NOT NULL CHECK (key_hash = encode(public.digest(jsonb_build_object(", key_hash_col_stmt, ")::TEXT, 'sha256'), 'hex')), \n\n",
      paste(table$colname, table$coltype, ' NOT NULL, \n', collapse = ' '),
      '\n map_order INTEGER DEFAULT 1 CHECK (map_order > 0),',
      '\n is_primary BOOLEAN DEFAULT TRUE CHECK((is_primary AND map_order = 1) OR map_order > 1),',
      '\n map_hash TEXT DEFAULT NULL,\n\n '
    )

    constraint_stmt <- paste0(
      'CONSTRAINT comp_map_lib_{schema}_{tablename}_unq UNIQUE (key_hash), \n\n ',
      'CONSTRAINT comp_map_lib_{schema}_{tablename}_pkey PRIMARY KEY (', paste0(c(table$colname, 'map_order'), collapse = ', '), '), \n\n ',
      'CONSTRAINT comp_map_lib_{schema}_{tablename}_twm_map_fkey FOREIGN KEY (map_hash) REFERENCES map_library.twm_map (map_hash) ON UPDATE CASCADE ON DELETE RESTRICT '
    )

  } else {
    stop("`include_competitor` must be a logical in call to `rebuild_mapping_table`", call. = FALSE)
  }

  end_stmt <- paste0("\n\n)")

  create_stmt <- glue::glue(paste0(header_stmt, column_stmt, constraint_stmt, end_stmt, collapse = ' '))

  # # Execute 'CREATE' statement
  # tryCatch({
  #
  #   DBI::dbBegin(conn)
  #   DBI::dbExecute(conn, create_stmt)
  #   DBI::dbCommit(conn)
  #
  # }, warning = function(w) {
  #   message(sprintf("Warning in %s: %s", deparse(w[["call"]]), w[["message"]]))
  # }, error = function(e) {
  #
  #   DBI::dbRollback(conn)
  #   message(sprintf("Error in %s: %s", deparse(e[["call"]]), e[["message"]]))
  #
  # })
  #
  # # Return Success
  # invisible(TRUE)

  return(create_stmt)

}


#' Create TWM Item UPC Table
#'
#' @param conn DBIConnection
#'
#' @return data.frame
#'
#' @examples
#' \dontrun{
#' create_twm_item_upc_table()
#' }
create_twm_item_upc_table <- function(conn) {

  # Validate Inputs
  if (missing(conn)) {stop("`conn` is missing in call to `create_twm_item_upc_table`", call. = FALSE)}

  # Validate Input Expectations
  expect_dbi(conn)

  # Drop Table if Exists
  suppressMessages({DBI::dbExecute(conn = conn, glue::glue("DROP TABLE IF EXISTS map_library.twm_item_upc"))})

  # Refresh Table Contents
  twm_item_upc <- refresh_twm_item_upc(conn)

  # Return Success
  invisible(twm_item_upc)

}

#' Drop Table 'map_library.competitor'
#'
#' @param conn DBIConnection - R Database Connection Object
#'
#' @return NULL
#'
drop_competitor_table <- function(conn) {

  # Validate Inputs
  if (missing(conn)) {stop("`conn` is missing in call to `drop_competitor_table`", call. = FALSE)}

  # Validate Input Expectations
  expect_dbi(conn)

  DBI::dbExecute(conn = conn, glue::glue("DROP TABLE IF EXISTS map_library.competitor"))

}

#' Drop Table 'map_library.twm_map'
#'
#' @param conn DBIConnection - R Database Connection Object
#'
#' @return NULL
#'
drop_twm_map_table <- function(conn) {

  # Validate Inputs
  if (missing(conn)) {stop("`conn` is missing in call to `drop_twm_map_table`", call. = FALSE)}

  # Validate Input Expectations
  expect_dbi(conn)

  # Check if 'map_library' schema already exists
  DBI::dbExecute(conn = conn, glue::glue("DROP TABLE IF EXISTS map_library.twm_map"))

}

#' Drop Table 'map_library.map_lib'
#'
#' @param conn DBIConnection - R Database Connection Object
#'
#' @return NULL
#'
drop_map_lib_table <- function(conn) {

  # Validate Inputs
  if (missing(conn)) {stop("`conn` is missing in call to `drop_map_lib_table`", call. = FALSE)}

  # Validate Input Expectations
  expect_dbi(conn)

  # Check if 'map_library' schema already exists
  DBI::dbExecute(conn = conn, glue::glue("DROP TABLE IF EXISTS map_library.map_lib"))

}

#' Drop Table 'map_library.map_lib_update'
#'
#' @param conn DBIConnection - R Database Connection Object
#'
#' @return NULL
#'
drop_map_lib_update_table <- function(conn) {

  # Validate Inputs
  if (missing(conn)) {stop("`conn` is missing in call to `drop_map_lib_update_table`", call. = FALSE)}

  # Validate Input Expectations
  expect_dbi(conn)

  # Check if 'map_library' schema already exists
  DBI::dbExecute(conn = conn, glue::glue("DROP TABLE IF EXISTS map_library.map_lib_update"))

}

#' Drop Table 'map_library.valid_key'
#'
#' @param conn DBIConnection - R Database Connection Object
#'
#' @return NULL
#'
drop_valid_key_table <- function(conn) {

  # Validate Inputs
  if (missing(conn)) {stop("`conn` is missing in call to `drop_valid_key_table`", call. = FALSE)}

  # Validate Input Expectations
  expect_dbi(conn)

  # Check if 'map_library' schema already exists
  DBI::dbExecute(conn = conn, glue::glue("DROP TABLE IF EXISTS map_library.valid_key"))

}

#' Drop Table 'map_library.valid_key_field'
#'
#' @param conn DBIConnection - R Database Connection Object
#'
#' @return NULL
#'
drop_valid_key_field_table <- function(conn) {

  # Validate Inputs
  if (missing(conn)) {stop("`conn` is missing in call to `drop_valid_key_field_table`", call. = FALSE)}

  # Validate Input Expectations
  expect_dbi(conn)

  # Check if 'map_library' schema already exists
  DBI::dbExecute(conn = conn, glue::glue("DROP TABLE IF EXISTS map_library.valid_key_field"))

}

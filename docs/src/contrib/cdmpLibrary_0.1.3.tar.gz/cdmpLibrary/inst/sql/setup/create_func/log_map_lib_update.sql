
CREATE OR REPLACE FUNCTION public.log_map_lib_update() 
   RETURNS TRIGGER 
   LANGUAGE PLPGSQL
AS $$
BEGIN
   
   IF (TG_OP = 'INSERT') THEN
      
      INSERT INTO map_library.map_lib_update (edit_time, edit_type, key_hash, key_jsonb, map_order, map_hash, is_primary) 
      SELECT 
      clock_timestamp() as edit_time, 
      'I' as edit_type, 
      t.key_hash, 
      t.key_jsonb, 
      t.map_order, 
      t.map_hash, 
      t.is_primary 
      FROM new_table t; 
      
   ELSIF (TG_OP = 'UPDATE') THEN
      
      INSERT INTO map_library.map_lib_update (edit_time, edit_type, key_hash, key_jsonb, map_order, map_hash, is_primary) 
      SELECT 
      clock_timestamp() as edit_time, 
      'U' as edit_type, 
      t.key_hash, 
      t.key_jsonb, 
      t.map_order, 
      t.map_hash, 
      t.is_primary
      FROM new_table t 
      INNER JOIN old_table o 
      ON t.key_hash = o.key_hash 
      AND t.map_order = o.map_order 
      WHERE (o.map_hash IS NULL or t.map_hash IS NULL) OR (o.map_hash != t.map_hash) OR (o.is_primary != t.is_primary); 
      
   ELSIF (TG_OP = 'DELETE') THEN
      
      INSERT INTO map_library.map_lib_update (edit_time, edit_type, key_hash, key_jsonb, map_order, map_hash, is_primary) 
      SELECT 
      clock_timestamp() as edit_time, 
      'D' as edit_type, 
      t.key_hash, 
      t.key_jsonb, 
      t.map_order, 
      t.map_hash, 
      t.is_primary
      FROM old_table t;
      
   END IF;

   RETURN NULL;
   
END;
$$

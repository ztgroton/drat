
CREATE OR REPLACE FUNCTION public.tcol_columns(
  sch TEXT,
  tbl TEXT,
  rm_col TEXT[] DEFAULT array[]::TEXT[],
  use_col TEXT[] DEFAULT array[]::TEXT[]
)
  RETURNS TEXT
  LANGUAGE PLPGSQL
AS $$
DECLARE

  result TEXT[];

BEGIN

  -- Initialize 'use_col' with ALL COLUMN NAMES (if empty by default)
  IF ((array_length(use_col, 1) = 0) OR (array_length(use_col, 1) IS NULL))  THEN
    use_col := ARRAY(
      SELECT c.column_name::TEXT
      FROM information_schema.columns c

      INNER JOIN information_schema.tables t
      ON t.table_name = c.table_name
      AND t.table_schema = c.table_schema
      AND t.table_catalog = c.table_catalog

      WHERE c.table_schema = sch::TEXT
      AND c.table_name = tbl::TEXT
      AND t.table_type = 'BASE TABLE'
      ORDER BY t.table_schema, t.table_name, c.ordinal_position
    );
  END IF;

  -- Append Dummy Column Name to 'rm_col' (ensures it is never empty)
  rm_col := array_append(rm_col, 'THIS_IS_A_DUMMY_COLUMN_vfdsaokvfjnfdaskfjreoiv'::TEXT);

  -- Insert Table Columns into Text Array
  result := ARRAY(

      SELECT CONCAT('t.'::TEXT, c.column_name)::TEXT
      FROM information_schema.columns c

      INNER JOIN information_schema.tables t
      ON t.table_name = c.table_name
      AND t.table_schema = c.table_schema
      AND t.table_catalog = c.table_catalog

      WHERE c.table_schema = sch::TEXT
      AND c.table_name = tbl::TEXT
      AND t.table_type = 'BASE TABLE'

      AND c.column_name IN (
        SELECT id
        FROM unnest(use_col) as id
      )

      AND c.column_name NOT IN (
        SELECT id
        FROM unnest(rm_col) as id
      )

      ORDER BY t.table_schema, t.table_name, c.ordinal_position
  );

  -- Return Result
  RETURN result;

END;
$$

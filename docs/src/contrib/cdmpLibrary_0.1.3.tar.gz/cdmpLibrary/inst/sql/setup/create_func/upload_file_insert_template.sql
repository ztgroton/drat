
CREATE OR REPLACE FUNCTION public.upload_file_insert_template(upload_schema TEXT, upload_table TEXT, map_schema TEXT, map_table TEXT) 
  RETURNS TEXT
  LANGUAGE PLPGSQL
AS $$
DECLARE 
  
  result TEXT;
  
BEGIN 
  
  -- Build SELECT statement to generate key values
  SELECT format(
    CONCAT(
      --'insert into upload_files.record_match_log (upload_date, file_name, orig_row_num, key_hash, key_jsonb) ', 
      'select '::TEXT, 
      't.upload_date, '::TEXT, 
      't.file_name, '::TEXT, 
      't.orig_row_num, '::TEXT, 
      public.sha256_template(map_schema, map_table)::TEXT, ' as key_hash, ',  
      public.jsonb_template(map_schema, map_table)::TEXT, ' as key_jsonb ', 
      'from %I.%I t '
    )::TEXT
    , upload_schema, upload_table
  ) INTO result;
  
  -- Return Result 
  RETURN result;
  
END; 
$$


CREATE OR REPLACE FUNCTION public.pk_col_hash(sch TEXT, tbl TEXT, log_tbl BOOLEAN DEFAULT TRUE)
  RETURNS TEXT
  LANGUAGE PLPGSQL
AS $$
DECLARE

  jsonb_txt TEXT;
  result TEXT;

BEGIN

  -- Insert Primary Key Columns into Text Array
  SELECT public.pk_col_jsonb(sch, tbl, log_tbl) INTO jsonb_txt;

  -- Create JSONB Element Template from input Column text value
  SELECT CONCAT('encode(public.digest('::TEXT, jsonb_txt::TEXT, '::TEXT, ''sha256''), ''hex'')'::TEXT) INTO result;

  -- Return Result
  RETURN result;

END;
$$

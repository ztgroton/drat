
CREATE TABLE IF NOT EXISTS common.pk_col
(
  id SERIAL,
  tab_id INTEGER NOT NULL,
  col_id INTEGER NOT NULL,

  CONSTRAINT common_pk_pkey PRIMARY KEY (id),
  CONSTRAINT common_pk_fkey1 FOREIGN KEY (tab_id, col_id) REFERENCES common.tab_col (tab_id, col_id) ON UPDATE CASCADE ON DELETE RESTRICT,
  CONSTRAINT common_pk_unq1 UNIQUE (tab_id, col_id)
)


CREATE TABLE IF NOT EXISTS common.default_type_map
(
  conn_type_id INTEGER NOT NULL CHECK (conn_type_id > 0),
  field_type_id INTEGER NOT NULL CHECK (field_type_id > 0),
  sql_type TEXT NOT NULL,
  r_order INTEGER NOT NULL CHECK (r_order > 0),

  CONSTRAINT common_default_type_map_pkey PRIMARY KEY (conn_type_id, field_type_id, r_order),
  CONSTRAINT common_default_type_map_fkey1 FOREIGN KEY (conn_type_id) REFERENCES common.conn_type (id) ON UPDATE CASCADE ON DELETE RESTRICT,
  CONSTRAINT common_default_type_map_fkey2 FOREIGN KEY (field_type_id) REFERENCES common.field_type (id) ON UPDATE CASCADE ON DELETE RESTRICT
)

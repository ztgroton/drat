
SELECT
t.table_catalog as "db",
t.table_schema as "schema",
t.table_name as "table"
FROM information_schema.tables t
WHERE t.table_schema = {sch}

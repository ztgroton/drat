
create table merchandising.{result} as

WITH raw_row AS
(
  select {columns_w_comma},
  ROW_NUMBER() OVER() as orig_row_num
  from {schema}.{table}
),

agg_row AS
(
  select
  {columns_w_comma},
  ARRAY_AGG(orig_row_num) as nest_row_num
  from raw_row
  group by {columns_w_comma}
)

select t.*,
ARRAY_LENGTH(t.nest_row_num) as nest_row_cnt
from agg_row t

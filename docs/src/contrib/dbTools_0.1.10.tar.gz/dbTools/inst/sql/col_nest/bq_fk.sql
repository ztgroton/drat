create table merchandising.{result} as

WITH unq_value AS
(
  select {child_columns_w_comma}
  from {child_schema}.{child_table} t1
  union distinct
  select {parent_columns_w_comma_and_names}
  from {parent_schema}.{parent_table} t2
),

child_raw_row AS
(
  select {child_columns_w_comma},
  ROW_NUMBER() OVER() as orig_row_num
  from {child_schema}.{child_table} t1
),

child_agg_row AS
(
  select
  {child_columns_w_comma},
  ARRAY_AGG(t1.orig_row_num) as nest_row_num
  from child_raw_row t1
  group by {child_columns_w_comma}
),

child_final AS
(
  select t.*,
  ARRAY_LENGTH(t.nest_row_num) as nest_row_cnt
  from child_agg_row t
),

parent_raw_row AS
(
  select {parent_columns_w_comma},
  ROW_NUMBER() OVER() as orig_row_num
  from {parent_schema}.{parent_table} t2
),

parent_agg_row AS
(
  select
  {parent_columns_w_comma},
  ARRAY_AGG(t2.orig_row_num) as nest_row_num
  from parent_raw_row t2
  group by {parent_columns_w_comma}
),

parent_final AS
(
  select t.*,
  ARRAY_LENGTH(t.nest_row_num) as nest_row_cnt
  from parent_agg_row t
),

child_unq_value AS
(
  select t.*,
  ct.nest_row_num as child_nest_row_num,
  ct.nest_row_cnt as child_nest_row_cnt

  from unq_value t

  left outer join child_final ct
  {child_join}
)

select t.*,
pt.nest_row_num as parent_nest_row_num,
pt.nest_row_cnt as parent_nest_row_cnt

from child_unq_value t

left outer join parent_final pt
{parent_join}

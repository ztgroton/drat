
#' S3 Method - Create New Entry in 'db_projects'
#'
#' @param obj S3 Class
#' @param ... ellipsis
#'
#' @return TRUE
#' @export
#'
db_proj_create.db_proj_field_type <- function(obj, ...) {

  # Validate Input
  if (missing(obj)) {
    stop("`obj` is missing in call to `db_proj_create.db_proj_field_type`", call. = FALSE)
  }

  # Gather `dot_arg`
  dot_arg <- dots_to_list(...)

  # Validate `obj`
  is_valid_obj <- validate_db_proj_field_type(obj, TRUE)
  if (!isTRUE(is_valid_obj)) {
    stop("`obj` is not valid in call to db_proj_create.db_proj_field_type", call. = FALSE)
  }

  # Prepare Upload Data
  upload_data <- data.frame(
    name = obj$name,
    stringsAsFactors = FALSE
  )

  # Upsert Data
  psql_conn <- psql_db_connect('db_projects')
  table_id <- DBI::Id(schema = 'common', table = 'field_type')

  dbx::dbxUpsert(
    conn = psql_conn,
    table = table_id,
    records = upload_data,
    where_cols = 'name',
    skip_existing = TRUE
  )

  DBI::dbDisconnect(psql_conn)
  rm(psql_conn)

  # Return Success
  invisible(TRUE)

}

#' S3 Method - Create New Entry in 'db_projects'
#'
#' @param obj S3 Class
#' @param ... ellipsis
#'
#' @return TRUE
#' @export
#'
db_proj_create.db_proj_conn_type <- function(obj, ...) {

  # Validate Input
  if (missing(obj)) {
    stop("`obj` is missing in call to `db_proj_create.db_proj_conn_type`", call. = FALSE)
  }

  # Gather `dot_arg`
  dot_arg <- dots_to_list(...)

  # Validate `obj`
  is_valid_obj <- validate_db_proj_conn_type(obj, TRUE)
  if (!isTRUE(is_valid_obj)) {
    stop("`obj` is not valid in call to db_proj_create.db_proj_conn_type", call. = FALSE)
  }

  # Prepare Upload Data
  upload_data <- data.frame(
    name = obj$name,
    stringsAsFactors = FALSE
  )

  # Upsert Data
  psql_conn <- psql_db_connect('db_projects')
  table_id <- DBI::Id(schema = 'common', table = 'conn_type')

  dbx::dbxUpsert(
    conn = psql_conn,
    table = table_id,
    records = upload_data,
    where_cols = 'name',
    skip_existing = TRUE
  )

  DBI::dbDisconnect(psql_conn)
  rm(psql_conn)

  # Return Success
  invisible(TRUE)

}

#' S3 Method - Create New Entry in 'db_projects'
#'
#' @param obj S3 Class
#' @param ... ellipsis
#'
#' @return TRUE
#' @export
#'
db_proj_create.db_proj_default_type_map <- function(obj, ...) {

  # Validate Input
  if (missing(obj)) {
    stop("`obj` is missing in call to `db_proj_create.db_proj_default_type_map`", call. = FALSE)
  }

  # Gather `dot_arg`
  dot_arg <- dots_to_list(...)

  # Validate `obj`
  is_valid_obj <- validate_db_proj_default_type_map(obj, TRUE)
  if (!isTRUE(is_valid_obj)) {
    stop("`obj` is not valid in call to `db_proj_create.db_proj_default_type_map`", call. = FALSE)
  }

  # Connect to DB
  psql_conn <- psql_db_connect('db_projects')

  # Query `conn_type` details
  table_conn_type <- DBI::Id(schema = 'common', table = 'conn_type')
  conn_type_id <- DBI::dbGetQuery(
    conn = psql_conn,
    glue::glue_sql(
      "select t.id from {`table_conn_type`} t where t.name = {name}",
      name = obj$name,
      .con = psql_conn
    )
  ) %>% dplyr::pull(id)

  if (!isTRUE(length(conn_type_id) == 1)) {
    stop("`conn_type_id` must have length 1 in call to `db_proj_create.db_proj_default_type_map`", call. = FALSE)
  }

  # Query `field_type` details
  table_field_type <- DBI::Id(schema = 'common', table = 'field_type')
  field_type_id <- DBI::dbGetQuery(
    conn = psql_conn,
    glue::glue_sql(
      "select t.id from {`table_field_type`} t where t.name = {name}",
      name = obj$name,
      .con = psql_conn
    )
  ) %>% dplyr::pull(id)

  if (!isTRUE(length(field_type_id) == 1)) {
    stop("`field_type_id` must have length 1 in call to `db_proj_create.db_proj_default_type_map`", call. = FALSE)
  }

  # Get Max `r_order`
  table_default_type_map <- DBI::Id(schema = 'common', table = 'default_type_map')
  max_r_order <- DBI::dbGetQuery(
    conn = psql_conn,
    glue::glue_sql(
      "select max(t.r_order) as max_r_order
      from {`table_default_type_map`} t
      where t.conn_type_id = {conn_type_id}
      and t.field_type_id = {field_type_id}",
      .con = psql_conn
    )
  ) %>% dplyr::pull(max_r_order) %>%
    c(0) %>% max(na.rm = TRUE)

  # Prepare Upload Data
  upload_data <- data.frame(
    conn_type_id = conn_type_id,
    field_type_id = field_type_id,
    sql_type = obj$sql_type,
    r_order = max_r_order + 1,
    stringsAsFactors = FALSE
  )

  # Upsert Data
  dbx::dbxUpsert(
    conn = psql_conn,
    table = table_default_type_map,
    records = upload_data,
    where_cols = c('conn_type_id', 'field_type_id', 'r_order'),
    skip_existing = TRUE
  )

  DBI::dbDisconnect(psql_conn)
  rm(psql_conn)

  # Return Success
  invisible(TRUE)

}

#' S3 Method - Create New Entry in 'db_projects'
#'
#' @param obj S3 Class
#' @param ... ellipsis
#'
#' @return TRUE
#' @export
#'
db_proj_create.db_proj_conn <- function(obj, ...) {

  # Validate Input
  if (missing(obj)) {
    stop("`obj` is missing in call to `db_proj_create.db_proj_conn`", call. = FALSE)
  }

  # Gather `dot_arg`
  dot_arg <- dots_to_list(...)

  # Validate `obj`
  is_valid_obj <- validate_db_proj_conn(obj, TRUE)
  if (!isTRUE(is_valid_obj)) {
    stop("`obj` is not valid in call to `db_proj_create.db_proj_conn`", call. = FALSE)
  }

  # Connect to DB
  psql_conn <- psql_db_connect('db_projects')

  # Query `conn_type` details
  table_conn_type <- DBI::Id(schema = 'common', table = 'conn_type')
  conn_type_id <- DBI::dbGetQuery(
    conn = psql_conn,
    glue::glue_sql(
      "select t.id from {`table_conn_type`} t where t.name = {type}",
      type = obj$type,
      .con = psql_conn
    )
  ) %>% dplyr::pull(id)

  if (!isTRUE(length(conn_type_id) == 1)) {
    stop("`conn_type_id` must have length 1 in call to `db_proj_create.db_proj_conn`", call. = FALSE)
  }

  # Prepare Upload Data
  upload_data <- data.frame(
    conn_type_id = conn_type_id,
    name = obj$conn,
    stringsAsFactors = FALSE
  )

  # Upsert Data
  table_conn <- DBI::Id(schema = 'common', table = 'conn')
  dbx::dbxUpsert(
    conn = psql_conn,
    table = table_conn,
    records = upload_data,
    where_cols = c('name'),
    skip_existing = TRUE
  )

  DBI::dbDisconnect(psql_conn)
  rm(psql_conn)

  # Return Success
  invisible(TRUE)

}

#' S3 Method - Create New Entry in 'db_projects'
#'
#' @param obj S3 Class
#' @param ... ellipsis
#'
#' @return TRUE
#' @export
#'
db_proj_create.db_proj_conn_param <- function(obj, ...) {

  # Validate Input
  if (missing(obj)) {
    stop("`obj` is missing in call to `db_proj_create.db_proj_conn_param`", call. = FALSE)
  }

  # Gather `dot_arg`
  dot_arg <- dots_to_list(...)

  # Validate `obj`
  is_valid_obj <- validate_db_proj_conn_param(obj, TRUE)
  if (!isTRUE(is_valid_obj)) {
    stop("`obj` is not valid in call to `db_proj_create.db_proj_conn_param`", call. = FALSE)
  }

  # Connect to DB
  psql_conn <- psql_db_connect('db_projects')

  # Query `conn` details
  table_conn <- DBI::Id(schema = 'common', table = 'conn')
  conn_id <- DBI::dbGetQuery(
    conn = psql_conn,
    glue::glue_sql(
      "select t.id from {`table_conn`} t where t.name = {conn}",
      conn = obj$conn,
      .con = psql_conn
    )
  ) %>% dplyr::pull(id)

  if (!isTRUE(length(conn_id) == 1)) {
    stop("`conn_id` must have length 1 in call to `db_proj_create.db_proj_conn_param`", call. = FALSE)
  }

  # Prepare Upload Data
  upload_data <- data.frame(
    conn_id = conn_id,
    param = obj$param,
    value = obj$value,
    stringsAsFactors = FALSE
  )

  # Upsert Data
  table_conn_param <- DBI::Id(schema = 'common', table = 'conn_param')
  dbx::dbxUpsert(
    conn = psql_conn,
    table = table_conn_param,
    records = upload_data,
    where_cols = c('conn_id', 'param'),
    skip_existing = TRUE
  )

  DBI::dbDisconnect(psql_conn)
  rm(psql_conn)

  # Return Success
  invisible(TRUE)

}

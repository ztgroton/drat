
#' Generate a Unique Column Name, using a data frame and character string
#'
#' @param x data.frame - column names are used to check 'uniqueness'
#' @param name character - used as a starting point to generate unique value (if neccessary)
#'
#' @return character - final unique column name
#' @export
#'
unq_colname <- function(x, name) {

  # Validate Inputs
  if (missing(x)) {stop("`x` is missing in call to `unq_colname`", call. = FALSE)}
  if (!isTRUE(is.data.frame(x))) {stop("`x` must be `data.frame` in call to `unq_colname`", call. = FALSE)}

  if (missing(name)) {stop("`name` is missing in call to `unq_colname`", call. = FALSE)}
  if (!isTRUE(is.character(name))) {
    stop("`name` must be character in call to `unq_colname`", call. = FALSE)
  } else if (!isTRUE(length(name) == 1)) {
    stop("`name` must be length 1 in call to `unq_colname`", call. = FALSE)
  } else if (isTRUE(is.na(name))) {
    stop("`name` cannot be NA in call to `unq_colname`", call. = FALSE)
  }

  # Return `name` if not already present in `colnames(x)`
  if (!isTRUE(name %in% colnames(x))) {return(name)}

  # Compute new unique column name
  colnames_x <- unique(colnames(x))
  unq_colnames_x <- make.unique(c(name, colnames_x), sep = '_')
  unq_name <- setdiff(unq_colnames_x, colnames_x)

  if (!isTRUE(length(unq_name) == 1)) {
    stop("FUNCTIONAL ERROR - `unq_name` must have length 1 in call to `unq_colname`", call. = FALSE)
  } else {
    return(unq_name)
  }

}

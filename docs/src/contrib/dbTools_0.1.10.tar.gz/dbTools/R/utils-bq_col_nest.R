
#' Generate SQL Statement for 'BigQuery' SQL Colnest
#'
#' @param result character
#' @param dataset character
#' @param table character
#' @param columns character
#'
#' @return SQL Text
#' @export
#'
bq_col_nest <- function(result, dataset, table, columns) {

  # Validate Inputs
  if (missing(result)) {stop("`result` is mising in call to `bq_col_nest`", call. = FALSE)}
  if (missing(dataset)) {stop("`dataset` is mising in call to `bq_col_nest`", call. = FALSE)}
  if (missing(table)) {stop("`table` is missing in call to `bq_col_nest`", call. = FALSE)}
  if (missing(columns)) {stop("`columns` is missing in call to `bq_col_nest`", call. = FALSE)}

  # Validate Input Expectations
  expect_scalar_char(result)
  expect_scalar_char(dataset)
  expect_scalar_char(table)
  expect_data_type(obj = columns, type = 'character', nz_len = TRUE)

  # Create Reference to 'BigQuery' Table
  tbl <- bq_init_tbl(dataset = dataset, table = table)

  # Validate that 'tbl' Exists
  if (!isTRUE(bigrquery::bq_table_exists(tbl))) {
    stop(paste0("`", dataset, ".", table, "` does not exist in call to `bq_col_nest`", call. = FALSE))
  }

  # Collapse 'columns' into single comma-separated string
  columns_w_comma <- paste0(columns, collapse = ', ')

  # Construct SQL Statement
  stmt <- glue::glue(
    readr::read_file(system.file("sql/col_nest/bq_col_nest.sql", package = 'dbTools')),
    schema = tbl$dataset, table = tbl$table
  )

  # Execute SQL Statement
  conn_dataset <- gsql_db_connect(dataset)
  DBI::dbExecute(conn_dataset, stmt)
  DBI::dbDisconnect(conn_dataset)
  rm(conn_dataset)

  # Return 'bq_table' reference to results
  res <- bq_init_tbl('merchandising', result)
  return(res)

}

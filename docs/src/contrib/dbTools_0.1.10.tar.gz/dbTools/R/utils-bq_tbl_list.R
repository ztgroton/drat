
#' Merge set of 'bq_table' S3 objects into a single list
#'
#' @param ... ellipsis
#'
#' @return list of 'bq_table' S3 objects
#' @export
#'
bq_tbl_list <- function(...) {

  # Convert Ellipsis to List
  tbl_list <- list(...)

  # Validate `tbl_list`
  if (!isTRUE(length(tbl_list) > 0)) {
    stop("`tbl_list` must have non-zero length in call to `bq_tbl_list`", call. = FALSE)
  }

  list_elem_valid <- purrr::map_lgl(tbl_list, function(x) {isTRUE(inherits(x, 'bq_table'))})
  if (!isTRUE(all(list_elem_valid))) {
    stop("`tbl_list` must only contain S3 objects of class 'bq_table' in call to `bq_tbl_list`", call. = FALSE)
  }

  # Return `tbl_list`
  return(tbl_list)

}

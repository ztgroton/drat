
#' Validate if a set of columns 'pk' is a Primary Key on data.frame 'x'
#'
#' @importFrom rlang .data
#'
#' @param x data.frame - The data.frame containing data to be tested.
#' @param pk character - Vector of column names defining a candidate 'primary key' for 'x'.
#' @param verbose TRUE/FALSE - In case of any Primary Key Violations: Specifies if records are returned or just FALSE.
#' @param all_records TRUE/FALSE - In case of any Primary Key Violations: Specifies if all records are returned or just violations.
#'
#' @return R Object
#' @export
#'
is_valid_r_pk <- function(x, pk, verbose = FALSE, all_records = FALSE) {

  cat("Validating PK\n")

  # Validate Inputs
  if (missing(x)) {stop("`x` is missing in call to `is_valid_r_pk`", call. = FALSE)}
  if (!isTRUE(is.data.frame(x))) {stop("`x` must be `data.frame` in call to `is_valid_r_pk`", call. = FALSE)}

  if (missing(pk)) {stop("`pk` is missing in call to `is_valid_r_pk`", call. = FALSE)}
  if (!isTRUE(all(pk %in% colnames(x)))) {
    stop("`pk` must be subset of `colnames(x)` in call to `is_valid_r_pk`", call. = FALSE)
  }

  if (!isTRUE(identical(verbose, TRUE)) && !isTRUE(identical(verbose, FALSE))) {
    stop("`verbose` must be TRUE/FALSE in call to `is_valid_r_pk`", call. = FALSE)
  }

  if (!isTRUE(identical(all_records, TRUE)) && !isTRUE(identical(all_records, FALSE))) {
    stop("`all_records` must be TRUE/FALSE in call to `is_valid_r_pk`", call. = FALSE)
  }

  # Nest row numbers of `x` by `pk` columns
  cat("Nesting Columns... ")
  tictoc::tic()
  x_nest <- r_nest_pk(x, pk)
  tictoc::toc()

  # Filter for Primary Key Violations
  cat("Searching for Violations... ")
  tictoc::tic()
  x_violation <- x_nest %>% dplyr::filter(.data$orig_row_count > 1)
  tictoc::toc()
  cat("Complete\n")

  # Return Result
  if (isTRUE(verbose)) {

    if (isTRUE(all_records)) {
      return(x_nest)
    } else {
      return(x_violation)
    }

  } else {

    if (isTRUE(nrow(x_violation) == 0)) {
      return(TRUE)
    } else {
      return(FALSE)
    }

  }

}

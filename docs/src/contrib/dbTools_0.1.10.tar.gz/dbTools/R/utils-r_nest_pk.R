
#' Validate if a set of columns 'pk' is a Primary Key on data.frame 'x'
#'
#' @importFrom rlang .data
#'
#' @param x data.frame - The data.frame containing data to be tested.
#' @param pk character - Vector of column names defining a candidate 'primary key' for 'x'.
#'
#' @return R Object
#' @export
#'
r_nest_pk <- function(x, pk) {

  # Validate Inputs
  if (missing(x)) {stop("`x` is missing in call to `r_nest_pk`", call. = FALSE)}
  if (!isTRUE(is.data.frame(x))) {stop("`x` must be `data.frame` in call to `r_nest_pk`", call. = FALSE)}

  if (missing(pk)) {stop("`pk` is missing in call to `r_nest_pk`", call. = FALSE)}
  if (!isTRUE(all(pk %in% colnames(x)))) {
    stop("`pk` must be subset of `colnames(x)` in call to `r_nest_pk`", call. = FALSE)
  }

  # Nest row numbers of `x` by `pk` columns
  x_nest <- r_col_nest(x, pk)

  # Return Result
  class(x_nest) <- c(setdiff('r_nest_pk', class(x_nest)), class(x_nest))
  return(x_nest)

}

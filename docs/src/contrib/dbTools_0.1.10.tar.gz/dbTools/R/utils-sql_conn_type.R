
#' Validates if an R Object is a DBI Connection of type 'MSSQL'
#'
#' @param obj R Object
#'
#' @return TRUE/FALSE
#'
is_mssql <- function(obj) {

  mssql_classes <- c(
    "Microsoft SQL Server", "src_Microsoft SQL Server",
    "dblogConnection-Microsoft SQL Server", "src_dblogConnection-Microsoft SQL Server"
  )
  res <- isTRUE(inherits(obj, mssql_classes))
  return(res)

}

#' Validates if an R Object is a DBI Connection of type 'PSQL'
#'
#' @param obj R Object
#'
#' @return TRUE/FALSE
#'
is_psql <- function(obj) {

  psql_classes <- c(
    "src_PostgreSQLConnection", "src_PqConnection",
    "PostgreSQLConnection", "PqConnection"
  )
  res <- isTRUE(inherits(obj, psql_classes))
  return(res)

}

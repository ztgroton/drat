
#' Pull Result Sets for List of Tables, Save to File Directory
#'
#' @param conn R DBI Connection
#' @param data data.frame - must contain columns 'table' and 'column'
#' @param root_dir character - folder path to where result sets will be saved
#'
#' @return NULL
#' @export
#'
archive_table_data <- function(conn, data, root_dir) {

  # Validate Inputs
  if (missing(conn)) {stop("`conn` is missing in call to `archive_table_data`", call. = FALSE)}
  if (missing(data)) {stop("`data` is missing in call to `archive_table_data`", call. = FALSE)}
  if (missing(root_dir)) {stop("`root_dir` is missing in call to `archive_table_data`", call. = FALSE)}

  expect_dbi(obj = conn)
  expect_data_frame(df = data)
  expect_scalar_char(root_dir)

  if (!isTRUE(all(c('schema', 'table') %in% colnames(data)))) {
    stop("`colnames(data)` must contain c('table', 'schema') in call to `archive_table_data`", call. = FALSE)
  }

  # Query Table List
  cat("Querying Table List...")
  tictoc::tic()
  schema_tables <- data %>%
    dplyr::distinct(.data$schema, .data$table) %>%
    dplyr::arrange(.data$schema, .data$table)
  tictoc::toc()

  # Create Database Folder
  cat("Database Folder Setup...")
  tictoc::tic()
  dbDir <- file.path(root_dir)
  dir.create(dbDir, showWarnings = FALSE)
  tictoc::toc()

  # Create Schema Folders
  cat("Schema Folder(s) Setup...")
  tictoc::tic()
  schema_list <- schema_tables %>% dplyr::pull(.data$schema) %>% unique()
  purrr::walk(schema_list, ~ dir.create(file.path(dbDir, .), showWarnings = FALSE))
  tictoc::toc()

  # Iterate over all Tables
  cat("\nArchiving Table Data...\n")

  purrr::pwalk(schema_tables, function(schema, table){

    tryCatch({

      cat(paste0(paste(schema, table, sep = '-'), '...'))
      tictoc::tic()

      data <- get_table_data(
        conn = conn,
        schema = schema,
        table = table
      )

      data_path <- file.path(root_dir, schema, table)
      saveRDS(data, paste0(data_path, '.rds'))

      tictoc::toc()

    }, error = function(e) {
      message(sprintf("Error in %s: %s", deparse(e[["call"]]), e[["message"]]))
    })

  })

  return(NULL)

}


#' Validates that the input object is a list whose elements are all S3 Objects of class 'bq_table'
#'
#' @param tbl_list list
#'
#' @return TRUE
#' @export
#'
bq_tbl_list_validate <- function(tbl_list) {

  # Validate Inputs
  if (missing(tbl_list)) {stop("`tbl_list` is missing in call to `bq_tbl_list_validate`", call. = FALSE)}

  # Validate Input Expectations
  if (!isTRUE(is.list(tbl_list))) {return(FALSE)}

  list_elem_valid <- purrr::map_lgl(tbl_list, function(x) {isTRUE(bq_tbl_validate(x))})
  if (!isTRUE(all(list_elem_valid))) {return(FALSE)}

  # Return TRUE
  return(TRUE)

}


#' Aggregate an S3 Object of class 'r_col_nest_agg' by Existing Columns
#'
#' @param x data.frame - The data.frame containing data to be nested. Mut inherit from S3 class 'r_col_nest_agg'
#' @param group character - Vector of column names to 'group by'. Columns must already exist in 'colnames(x)'
#'
#' @return data.frame
#' @export
#'
r_col_nest_agg <- function(x, group) {

  # Validate Inputs
  if (missing(x)) {stop("`x` is missing in call to `r_col_nest_agg`", call. = FALSE)}
  if (!isTRUE(inherits(x, 'r_col_nest'))) {stop("`x` must inherit from 'r_col_nest' in call to 'r_col_nest_agg'", call. = FALSE)}
  if (!isTRUE(is.data.frame(x))) {stop("`x` must be `data.frame` in call to `r_col_nest_agg`", call. = FALSE)}

  if (missing(group)) {stop("`group` is missing in call to `r_col_nest_agg`", call. = FALSE)}
  if (!isTRUE(all(group %in% colnames(x)))) {
    stop("`group` must be subset of `colnames(x)` in call to `r_col_nest_agg`", call. = FALSE)
  }

  # Initialize `group_by_cols` for later use
  group_by_cols <- setdiff(colnames(x), c(group, 'nest_row_num', 'nest_row_cnt'))

  # Create Aggregated Nesting
  x <- x %>%
    dplyr::group_by_at(group_by_cols) %>%
    dplyr::summarise(
      nest_row_num = dplyr::bind_rows(.data$nest_row_num),
      nest_row_cnt = sum(.data$nest_row_cnt),
      .groups = 'keep'
    ) %>%
    dplyr::ungroup()

  # Return
  class(x) <- c('r_col_nest_agg', unique(setdiff(class(x), 'r_col_nest_agg')))
  return(x)

}
